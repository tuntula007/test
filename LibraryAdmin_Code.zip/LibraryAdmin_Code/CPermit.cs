using System;
using System.Collections;
public class CPermit
{
	private ArrayList m_Access = new ArrayList();
	private string m_Userid;
	private string m_Usergroup;
	private string m_Logintime;
	private string m_Computer;
	private string m_Hostname;
	private string m_IPAddress;
	private string m_Direction;
	private string m_MsgType;
	private string m_SourceApplication;
	private string m_SourceClass;
	private string m_MethodName;
	private string m_Password;
	public ArrayList Access
	{
		get
		{
			return this.m_Access;
		}
		set
		{
			this.m_Access = value;
		}
	}
	public string Direction
	{
		get
		{
			return this.m_Direction;
		}
		set
		{
			this.m_Direction = value;
		}
	}
	public string Userid
	{
		get
		{
			return this.m_Userid;
		}
		set
		{
			this.m_Userid = value;
		}
	}
	public string Usergroup
	{
		get
		{
			return this.m_Usergroup;
		}
		set
		{
			this.m_Usergroup = value;
		}
	}
	public string Logintime
	{
		get
		{
			return this.m_Logintime;
		}
		set
		{
			this.m_Logintime = value;
		}
	}
	public string Computer
	{
		get
		{
			return this.m_Computer;
		}
		set
		{
			this.m_Computer = value;
		}
	}
	public string Hostname
	{
		get
		{
			return this.m_Hostname;
		}
		set
		{
			this.m_Hostname = value;
		}
	}
	public string IPAddress
	{
		get
		{
			return this.m_IPAddress;
		}
		set
		{
			this.m_IPAddress = value;
		}
	}
	public string MsgType
	{
		get
		{
			return this.m_MsgType;
		}
		set
		{
			this.m_MsgType = value;
		}
	}
	public string SourceApplication
	{
		get
		{
			return this.m_SourceApplication;
		}
		set
		{
			this.m_SourceApplication = value;
		}
	}
	public string SourceClass
	{
		get
		{
			return this.m_SourceClass;
		}
		set
		{
			this.m_SourceClass = value;
		}
	}
	public string MethodName
	{
		get
		{
			return this.m_MethodName;
		}
		set
		{
			this.m_MethodName = value;
		}
	}
	public string Password
	{
		get
		{
			return this.m_Password;
		}
		set
		{
			this.m_Password = value;
		}
	}
	public CPermit()
	{
		this.MsgType = "INFO";
	}
}
