using System;
using System.Messaging;
public class CWritetoqueue
{
	public CPermit Logonpermit;
	public string strPath;
	public void Writeaudit(CPermit cp)
	{
		try
		{
			DefaultPropertiesToSend defaultPropertiesToSend = new DefaultPropertiesToSend();
			defaultPropertiesToSend.AttachSenderId = true;
			defaultPropertiesToSend.Recoverable = true;
			MessageQueue messageQueue;
			if (!MessageQueue.Exists(this.strPath))
			{
				messageQueue = MessageQueue.Create(this.strPath);
				messageQueue.SetPermissions("Everyone", MessageQueueAccessRights.FullControl);
			}
			else
			{
				messageQueue = new MessageQueue(this.strPath);
				messageQueue.Formatter = new XmlMessageFormatter(new Type[]
				{
					typeof(CPermit)
				});
				messageQueue.DefaultPropertiesToSend = defaultPropertiesToSend;
			}
			messageQueue.DefaultPropertiesToSend.Recoverable = true;
			messageQueue.DefaultPropertiesToSend.AttachSenderId = true;
			messageQueue.DefaultPropertiesToSend.Label = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + " " + cp.Userid;
			messageQueue.Send(cp);
			messageQueue.Dispose();
			messageQueue.Close();
		}
		catch (Exception ex)
		{
			string arg_D4_0 = ex.Message;
		}
	}
}
