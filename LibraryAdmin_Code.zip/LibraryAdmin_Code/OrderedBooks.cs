using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;
[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0"), HelpKeyword("vs.data.DataSet"), DesignerCategory("code"), ToolboxItem(true), XmlRoot("OrderedBooks"), XmlSchemaProvider("GetTypedDataSetSchema")]
[Serializable]
public class OrderedBooks : DataSet
{
	public delegate void BookAquisitionsRowChangeEventHandler(object sender, OrderedBooks.BookAquisitionsRowChangeEvent e);
	[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0"), XmlSchemaProvider("GetTypedTableSchema")]
	[Serializable]
	public class BookAquisitionsDataTable : TypedTableBase<OrderedBooks.BookAquisitionsRow>
	{
		private DataColumn columnSrn;
		private DataColumn columnOrderNo;
		private DataColumn columnTitle;
		private DataColumn columnAuthor;
		private DataColumn columnPublisher;
		private DataColumn columnBookType;
		private DataColumn columnDealer;
		private DataColumn columnAquisitionType;
		private DataColumn columnOrderedGroup;
		private DataColumn columnSetupBy;
		private DataColumn columnDatesetup;
		private DataColumn columnReceivedStatus;
		private DataColumn columnCopies;
		private DataColumn columnPublishedDate;
		private DataColumn columnPublishedYear;
		private DataColumn columnVol;
		private DataColumn columnNo;
		private DataColumn columnEdition;
		private DataColumn columnCost;
		private DataColumn columnTotalCost;
		private DataColumn columnTransId;
		public event OrderedBooks.BookAquisitionsRowChangeEventHandler BookAquisitionsRowChanging
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.BookAquisitionsRowChanging = (OrderedBooks.BookAquisitionsRowChangeEventHandler)Delegate.Combine(this.BookAquisitionsRowChanging, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.BookAquisitionsRowChanging = (OrderedBooks.BookAquisitionsRowChangeEventHandler)Delegate.Remove(this.BookAquisitionsRowChanging, value);
			}
		}
		public event OrderedBooks.BookAquisitionsRowChangeEventHandler BookAquisitionsRowChanged
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.BookAquisitionsRowChanged = (OrderedBooks.BookAquisitionsRowChangeEventHandler)Delegate.Combine(this.BookAquisitionsRowChanged, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.BookAquisitionsRowChanged = (OrderedBooks.BookAquisitionsRowChangeEventHandler)Delegate.Remove(this.BookAquisitionsRowChanged, value);
			}
		}
		public event OrderedBooks.BookAquisitionsRowChangeEventHandler BookAquisitionsRowDeleting
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.BookAquisitionsRowDeleting = (OrderedBooks.BookAquisitionsRowChangeEventHandler)Delegate.Combine(this.BookAquisitionsRowDeleting, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.BookAquisitionsRowDeleting = (OrderedBooks.BookAquisitionsRowChangeEventHandler)Delegate.Remove(this.BookAquisitionsRowDeleting, value);
			}
		}
		public event OrderedBooks.BookAquisitionsRowChangeEventHandler BookAquisitionsRowDeleted
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.BookAquisitionsRowDeleted = (OrderedBooks.BookAquisitionsRowChangeEventHandler)Delegate.Combine(this.BookAquisitionsRowDeleted, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.BookAquisitionsRowDeleted = (OrderedBooks.BookAquisitionsRowChangeEventHandler)Delegate.Remove(this.BookAquisitionsRowDeleted, value);
			}
		}
		[DebuggerNonUserCode]
		public DataColumn SrnColumn
		{
			get
			{
				return this.columnSrn;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn OrderNoColumn
		{
			get
			{
				return this.columnOrderNo;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn TitleColumn
		{
			get
			{
				return this.columnTitle;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn AuthorColumn
		{
			get
			{
				return this.columnAuthor;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn PublisherColumn
		{
			get
			{
				return this.columnPublisher;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn BookTypeColumn
		{
			get
			{
				return this.columnBookType;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn DealerColumn
		{
			get
			{
				return this.columnDealer;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn AquisitionTypeColumn
		{
			get
			{
				return this.columnAquisitionType;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn OrderedGroupColumn
		{
			get
			{
				return this.columnOrderedGroup;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn SetupByColumn
		{
			get
			{
				return this.columnSetupBy;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn DatesetupColumn
		{
			get
			{
				return this.columnDatesetup;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn ReceivedStatusColumn
		{
			get
			{
				return this.columnReceivedStatus;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn CopiesColumn
		{
			get
			{
				return this.columnCopies;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn PublishedDateColumn
		{
			get
			{
				return this.columnPublishedDate;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn PublishedYearColumn
		{
			get
			{
				return this.columnPublishedYear;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn VolColumn
		{
			get
			{
				return this.columnVol;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn NoColumn
		{
			get
			{
				return this.columnNo;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn EditionColumn
		{
			get
			{
				return this.columnEdition;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn CostColumn
		{
			get
			{
				return this.columnCost;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn TotalCostColumn
		{
			get
			{
				return this.columnTotalCost;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn TransIdColumn
		{
			get
			{
				return this.columnTransId;
			}
		}
		[Browsable(false), DebuggerNonUserCode]
		public int Count
		{
			get
			{
				return base.Rows.Count;
			}
		}
		[DebuggerNonUserCode]
		public OrderedBooks.BookAquisitionsRow this[int index]
		{
			get
			{
				return (OrderedBooks.BookAquisitionsRow)base.Rows[index];
			}
		}
		[DebuggerNonUserCode]
		public BookAquisitionsDataTable()
		{
			base.TableName = "BookAquisitions";
			this.BeginInit();
			this.InitClass();
			this.EndInit();
		}
		[DebuggerNonUserCode]
		internal BookAquisitionsDataTable(DataTable table)
		{
			base.TableName = table.TableName;
			if (table.CaseSensitive != table.DataSet.CaseSensitive)
			{
				base.CaseSensitive = table.CaseSensitive;
			}
			if (table.Locale.ToString() != table.DataSet.Locale.ToString())
			{
				base.Locale = table.Locale;
			}
			if (table.Namespace != table.DataSet.Namespace)
			{
				base.Namespace = table.Namespace;
			}
			base.Prefix = table.Prefix;
			base.MinimumCapacity = table.MinimumCapacity;
		}
		[DebuggerNonUserCode]
		protected BookAquisitionsDataTable(SerializationInfo info, StreamingContext context) : base(info, context)
		{
			this.InitVars();
		}
		[DebuggerNonUserCode]
		public void AddBookAquisitionsRow(OrderedBooks.BookAquisitionsRow row)
		{
			base.Rows.Add(row);
		}
		[DebuggerNonUserCode]
		public OrderedBooks.BookAquisitionsRow AddBookAquisitionsRow(string OrderNo, string Title, string Author, string Publisher, string BookType, string Dealer, string AquisitionType, string OrderedGroup, string SetupBy, DateTime Datesetup, int ReceivedStatus, int Copies, string PublishedDate, string PublishedYear, int Vol, int No, string Edition, decimal Cost, decimal TotalCost, string TransId)
		{
			OrderedBooks.BookAquisitionsRow bookAquisitionsRow = (OrderedBooks.BookAquisitionsRow)base.NewRow();
			object[] itemArray = new object[]
			{
				null,
				OrderNo,
				Title,
				Author,
				Publisher,
				BookType,
				Dealer,
				AquisitionType,
				OrderedGroup,
				SetupBy,
				Datesetup,
				ReceivedStatus,
				Copies,
				PublishedDate,
				PublishedYear,
				Vol,
				No,
				Edition,
				Cost,
				TotalCost,
				TransId
			};
			bookAquisitionsRow.ItemArray = itemArray;
			base.Rows.Add(bookAquisitionsRow);
			return bookAquisitionsRow;
		}
		[DebuggerNonUserCode]
		public override DataTable Clone()
		{
			OrderedBooks.BookAquisitionsDataTable bookAquisitionsDataTable = (OrderedBooks.BookAquisitionsDataTable)base.Clone();
			bookAquisitionsDataTable.InitVars();
			return bookAquisitionsDataTable;
		}
		[DebuggerNonUserCode]
		protected override DataTable CreateInstance()
		{
			return new OrderedBooks.BookAquisitionsDataTable();
		}
		[DebuggerNonUserCode]
		internal void InitVars()
		{
			this.columnSrn = base.Columns["Srn"];
			this.columnOrderNo = base.Columns["OrderNo"];
			this.columnTitle = base.Columns["Title"];
			this.columnAuthor = base.Columns["Author"];
			this.columnPublisher = base.Columns["Publisher"];
			this.columnBookType = base.Columns["BookType"];
			this.columnDealer = base.Columns["Dealer"];
			this.columnAquisitionType = base.Columns["AquisitionType"];
			this.columnOrderedGroup = base.Columns["OrderedGroup"];
			this.columnSetupBy = base.Columns["SetupBy"];
			this.columnDatesetup = base.Columns["Datesetup"];
			this.columnReceivedStatus = base.Columns["ReceivedStatus"];
			this.columnCopies = base.Columns["Copies"];
			this.columnPublishedDate = base.Columns["PublishedDate"];
			this.columnPublishedYear = base.Columns["PublishedYear"];
			this.columnVol = base.Columns["Vol"];
			this.columnNo = base.Columns["No"];
			this.columnEdition = base.Columns["Edition"];
			this.columnCost = base.Columns["Cost"];
			this.columnTotalCost = base.Columns["TotalCost"];
			this.columnTransId = base.Columns["TransId"];
		}
		[DebuggerNonUserCode]
		private void InitClass()
		{
			this.columnSrn = new DataColumn("Srn", typeof(decimal), null, MappingType.Element);
			base.Columns.Add(this.columnSrn);
			this.columnOrderNo = new DataColumn("OrderNo", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnOrderNo);
			this.columnTitle = new DataColumn("Title", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnTitle);
			this.columnAuthor = new DataColumn("Author", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnAuthor);
			this.columnPublisher = new DataColumn("Publisher", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnPublisher);
			this.columnBookType = new DataColumn("BookType", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnBookType);
			this.columnDealer = new DataColumn("Dealer", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnDealer);
			this.columnAquisitionType = new DataColumn("AquisitionType", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnAquisitionType);
			this.columnOrderedGroup = new DataColumn("OrderedGroup", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnOrderedGroup);
			this.columnSetupBy = new DataColumn("SetupBy", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnSetupBy);
			this.columnDatesetup = new DataColumn("Datesetup", typeof(DateTime), null, MappingType.Element);
			base.Columns.Add(this.columnDatesetup);
			this.columnReceivedStatus = new DataColumn("ReceivedStatus", typeof(int), null, MappingType.Element);
			base.Columns.Add(this.columnReceivedStatus);
			this.columnCopies = new DataColumn("Copies", typeof(int), null, MappingType.Element);
			base.Columns.Add(this.columnCopies);
			this.columnPublishedDate = new DataColumn("PublishedDate", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnPublishedDate);
			this.columnPublishedYear = new DataColumn("PublishedYear", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnPublishedYear);
			this.columnVol = new DataColumn("Vol", typeof(int), null, MappingType.Element);
			base.Columns.Add(this.columnVol);
			this.columnNo = new DataColumn("No", typeof(int), null, MappingType.Element);
			base.Columns.Add(this.columnNo);
			this.columnEdition = new DataColumn("Edition", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnEdition);
			this.columnCost = new DataColumn("Cost", typeof(decimal), null, MappingType.Element);
			base.Columns.Add(this.columnCost);
			this.columnTotalCost = new DataColumn("TotalCost", typeof(decimal), null, MappingType.Element);
			base.Columns.Add(this.columnTotalCost);
			this.columnTransId = new DataColumn("TransId", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnTransId);
			this.columnSrn.AutoIncrement = true;
			this.columnSrn.AutoIncrementSeed = -1L;
			this.columnSrn.AutoIncrementStep = -1L;
			this.columnSrn.AllowDBNull = false;
			this.columnSrn.ReadOnly = true;
			this.columnOrderNo.AllowDBNull = false;
			this.columnOrderNo.MaxLength = 50;
			this.columnTitle.MaxLength = 200;
			this.columnAuthor.MaxLength = 50;
			this.columnPublisher.MaxLength = 50;
			this.columnBookType.MaxLength = 50;
			this.columnDealer.MaxLength = 50;
			this.columnAquisitionType.MaxLength = 50;
			this.columnOrderedGroup.MaxLength = 100;
			this.columnSetupBy.MaxLength = 50;
			this.columnReceivedStatus.AllowDBNull = false;
			this.columnPublishedDate.MaxLength = 50;
			this.columnPublishedYear.MaxLength = 50;
			this.columnEdition.MaxLength = 50;
			this.columnTransId.MaxLength = 50;
		}
		[DebuggerNonUserCode]
		public OrderedBooks.BookAquisitionsRow NewBookAquisitionsRow()
		{
			return (OrderedBooks.BookAquisitionsRow)base.NewRow();
		}
		[DebuggerNonUserCode]
		protected override DataRow NewRowFromBuilder(DataRowBuilder builder)
		{
			return new OrderedBooks.BookAquisitionsRow(builder);
		}
		[DebuggerNonUserCode]
		protected override Type GetRowType()
		{
			return typeof(OrderedBooks.BookAquisitionsRow);
		}
		[DebuggerNonUserCode]
		protected override void OnRowChanged(DataRowChangeEventArgs e)
		{
			base.OnRowChanged(e);
			if (this.BookAquisitionsRowChanged != null)
			{
				this.BookAquisitionsRowChanged(this, new OrderedBooks.BookAquisitionsRowChangeEvent((OrderedBooks.BookAquisitionsRow)e.Row, e.Action));
			}
		}
		[DebuggerNonUserCode]
		protected override void OnRowChanging(DataRowChangeEventArgs e)
		{
			base.OnRowChanging(e);
			if (this.BookAquisitionsRowChanging != null)
			{
				this.BookAquisitionsRowChanging(this, new OrderedBooks.BookAquisitionsRowChangeEvent((OrderedBooks.BookAquisitionsRow)e.Row, e.Action));
			}
		}
		[DebuggerNonUserCode]
		protected override void OnRowDeleted(DataRowChangeEventArgs e)
		{
			base.OnRowDeleted(e);
			if (this.BookAquisitionsRowDeleted != null)
			{
				this.BookAquisitionsRowDeleted(this, new OrderedBooks.BookAquisitionsRowChangeEvent((OrderedBooks.BookAquisitionsRow)e.Row, e.Action));
			}
		}
		[DebuggerNonUserCode]
		protected override void OnRowDeleting(DataRowChangeEventArgs e)
		{
			base.OnRowDeleting(e);
			if (this.BookAquisitionsRowDeleting != null)
			{
				this.BookAquisitionsRowDeleting(this, new OrderedBooks.BookAquisitionsRowChangeEvent((OrderedBooks.BookAquisitionsRow)e.Row, e.Action));
			}
		}
		[DebuggerNonUserCode]
		public void RemoveBookAquisitionsRow(OrderedBooks.BookAquisitionsRow row)
		{
			base.Rows.Remove(row);
		}
		[DebuggerNonUserCode]
		public static XmlSchemaComplexType GetTypedTableSchema(XmlSchemaSet xs)
		{
			XmlSchemaComplexType xmlSchemaComplexType = new XmlSchemaComplexType();
			XmlSchemaSequence xmlSchemaSequence = new XmlSchemaSequence();
			OrderedBooks orderedBooks = new OrderedBooks();
			XmlSchemaAny xmlSchemaAny = new XmlSchemaAny();
			xmlSchemaAny.Namespace = "http://www.w3.org/2001/XMLSchema";
			xmlSchemaAny.MinOccurs = 0m;
			xmlSchemaAny.MaxOccurs = 79228162514264337593543950335m;
			xmlSchemaAny.ProcessContents = XmlSchemaContentProcessing.Lax;
			xmlSchemaSequence.Items.Add(xmlSchemaAny);
			XmlSchemaAny xmlSchemaAny2 = new XmlSchemaAny();
			xmlSchemaAny2.Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1";
			xmlSchemaAny2.MinOccurs = 1m;
			xmlSchemaAny2.ProcessContents = XmlSchemaContentProcessing.Lax;
			xmlSchemaSequence.Items.Add(xmlSchemaAny2);
			XmlSchemaAttribute xmlSchemaAttribute = new XmlSchemaAttribute();
			xmlSchemaAttribute.Name = "namespace";
			xmlSchemaAttribute.FixedValue = orderedBooks.Namespace;
			xmlSchemaComplexType.Attributes.Add(xmlSchemaAttribute);
			XmlSchemaAttribute xmlSchemaAttribute2 = new XmlSchemaAttribute();
			xmlSchemaAttribute2.Name = "tableTypeName";
			xmlSchemaAttribute2.FixedValue = "BookAquisitionsDataTable";
			xmlSchemaComplexType.Attributes.Add(xmlSchemaAttribute2);
			xmlSchemaComplexType.Particle = xmlSchemaSequence;
			XmlSchema schemaSerializable = orderedBooks.GetSchemaSerializable();
			if (xs.Contains(schemaSerializable.TargetNamespace))
			{
				MemoryStream memoryStream = new MemoryStream();
				MemoryStream memoryStream2 = new MemoryStream();
				try
				{
					schemaSerializable.Write(memoryStream);
					IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
					while (enumerator.MoveNext())
					{
						XmlSchema xmlSchema = (XmlSchema)enumerator.Current;
						memoryStream2.SetLength(0L);
						xmlSchema.Write(memoryStream2);
						if (memoryStream.Length == memoryStream2.Length)
						{
							memoryStream.Position = 0L;
							memoryStream2.Position = 0L;
							while (memoryStream.Position != memoryStream.Length && memoryStream.ReadByte() == memoryStream2.ReadByte())
							{
							}
							if (memoryStream.Position == memoryStream.Length)
							{
								return xmlSchemaComplexType;
							}
						}
					}
				}
				finally
				{
					if (memoryStream != null)
					{
						memoryStream.Close();
					}
					if (memoryStream2 != null)
					{
						memoryStream2.Close();
					}
				}
			}
			xs.Add(schemaSerializable);
			return xmlSchemaComplexType;
		}
	}
	[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0")]
	public class BookAquisitionsRow : DataRow
	{
		private OrderedBooks.BookAquisitionsDataTable tableBookAquisitions;
		[DebuggerNonUserCode]
		public decimal Srn
		{
			get
			{
				return (decimal)base[this.tableBookAquisitions.SrnColumn];
			}
			set
			{
				base[this.tableBookAquisitions.SrnColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string OrderNo
		{
			get
			{
				return (string)base[this.tableBookAquisitions.OrderNoColumn];
			}
			set
			{
				base[this.tableBookAquisitions.OrderNoColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Title
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookAquisitions.TitleColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Title' in table 'BookAquisitions' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookAquisitions.TitleColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Author
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookAquisitions.AuthorColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Author' in table 'BookAquisitions' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookAquisitions.AuthorColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Publisher
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookAquisitions.PublisherColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Publisher' in table 'BookAquisitions' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookAquisitions.PublisherColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string BookType
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookAquisitions.BookTypeColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'BookType' in table 'BookAquisitions' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookAquisitions.BookTypeColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Dealer
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookAquisitions.DealerColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Dealer' in table 'BookAquisitions' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookAquisitions.DealerColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string AquisitionType
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookAquisitions.AquisitionTypeColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'AquisitionType' in table 'BookAquisitions' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookAquisitions.AquisitionTypeColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string OrderedGroup
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookAquisitions.OrderedGroupColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'OrderedGroup' in table 'BookAquisitions' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookAquisitions.OrderedGroupColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string SetupBy
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookAquisitions.SetupByColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'SetupBy' in table 'BookAquisitions' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookAquisitions.SetupByColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public DateTime Datesetup
		{
			get
			{
				DateTime result;
				try
				{
					result = (DateTime)base[this.tableBookAquisitions.DatesetupColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Datesetup' in table 'BookAquisitions' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookAquisitions.DatesetupColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public int ReceivedStatus
		{
			get
			{
				return (int)base[this.tableBookAquisitions.ReceivedStatusColumn];
			}
			set
			{
				base[this.tableBookAquisitions.ReceivedStatusColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public int Copies
		{
			get
			{
				int result;
				try
				{
					result = (int)base[this.tableBookAquisitions.CopiesColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Copies' in table 'BookAquisitions' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookAquisitions.CopiesColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string PublishedDate
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookAquisitions.PublishedDateColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'PublishedDate' in table 'BookAquisitions' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookAquisitions.PublishedDateColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string PublishedYear
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookAquisitions.PublishedYearColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'PublishedYear' in table 'BookAquisitions' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookAquisitions.PublishedYearColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public int Vol
		{
			get
			{
				int result;
				try
				{
					result = (int)base[this.tableBookAquisitions.VolColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Vol' in table 'BookAquisitions' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookAquisitions.VolColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public int No
		{
			get
			{
				int result;
				try
				{
					result = (int)base[this.tableBookAquisitions.NoColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'No' in table 'BookAquisitions' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookAquisitions.NoColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Edition
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookAquisitions.EditionColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Edition' in table 'BookAquisitions' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookAquisitions.EditionColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public decimal Cost
		{
			get
			{
				decimal result;
				try
				{
					result = (decimal)base[this.tableBookAquisitions.CostColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Cost' in table 'BookAquisitions' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookAquisitions.CostColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public decimal TotalCost
		{
			get
			{
				decimal result;
				try
				{
					result = (decimal)base[this.tableBookAquisitions.TotalCostColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'TotalCost' in table 'BookAquisitions' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookAquisitions.TotalCostColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string TransId
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookAquisitions.TransIdColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'TransId' in table 'BookAquisitions' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookAquisitions.TransIdColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		internal BookAquisitionsRow(DataRowBuilder rb) : base(rb)
		{
			this.tableBookAquisitions = (OrderedBooks.BookAquisitionsDataTable)base.Table;
		}
		[DebuggerNonUserCode]
		public bool IsTitleNull()
		{
			return base.IsNull(this.tableBookAquisitions.TitleColumn);
		}
		[DebuggerNonUserCode]
		public void SetTitleNull()
		{
			base[this.tableBookAquisitions.TitleColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsAuthorNull()
		{
			return base.IsNull(this.tableBookAquisitions.AuthorColumn);
		}
		[DebuggerNonUserCode]
		public void SetAuthorNull()
		{
			base[this.tableBookAquisitions.AuthorColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsPublisherNull()
		{
			return base.IsNull(this.tableBookAquisitions.PublisherColumn);
		}
		[DebuggerNonUserCode]
		public void SetPublisherNull()
		{
			base[this.tableBookAquisitions.PublisherColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsBookTypeNull()
		{
			return base.IsNull(this.tableBookAquisitions.BookTypeColumn);
		}
		[DebuggerNonUserCode]
		public void SetBookTypeNull()
		{
			base[this.tableBookAquisitions.BookTypeColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsDealerNull()
		{
			return base.IsNull(this.tableBookAquisitions.DealerColumn);
		}
		[DebuggerNonUserCode]
		public void SetDealerNull()
		{
			base[this.tableBookAquisitions.DealerColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsAquisitionTypeNull()
		{
			return base.IsNull(this.tableBookAquisitions.AquisitionTypeColumn);
		}
		[DebuggerNonUserCode]
		public void SetAquisitionTypeNull()
		{
			base[this.tableBookAquisitions.AquisitionTypeColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsOrderedGroupNull()
		{
			return base.IsNull(this.tableBookAquisitions.OrderedGroupColumn);
		}
		[DebuggerNonUserCode]
		public void SetOrderedGroupNull()
		{
			base[this.tableBookAquisitions.OrderedGroupColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsSetupByNull()
		{
			return base.IsNull(this.tableBookAquisitions.SetupByColumn);
		}
		[DebuggerNonUserCode]
		public void SetSetupByNull()
		{
			base[this.tableBookAquisitions.SetupByColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsDatesetupNull()
		{
			return base.IsNull(this.tableBookAquisitions.DatesetupColumn);
		}
		[DebuggerNonUserCode]
		public void SetDatesetupNull()
		{
			base[this.tableBookAquisitions.DatesetupColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsCopiesNull()
		{
			return base.IsNull(this.tableBookAquisitions.CopiesColumn);
		}
		[DebuggerNonUserCode]
		public void SetCopiesNull()
		{
			base[this.tableBookAquisitions.CopiesColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsPublishedDateNull()
		{
			return base.IsNull(this.tableBookAquisitions.PublishedDateColumn);
		}
		[DebuggerNonUserCode]
		public void SetPublishedDateNull()
		{
			base[this.tableBookAquisitions.PublishedDateColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsPublishedYearNull()
		{
			return base.IsNull(this.tableBookAquisitions.PublishedYearColumn);
		}
		[DebuggerNonUserCode]
		public void SetPublishedYearNull()
		{
			base[this.tableBookAquisitions.PublishedYearColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsVolNull()
		{
			return base.IsNull(this.tableBookAquisitions.VolColumn);
		}
		[DebuggerNonUserCode]
		public void SetVolNull()
		{
			base[this.tableBookAquisitions.VolColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsNoNull()
		{
			return base.IsNull(this.tableBookAquisitions.NoColumn);
		}
		[DebuggerNonUserCode]
		public void SetNoNull()
		{
			base[this.tableBookAquisitions.NoColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsEditionNull()
		{
			return base.IsNull(this.tableBookAquisitions.EditionColumn);
		}
		[DebuggerNonUserCode]
		public void SetEditionNull()
		{
			base[this.tableBookAquisitions.EditionColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsCostNull()
		{
			return base.IsNull(this.tableBookAquisitions.CostColumn);
		}
		[DebuggerNonUserCode]
		public void SetCostNull()
		{
			base[this.tableBookAquisitions.CostColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsTotalCostNull()
		{
			return base.IsNull(this.tableBookAquisitions.TotalCostColumn);
		}
		[DebuggerNonUserCode]
		public void SetTotalCostNull()
		{
			base[this.tableBookAquisitions.TotalCostColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsTransIdNull()
		{
			return base.IsNull(this.tableBookAquisitions.TransIdColumn);
		}
		[DebuggerNonUserCode]
		public void SetTransIdNull()
		{
			base[this.tableBookAquisitions.TransIdColumn] = Convert.DBNull;
		}
	}
	[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0")]
	public class BookAquisitionsRowChangeEvent : EventArgs
	{
		private OrderedBooks.BookAquisitionsRow eventRow;
		private DataRowAction eventAction;
		[DebuggerNonUserCode]
		public OrderedBooks.BookAquisitionsRow Row
		{
			get
			{
				return this.eventRow;
			}
		}
		[DebuggerNonUserCode]
		public DataRowAction Action
		{
			get
			{
				return this.eventAction;
			}
		}
		[DebuggerNonUserCode]
		public BookAquisitionsRowChangeEvent(OrderedBooks.BookAquisitionsRow row, DataRowAction action)
		{
			this.eventRow = row;
			this.eventAction = action;
		}
	}
	private OrderedBooks.BookAquisitionsDataTable tableBookAquisitions;
	private SchemaSerializationMode _schemaSerializationMode = SchemaSerializationMode.IncludeSchema;
	[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Content), DebuggerNonUserCode]
	public OrderedBooks.BookAquisitionsDataTable BookAquisitions
	{
		get
		{
			return this.tableBookAquisitions;
		}
	}
	[Browsable(true), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible), DebuggerNonUserCode]
	public override SchemaSerializationMode SchemaSerializationMode
	{
		get
		{
			return this._schemaSerializationMode;
		}
		set
		{
			this._schemaSerializationMode = value;
		}
	}
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden), DebuggerNonUserCode]
	public new DataTableCollection Tables
	{
		get
		{
			return base.Tables;
		}
	}
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden), DebuggerNonUserCode]
	public new DataRelationCollection Relations
	{
		get
		{
			return base.Relations;
		}
	}
	[DebuggerNonUserCode]
	public OrderedBooks()
	{
		base.BeginInit();
		this.InitClass();
		CollectionChangeEventHandler value = new CollectionChangeEventHandler(this.SchemaChanged);
		base.Tables.CollectionChanged += value;
		base.Relations.CollectionChanged += value;
		base.EndInit();
	}
	[DebuggerNonUserCode]
	protected OrderedBooks(SerializationInfo info, StreamingContext context) : base(info, context, false)
	{
		if (base.IsBinarySerialized(info, context))
		{
			this.InitVars(false);
			CollectionChangeEventHandler value = new CollectionChangeEventHandler(this.SchemaChanged);
			this.Tables.CollectionChanged += value;
			this.Relations.CollectionChanged += value;
			return;
		}
		string s = (string)info.GetValue("XmlSchema", typeof(string));
		if (base.DetermineSchemaSerializationMode(info, context) == SchemaSerializationMode.IncludeSchema)
		{
			DataSet dataSet = new DataSet();
			dataSet.ReadXmlSchema(new XmlTextReader(new StringReader(s)));
			if (dataSet.Tables["BookAquisitions"] != null)
			{
				base.Tables.Add(new OrderedBooks.BookAquisitionsDataTable(dataSet.Tables["BookAquisitions"]));
			}
			base.DataSetName = dataSet.DataSetName;
			base.Prefix = dataSet.Prefix;
			base.Namespace = dataSet.Namespace;
			base.Locale = dataSet.Locale;
			base.CaseSensitive = dataSet.CaseSensitive;
			base.EnforceConstraints = dataSet.EnforceConstraints;
			base.Merge(dataSet, false, MissingSchemaAction.Add);
			this.InitVars();
		}
		else
		{
			base.ReadXmlSchema(new XmlTextReader(new StringReader(s)));
		}
		base.GetSerializationData(info, context);
		CollectionChangeEventHandler value2 = new CollectionChangeEventHandler(this.SchemaChanged);
		base.Tables.CollectionChanged += value2;
		this.Relations.CollectionChanged += value2;
	}
	[DebuggerNonUserCode]
	protected override void InitializeDerivedDataSet()
	{
		base.BeginInit();
		this.InitClass();
		base.EndInit();
	}
	[DebuggerNonUserCode]
	public override DataSet Clone()
	{
		OrderedBooks orderedBooks = (OrderedBooks)base.Clone();
		orderedBooks.InitVars();
		orderedBooks.SchemaSerializationMode = this.SchemaSerializationMode;
		return orderedBooks;
	}
	[DebuggerNonUserCode]
	protected override bool ShouldSerializeTables()
	{
		return false;
	}
	[DebuggerNonUserCode]
	protected override bool ShouldSerializeRelations()
	{
		return false;
	}
	[DebuggerNonUserCode]
	protected override void ReadXmlSerializable(XmlReader reader)
	{
		if (base.DetermineSchemaSerializationMode(reader) == SchemaSerializationMode.IncludeSchema)
		{
			this.Reset();
			DataSet dataSet = new DataSet();
			dataSet.ReadXml(reader);
			if (dataSet.Tables["BookAquisitions"] != null)
			{
				base.Tables.Add(new OrderedBooks.BookAquisitionsDataTable(dataSet.Tables["BookAquisitions"]));
			}
			base.DataSetName = dataSet.DataSetName;
			base.Prefix = dataSet.Prefix;
			base.Namespace = dataSet.Namespace;
			base.Locale = dataSet.Locale;
			base.CaseSensitive = dataSet.CaseSensitive;
			base.EnforceConstraints = dataSet.EnforceConstraints;
			base.Merge(dataSet, false, MissingSchemaAction.Add);
			this.InitVars();
			return;
		}
		base.ReadXml(reader);
		this.InitVars();
	}
	[DebuggerNonUserCode]
	protected override XmlSchema GetSchemaSerializable()
	{
		MemoryStream memoryStream = new MemoryStream();
		base.WriteXmlSchema(new XmlTextWriter(memoryStream, null));
		memoryStream.Position = 0L;
		return XmlSchema.Read(new XmlTextReader(memoryStream), null);
	}
	[DebuggerNonUserCode]
	internal void InitVars()
	{
		this.InitVars(true);
	}
	[DebuggerNonUserCode]
	internal void InitVars(bool initTable)
	{
		this.tableBookAquisitions = (OrderedBooks.BookAquisitionsDataTable)base.Tables["BookAquisitions"];
		if (initTable && this.tableBookAquisitions != null)
		{
			this.tableBookAquisitions.InitVars();
		}
	}
	[DebuggerNonUserCode]
	private void InitClass()
	{
		base.DataSetName = "OrderedBooks";
		base.Prefix = "";
		base.Namespace = "http://tempuri.org/OrderedBooks.xsd";
		base.EnforceConstraints = true;
		this.SchemaSerializationMode = SchemaSerializationMode.IncludeSchema;
		this.tableBookAquisitions = new OrderedBooks.BookAquisitionsDataTable();
		base.Tables.Add(this.tableBookAquisitions);
	}
	[DebuggerNonUserCode]
	private bool ShouldSerializeBookAquisitions()
	{
		return false;
	}
	[DebuggerNonUserCode]
	private void SchemaChanged(object sender, CollectionChangeEventArgs e)
	{
		if (e.Action == CollectionChangeAction.Remove)
		{
			this.InitVars();
		}
	}
	[DebuggerNonUserCode]
	public static XmlSchemaComplexType GetTypedDataSetSchema(XmlSchemaSet xs)
	{
		OrderedBooks orderedBooks = new OrderedBooks();
		XmlSchemaComplexType xmlSchemaComplexType = new XmlSchemaComplexType();
		XmlSchemaSequence xmlSchemaSequence = new XmlSchemaSequence();
		XmlSchemaAny xmlSchemaAny = new XmlSchemaAny();
		xmlSchemaAny.Namespace = orderedBooks.Namespace;
		xmlSchemaSequence.Items.Add(xmlSchemaAny);
		xmlSchemaComplexType.Particle = xmlSchemaSequence;
		XmlSchema schemaSerializable = orderedBooks.GetSchemaSerializable();
		if (xs.Contains(schemaSerializable.TargetNamespace))
		{
			MemoryStream memoryStream = new MemoryStream();
			MemoryStream memoryStream2 = new MemoryStream();
			try
			{
				schemaSerializable.Write(memoryStream);
				IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
				while (enumerator.MoveNext())
				{
					XmlSchema xmlSchema = (XmlSchema)enumerator.Current;
					memoryStream2.SetLength(0L);
					xmlSchema.Write(memoryStream2);
					if (memoryStream.Length == memoryStream2.Length)
					{
						memoryStream.Position = 0L;
						memoryStream2.Position = 0L;
						while (memoryStream.Position != memoryStream.Length && memoryStream.ReadByte() == memoryStream2.ReadByte())
						{
						}
						if (memoryStream.Position == memoryStream.Length)
						{
							return xmlSchemaComplexType;
						}
					}
				}
			}
			finally
			{
				if (memoryStream != null)
				{
					memoryStream.Close();
				}
				if (memoryStream2 != null)
				{
					memoryStream2.Close();
				}
			}
		}
		xs.Add(schemaSerializable);
		return xmlSchemaComplexType;
	}
}
