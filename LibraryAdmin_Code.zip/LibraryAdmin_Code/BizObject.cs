using System;
using System.Collections;
using System.Collections.Generic;
using System.Security.Principal;
using System.Web;
using System.Web.Caching;
public class BizObject
{
	public const int MAXROWS = 10;
	public static Cache Cache
	{
		get
		{
			return HttpContext.Current.Cache;
		}
	}
	protected static IPrincipal CurrentUser
	{
		get
		{
			return HttpContext.Current.User;
		}
	}
	protected static string CurrentUserName
	{
		get
		{
			string result = "";
			if (HttpContext.Current.User.Identity.IsAuthenticated)
			{
				result = HttpContext.Current.User.Identity.Name;
			}
			return result;
		}
	}
	protected static int GetPageIndex(int startRowIndex, int maximunRows)
	{
		if (maximunRows <= 0)
		{
			return 0;
		}
		return (int)Math.Floor((double)startRowIndex / (double)maximunRows);
	}
	protected static string EncodeText(string content)
	{
		content = HttpUtility.HtmlEncode(content);
		content = content.Replace(" ", "&nbsp;&nbsp;").Replace("\n", "<br>");
		return content;
	}
	protected static string ConvertNullToEmptyString(string input)
	{
		if (input != null)
		{
			return input;
		}
		return "";
	}
	public static void PurgeCacheItems(string prefix)
	{
		prefix = prefix.ToLower();
		List<string> list = new List<string>();
		IDictionaryEnumerator enumerator = BizObject.Cache.GetEnumerator();
		while (enumerator.MoveNext())
		{
			if (enumerator.Key.ToString().ToLower().StartsWith(prefix))
			{
				list.Add(enumerator.Key.ToString());
			}
		}
		foreach (string current in list)
		{
			BizObject.Cache.Remove(current);
		}
	}
}
