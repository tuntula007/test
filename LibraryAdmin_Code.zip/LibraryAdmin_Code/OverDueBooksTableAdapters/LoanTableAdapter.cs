using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics;
namespace OverDueBooksTableAdapters
{
	[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0"), DataObject(true), HelpKeyword("vs.data.TableAdapter"), Designer("Microsoft.VSDesigner.DataSource.Design.TableAdapterDesigner, Microsoft.VSDesigner, Version=8.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a"), DesignerCategory("code"), ToolboxItem(true)]
	public class LoanTableAdapter : Component
	{
		private SqlDataAdapter _adapter;
		private SqlConnection _connection;
		private SqlCommand[] _commandCollection;
		private bool _clearBeforeFill;
		[DebuggerNonUserCode]
		private SqlDataAdapter Adapter
		{
			get
			{
				if (this._adapter == null)
				{
					this.InitAdapter();
				}
				return this._adapter;
			}
		}
		[DebuggerNonUserCode]
		internal SqlConnection Connection
		{
			get
			{
				if (this._connection == null)
				{
					this.InitConnection();
				}
				return this._connection;
			}
			set
			{
				this._connection = value;
				if (this.Adapter.InsertCommand != null)
				{
					this.Adapter.InsertCommand.Connection = value;
				}
				if (this.Adapter.DeleteCommand != null)
				{
					this.Adapter.DeleteCommand.Connection = value;
				}
				if (this.Adapter.UpdateCommand != null)
				{
					this.Adapter.UpdateCommand.Connection = value;
				}
				for (int i = 0; i < this.CommandCollection.Length; i++)
				{
					if (this.CommandCollection[i] != null)
					{
						this.CommandCollection[i].Connection = value;
					}
				}
			}
		}
		[DebuggerNonUserCode]
		protected SqlCommand[] CommandCollection
		{
			get
			{
				if (this._commandCollection == null)
				{
					this.InitCommandCollection();
				}
				return this._commandCollection;
			}
		}
		[DebuggerNonUserCode]
		public bool ClearBeforeFill
		{
			get
			{
				return this._clearBeforeFill;
			}
			set
			{
				this._clearBeforeFill = value;
			}
		}
		[DebuggerNonUserCode]
		public LoanTableAdapter()
		{
			this.ClearBeforeFill = true;
		}
		[DebuggerNonUserCode]
		private void InitAdapter()
		{
			this._adapter = new SqlDataAdapter();
			DataTableMapping dataTableMapping = new DataTableMapping();
			dataTableMapping.SourceTable = "Table";
			dataTableMapping.DataSetTable = "Loan";
			dataTableMapping.ColumnMappings.Add("Srn", "Srn");
			dataTableMapping.ColumnMappings.Add("BorrowerId", "BorrowerId");
			dataTableMapping.ColumnMappings.Add("Borrowers", "Borrowers");
			dataTableMapping.ColumnMappings.Add("AccNo", "AccNo");
			dataTableMapping.ColumnMappings.Add("Title", "Title");
			dataTableMapping.ColumnMappings.Add("ISBN", "ISBN");
			dataTableMapping.ColumnMappings.Add("ShelfRef", "ShelfRef");
			dataTableMapping.ColumnMappings.Add("Edition", "Edition");
			dataTableMapping.ColumnMappings.Add("PublishedYear", "PublishedYear");
			dataTableMapping.ColumnMappings.Add("Vol", "Vol");
			dataTableMapping.ColumnMappings.Add("No", "No");
			dataTableMapping.ColumnMappings.Add("imageurl", "imageurl");
			dataTableMapping.ColumnMappings.Add("DateBorrowed", "DateBorrowed");
			dataTableMapping.ColumnMappings.Add("ExpectedRetDate", "ExpectedRetDate");
			dataTableMapping.ColumnMappings.Add("DateReturned", "DateReturned");
			dataTableMapping.ColumnMappings.Add("DaysBorrowed", "DaysBorrowed");
			dataTableMapping.ColumnMappings.Add("Comment", "Comment");
			dataTableMapping.ColumnMappings.Add("RetStatus", "RetStatus");
			dataTableMapping.ColumnMappings.Add("BookIssuer", "BookIssuer");
			dataTableMapping.ColumnMappings.Add("BookReceiver", "BookReceiver");
			dataTableMapping.ColumnMappings.Add("Author", "Author");
			this._adapter.TableMappings.Add(dataTableMapping);
			this._adapter.InsertCommand = new SqlCommand();
			this._adapter.InsertCommand.Connection = this.Connection;
			this._adapter.InsertCommand.CommandText = "INSERT INTO [dbo].[Loan] ([BorrowerId], [Borrowers], [AccNo], [Title], [ISBN], [ShelfRef], [Edition], [PublishedYear], [Vol], [No], [imageurl], [DateBorrowed], [ExpectedRetDate], [DateReturned], [DaysBorrowed], [Comment], [RetStatus], [BookIssuer], [BookReceiver], [Author]) VALUES (@BorrowerId, @Borrowers, @AccNo, @Title, @ISBN, @ShelfRef, @Edition, @PublishedYear, @Vol, @No, @imageurl, @DateBorrowed, @ExpectedRetDate, @DateReturned, @DaysBorrowed, @Comment, @RetStatus, @BookIssuer, @BookReceiver, @Author)";
			this._adapter.InsertCommand.CommandType = CommandType.Text;
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@BorrowerId", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "BorrowerId", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Borrowers", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Borrowers", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@AccNo", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "AccNo", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Title", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@ISBN", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "ISBN", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@ShelfRef", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "ShelfRef", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Edition", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Edition", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@PublishedYear", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "PublishedYear", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Vol", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "Vol", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@No", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "No", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@imageurl", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "imageurl", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@DateBorrowed", SqlDbType.DateTime, 0, ParameterDirection.Input, 0, 0, "DateBorrowed", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@ExpectedRetDate", SqlDbType.DateTime, 0, ParameterDirection.Input, 0, 0, "ExpectedRetDate", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@DateReturned", SqlDbType.DateTime, 0, ParameterDirection.Input, 0, 0, "DateReturned", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@DaysBorrowed", SqlDbType.Decimal, 0, ParameterDirection.Input, 18, 0, "DaysBorrowed", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Comment", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Comment", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@RetStatus", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "RetStatus", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@BookIssuer", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "BookIssuer", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@BookReceiver", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "BookReceiver", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Author", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Author", DataRowVersion.Current, false, null, "", "", ""));
		}
		[DebuggerNonUserCode]
		private void InitConnection()
		{
			this._connection = new SqlConnection();
			this._connection.ConnectionString = ConfigurationManager.ConnectionStrings["LibraryAutomationConnectionString"].ConnectionString;
		}
		[DebuggerNonUserCode]
		private void InitCommandCollection()
		{
			this._commandCollection = new SqlCommand[1];
			this._commandCollection[0] = new SqlCommand();
			this._commandCollection[0].Connection = this.Connection;
			this._commandCollection[0].CommandText = "SELECT Srn, BorrowerId, Borrowers, AccNo, Title, ISBN, ShelfRef, Edition, PublishedYear, Vol, No, imageurl, DateBorrowed, ExpectedRetDate, DateReturned, DaysBorrowed, Comment, RetStatus, BookIssuer, BookReceiver, Author FROM dbo.Loan";
			this._commandCollection[0].CommandType = CommandType.Text;
		}
		[DataObjectMethod(DataObjectMethodType.Fill, true), HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Fill(OverDueBooks.LoanDataTable dataTable)
		{
			this.Adapter.SelectCommand = this.CommandCollection[0];
			if (this.ClearBeforeFill)
			{
				dataTable.Clear();
			}
			return this.Adapter.Fill(dataTable);
		}
		[DataObjectMethod(DataObjectMethodType.Select, true), HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual OverDueBooks.LoanDataTable GetData()
		{
			this.Adapter.SelectCommand = this.CommandCollection[0];
			OverDueBooks.LoanDataTable loanDataTable = new OverDueBooks.LoanDataTable();
			this.Adapter.Fill(loanDataTable);
			return loanDataTable;
		}
		[HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Update(OverDueBooks.LoanDataTable dataTable)
		{
			return this.Adapter.Update(dataTable);
		}
		[HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Update(OverDueBooks dataSet)
		{
			return this.Adapter.Update(dataSet, "Loan");
		}
		[HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Update(DataRow dataRow)
		{
			return this.Adapter.Update(new DataRow[]
			{
				dataRow
			});
		}
		[HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Update(DataRow[] dataRows)
		{
			return this.Adapter.Update(dataRows);
		}
		[DataObjectMethod(DataObjectMethodType.Insert, true), HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Insert(string BorrowerId, string Borrowers, string AccNo, string Title, string ISBN, string ShelfRef, string Edition, string PublishedYear, int? Vol, int? No, string imageurl, DateTime? DateBorrowed, DateTime? ExpectedRetDate, DateTime? DateReturned, decimal? DaysBorrowed, string Comment, int? RetStatus, string BookIssuer, string BookReceiver, string Author)
		{
			if (BorrowerId == null)
			{
				throw new ArgumentNullException("BorrowerId");
			}
			this.Adapter.InsertCommand.Parameters[0].Value = BorrowerId;
			if (Borrowers == null)
			{
				this.Adapter.InsertCommand.Parameters[1].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[1].Value = Borrowers;
			}
			if (AccNo == null)
			{
				this.Adapter.InsertCommand.Parameters[2].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[2].Value = AccNo;
			}
			if (Title == null)
			{
				this.Adapter.InsertCommand.Parameters[3].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[3].Value = Title;
			}
			if (ISBN == null)
			{
				this.Adapter.InsertCommand.Parameters[4].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[4].Value = ISBN;
			}
			if (ShelfRef == null)
			{
				this.Adapter.InsertCommand.Parameters[5].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[5].Value = ShelfRef;
			}
			if (Edition == null)
			{
				this.Adapter.InsertCommand.Parameters[6].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[6].Value = Edition;
			}
			if (PublishedYear == null)
			{
				this.Adapter.InsertCommand.Parameters[7].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[7].Value = PublishedYear;
			}
			if (Vol.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[8].Value = Vol.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[8].Value = DBNull.Value;
			}
			if (No.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[9].Value = No.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[9].Value = DBNull.Value;
			}
			if (imageurl == null)
			{
				this.Adapter.InsertCommand.Parameters[10].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[10].Value = imageurl;
			}
			if (DateBorrowed.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[11].Value = DateBorrowed.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[11].Value = DBNull.Value;
			}
			if (ExpectedRetDate.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[12].Value = ExpectedRetDate.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[12].Value = DBNull.Value;
			}
			if (DateReturned.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[13].Value = DateReturned.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[13].Value = DBNull.Value;
			}
			if (DaysBorrowed.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[14].Value = DaysBorrowed.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[14].Value = DBNull.Value;
			}
			if (Comment == null)
			{
				this.Adapter.InsertCommand.Parameters[15].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[15].Value = Comment;
			}
			if (RetStatus.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[16].Value = RetStatus.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[16].Value = DBNull.Value;
			}
			if (BookIssuer == null)
			{
				this.Adapter.InsertCommand.Parameters[17].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[17].Value = BookIssuer;
			}
			if (BookReceiver == null)
			{
				this.Adapter.InsertCommand.Parameters[18].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[18].Value = BookReceiver;
			}
			if (Author == null)
			{
				this.Adapter.InsertCommand.Parameters[19].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[19].Value = Author;
			}
			ConnectionState state = this.Adapter.InsertCommand.Connection.State;
			if ((this.Adapter.InsertCommand.Connection.State & ConnectionState.Open) != ConnectionState.Open)
			{
				this.Adapter.InsertCommand.Connection.Open();
			}
			int result;
			try
			{
				int num = this.Adapter.InsertCommand.ExecuteNonQuery();
				result = num;
			}
			finally
			{
				if (state == ConnectionState.Closed)
				{
					this.Adapter.InsertCommand.Connection.Close();
				}
			}
			return result;
		}
	}
}
