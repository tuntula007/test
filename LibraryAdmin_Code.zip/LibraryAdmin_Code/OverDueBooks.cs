using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;
[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0"), HelpKeyword("vs.data.DataSet"), DesignerCategory("code"), ToolboxItem(true), XmlRoot("OverDueBooks"), XmlSchemaProvider("GetTypedDataSetSchema")]
[Serializable]
public class OverDueBooks : DataSet
{
	public delegate void LoanRowChangeEventHandler(object sender, OverDueBooks.LoanRowChangeEvent e);
	[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0"), XmlSchemaProvider("GetTypedTableSchema")]
	[Serializable]
	public class LoanDataTable : TypedTableBase<OverDueBooks.LoanRow>
	{
		private DataColumn columnSrn;
		private DataColumn columnBorrowerId;
		private DataColumn columnBorrowers;
		private DataColumn columnAccNo;
		private DataColumn columnTitle;
		private DataColumn columnISBN;
		private DataColumn columnShelfRef;
		private DataColumn columnEdition;
		private DataColumn columnPublishedYear;
		private DataColumn columnVol;
		private DataColumn columnNo;
		private DataColumn columnimageurl;
		private DataColumn columnDateBorrowed;
		private DataColumn columnExpectedRetDate;
		private DataColumn columnDateReturned;
		private DataColumn columnDaysBorrowed;
		private DataColumn columnComment;
		private DataColumn columnRetStatus;
		private DataColumn columnBookIssuer;
		private DataColumn columnBookReceiver;
		private DataColumn columnAuthor;
		public event OverDueBooks.LoanRowChangeEventHandler LoanRowChanging
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.LoanRowChanging = (OverDueBooks.LoanRowChangeEventHandler)Delegate.Combine(this.LoanRowChanging, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.LoanRowChanging = (OverDueBooks.LoanRowChangeEventHandler)Delegate.Remove(this.LoanRowChanging, value);
			}
		}
		public event OverDueBooks.LoanRowChangeEventHandler LoanRowChanged
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.LoanRowChanged = (OverDueBooks.LoanRowChangeEventHandler)Delegate.Combine(this.LoanRowChanged, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.LoanRowChanged = (OverDueBooks.LoanRowChangeEventHandler)Delegate.Remove(this.LoanRowChanged, value);
			}
		}
		public event OverDueBooks.LoanRowChangeEventHandler LoanRowDeleting
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.LoanRowDeleting = (OverDueBooks.LoanRowChangeEventHandler)Delegate.Combine(this.LoanRowDeleting, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.LoanRowDeleting = (OverDueBooks.LoanRowChangeEventHandler)Delegate.Remove(this.LoanRowDeleting, value);
			}
		}
		public event OverDueBooks.LoanRowChangeEventHandler LoanRowDeleted
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.LoanRowDeleted = (OverDueBooks.LoanRowChangeEventHandler)Delegate.Combine(this.LoanRowDeleted, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.LoanRowDeleted = (OverDueBooks.LoanRowChangeEventHandler)Delegate.Remove(this.LoanRowDeleted, value);
			}
		}
		[DebuggerNonUserCode]
		public DataColumn SrnColumn
		{
			get
			{
				return this.columnSrn;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn BorrowerIdColumn
		{
			get
			{
				return this.columnBorrowerId;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn BorrowersColumn
		{
			get
			{
				return this.columnBorrowers;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn AccNoColumn
		{
			get
			{
				return this.columnAccNo;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn TitleColumn
		{
			get
			{
				return this.columnTitle;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn ISBNColumn
		{
			get
			{
				return this.columnISBN;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn ShelfRefColumn
		{
			get
			{
				return this.columnShelfRef;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn EditionColumn
		{
			get
			{
				return this.columnEdition;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn PublishedYearColumn
		{
			get
			{
				return this.columnPublishedYear;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn VolColumn
		{
			get
			{
				return this.columnVol;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn NoColumn
		{
			get
			{
				return this.columnNo;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn imageurlColumn
		{
			get
			{
				return this.columnimageurl;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn DateBorrowedColumn
		{
			get
			{
				return this.columnDateBorrowed;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn ExpectedRetDateColumn
		{
			get
			{
				return this.columnExpectedRetDate;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn DateReturnedColumn
		{
			get
			{
				return this.columnDateReturned;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn DaysBorrowedColumn
		{
			get
			{
				return this.columnDaysBorrowed;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn CommentColumn
		{
			get
			{
				return this.columnComment;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn RetStatusColumn
		{
			get
			{
				return this.columnRetStatus;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn BookIssuerColumn
		{
			get
			{
				return this.columnBookIssuer;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn BookReceiverColumn
		{
			get
			{
				return this.columnBookReceiver;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn AuthorColumn
		{
			get
			{
				return this.columnAuthor;
			}
		}
		[Browsable(false), DebuggerNonUserCode]
		public int Count
		{
			get
			{
				return base.Rows.Count;
			}
		}
		[DebuggerNonUserCode]
		public OverDueBooks.LoanRow this[int index]
		{
			get
			{
				return (OverDueBooks.LoanRow)base.Rows[index];
			}
		}
		[DebuggerNonUserCode]
		public LoanDataTable()
		{
			base.TableName = "Loan";
			this.BeginInit();
			this.InitClass();
			this.EndInit();
		}
		[DebuggerNonUserCode]
		internal LoanDataTable(DataTable table)
		{
			base.TableName = table.TableName;
			if (table.CaseSensitive != table.DataSet.CaseSensitive)
			{
				base.CaseSensitive = table.CaseSensitive;
			}
			if (table.Locale.ToString() != table.DataSet.Locale.ToString())
			{
				base.Locale = table.Locale;
			}
			if (table.Namespace != table.DataSet.Namespace)
			{
				base.Namespace = table.Namespace;
			}
			base.Prefix = table.Prefix;
			base.MinimumCapacity = table.MinimumCapacity;
		}
		[DebuggerNonUserCode]
		protected LoanDataTable(SerializationInfo info, StreamingContext context) : base(info, context)
		{
			this.InitVars();
		}
		[DebuggerNonUserCode]
		public void AddLoanRow(OverDueBooks.LoanRow row)
		{
			base.Rows.Add(row);
		}
		[DebuggerNonUserCode]
		public OverDueBooks.LoanRow AddLoanRow(string BorrowerId, string Borrowers, string AccNo, string Title, string ISBN, string ShelfRef, string Edition, string PublishedYear, int Vol, int No, string imageurl, DateTime DateBorrowed, DateTime ExpectedRetDate, DateTime DateReturned, decimal DaysBorrowed, string Comment, int RetStatus, string BookIssuer, string BookReceiver, string Author)
		{
			OverDueBooks.LoanRow loanRow = (OverDueBooks.LoanRow)base.NewRow();
			object[] itemArray = new object[]
			{
				null,
				BorrowerId,
				Borrowers,
				AccNo,
				Title,
				ISBN,
				ShelfRef,
				Edition,
				PublishedYear,
				Vol,
				No,
				imageurl,
				DateBorrowed,
				ExpectedRetDate,
				DateReturned,
				DaysBorrowed,
				Comment,
				RetStatus,
				BookIssuer,
				BookReceiver,
				Author
			};
			loanRow.ItemArray = itemArray;
			base.Rows.Add(loanRow);
			return loanRow;
		}
		[DebuggerNonUserCode]
		public override DataTable Clone()
		{
			OverDueBooks.LoanDataTable loanDataTable = (OverDueBooks.LoanDataTable)base.Clone();
			loanDataTable.InitVars();
			return loanDataTable;
		}
		[DebuggerNonUserCode]
		protected override DataTable CreateInstance()
		{
			return new OverDueBooks.LoanDataTable();
		}
		[DebuggerNonUserCode]
		internal void InitVars()
		{
			this.columnSrn = base.Columns["Srn"];
			this.columnBorrowerId = base.Columns["BorrowerId"];
			this.columnBorrowers = base.Columns["Borrowers"];
			this.columnAccNo = base.Columns["AccNo"];
			this.columnTitle = base.Columns["Title"];
			this.columnISBN = base.Columns["ISBN"];
			this.columnShelfRef = base.Columns["ShelfRef"];
			this.columnEdition = base.Columns["Edition"];
			this.columnPublishedYear = base.Columns["PublishedYear"];
			this.columnVol = base.Columns["Vol"];
			this.columnNo = base.Columns["No"];
			this.columnimageurl = base.Columns["imageurl"];
			this.columnDateBorrowed = base.Columns["DateBorrowed"];
			this.columnExpectedRetDate = base.Columns["ExpectedRetDate"];
			this.columnDateReturned = base.Columns["DateReturned"];
			this.columnDaysBorrowed = base.Columns["DaysBorrowed"];
			this.columnComment = base.Columns["Comment"];
			this.columnRetStatus = base.Columns["RetStatus"];
			this.columnBookIssuer = base.Columns["BookIssuer"];
			this.columnBookReceiver = base.Columns["BookReceiver"];
			this.columnAuthor = base.Columns["Author"];
		}
		[DebuggerNonUserCode]
		private void InitClass()
		{
			this.columnSrn = new DataColumn("Srn", typeof(decimal), null, MappingType.Element);
			base.Columns.Add(this.columnSrn);
			this.columnBorrowerId = new DataColumn("BorrowerId", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnBorrowerId);
			this.columnBorrowers = new DataColumn("Borrowers", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnBorrowers);
			this.columnAccNo = new DataColumn("AccNo", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnAccNo);
			this.columnTitle = new DataColumn("Title", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnTitle);
			this.columnISBN = new DataColumn("ISBN", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnISBN);
			this.columnShelfRef = new DataColumn("ShelfRef", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnShelfRef);
			this.columnEdition = new DataColumn("Edition", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnEdition);
			this.columnPublishedYear = new DataColumn("PublishedYear", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnPublishedYear);
			this.columnVol = new DataColumn("Vol", typeof(int), null, MappingType.Element);
			base.Columns.Add(this.columnVol);
			this.columnNo = new DataColumn("No", typeof(int), null, MappingType.Element);
			base.Columns.Add(this.columnNo);
			this.columnimageurl = new DataColumn("imageurl", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnimageurl);
			this.columnDateBorrowed = new DataColumn("DateBorrowed", typeof(DateTime), null, MappingType.Element);
			base.Columns.Add(this.columnDateBorrowed);
			this.columnExpectedRetDate = new DataColumn("ExpectedRetDate", typeof(DateTime), null, MappingType.Element);
			base.Columns.Add(this.columnExpectedRetDate);
			this.columnDateReturned = new DataColumn("DateReturned", typeof(DateTime), null, MappingType.Element);
			base.Columns.Add(this.columnDateReturned);
			this.columnDaysBorrowed = new DataColumn("DaysBorrowed", typeof(decimal), null, MappingType.Element);
			base.Columns.Add(this.columnDaysBorrowed);
			this.columnComment = new DataColumn("Comment", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnComment);
			this.columnRetStatus = new DataColumn("RetStatus", typeof(int), null, MappingType.Element);
			base.Columns.Add(this.columnRetStatus);
			this.columnBookIssuer = new DataColumn("BookIssuer", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnBookIssuer);
			this.columnBookReceiver = new DataColumn("BookReceiver", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnBookReceiver);
			this.columnAuthor = new DataColumn("Author", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnAuthor);
			this.columnSrn.AutoIncrement = true;
			this.columnSrn.AutoIncrementSeed = -1L;
			this.columnSrn.AutoIncrementStep = -1L;
			this.columnSrn.AllowDBNull = false;
			this.columnSrn.ReadOnly = true;
			this.columnBorrowerId.AllowDBNull = false;
			this.columnBorrowerId.MaxLength = 50;
			this.columnBorrowers.MaxLength = 50;
			this.columnAccNo.MaxLength = 50;
			this.columnTitle.MaxLength = 250;
			this.columnISBN.MaxLength = 50;
			this.columnShelfRef.MaxLength = 50;
			this.columnEdition.MaxLength = 50;
			this.columnPublishedYear.MaxLength = 50;
			this.columnimageurl.MaxLength = 150;
			this.columnComment.MaxLength = 1000;
			this.columnBookIssuer.MaxLength = 50;
			this.columnBookReceiver.MaxLength = 50;
			this.columnAuthor.MaxLength = 150;
		}
		[DebuggerNonUserCode]
		public OverDueBooks.LoanRow NewLoanRow()
		{
			return (OverDueBooks.LoanRow)base.NewRow();
		}
		[DebuggerNonUserCode]
		protected override DataRow NewRowFromBuilder(DataRowBuilder builder)
		{
			return new OverDueBooks.LoanRow(builder);
		}
		[DebuggerNonUserCode]
		protected override Type GetRowType()
		{
			return typeof(OverDueBooks.LoanRow);
		}
		[DebuggerNonUserCode]
		protected override void OnRowChanged(DataRowChangeEventArgs e)
		{
			base.OnRowChanged(e);
			if (this.LoanRowChanged != null)
			{
				this.LoanRowChanged(this, new OverDueBooks.LoanRowChangeEvent((OverDueBooks.LoanRow)e.Row, e.Action));
			}
		}
		[DebuggerNonUserCode]
		protected override void OnRowChanging(DataRowChangeEventArgs e)
		{
			base.OnRowChanging(e);
			if (this.LoanRowChanging != null)
			{
				this.LoanRowChanging(this, new OverDueBooks.LoanRowChangeEvent((OverDueBooks.LoanRow)e.Row, e.Action));
			}
		}
		[DebuggerNonUserCode]
		protected override void OnRowDeleted(DataRowChangeEventArgs e)
		{
			base.OnRowDeleted(e);
			if (this.LoanRowDeleted != null)
			{
				this.LoanRowDeleted(this, new OverDueBooks.LoanRowChangeEvent((OverDueBooks.LoanRow)e.Row, e.Action));
			}
		}
		[DebuggerNonUserCode]
		protected override void OnRowDeleting(DataRowChangeEventArgs e)
		{
			base.OnRowDeleting(e);
			if (this.LoanRowDeleting != null)
			{
				this.LoanRowDeleting(this, new OverDueBooks.LoanRowChangeEvent((OverDueBooks.LoanRow)e.Row, e.Action));
			}
		}
		[DebuggerNonUserCode]
		public void RemoveLoanRow(OverDueBooks.LoanRow row)
		{
			base.Rows.Remove(row);
		}
		[DebuggerNonUserCode]
		public static XmlSchemaComplexType GetTypedTableSchema(XmlSchemaSet xs)
		{
			XmlSchemaComplexType xmlSchemaComplexType = new XmlSchemaComplexType();
			XmlSchemaSequence xmlSchemaSequence = new XmlSchemaSequence();
			OverDueBooks overDueBooks = new OverDueBooks();
			XmlSchemaAny xmlSchemaAny = new XmlSchemaAny();
			xmlSchemaAny.Namespace = "http://www.w3.org/2001/XMLSchema";
			xmlSchemaAny.MinOccurs = 0m;
			xmlSchemaAny.MaxOccurs = 79228162514264337593543950335m;
			xmlSchemaAny.ProcessContents = XmlSchemaContentProcessing.Lax;
			xmlSchemaSequence.Items.Add(xmlSchemaAny);
			XmlSchemaAny xmlSchemaAny2 = new XmlSchemaAny();
			xmlSchemaAny2.Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1";
			xmlSchemaAny2.MinOccurs = 1m;
			xmlSchemaAny2.ProcessContents = XmlSchemaContentProcessing.Lax;
			xmlSchemaSequence.Items.Add(xmlSchemaAny2);
			XmlSchemaAttribute xmlSchemaAttribute = new XmlSchemaAttribute();
			xmlSchemaAttribute.Name = "namespace";
			xmlSchemaAttribute.FixedValue = overDueBooks.Namespace;
			xmlSchemaComplexType.Attributes.Add(xmlSchemaAttribute);
			XmlSchemaAttribute xmlSchemaAttribute2 = new XmlSchemaAttribute();
			xmlSchemaAttribute2.Name = "tableTypeName";
			xmlSchemaAttribute2.FixedValue = "LoanDataTable";
			xmlSchemaComplexType.Attributes.Add(xmlSchemaAttribute2);
			xmlSchemaComplexType.Particle = xmlSchemaSequence;
			XmlSchema schemaSerializable = overDueBooks.GetSchemaSerializable();
			if (xs.Contains(schemaSerializable.TargetNamespace))
			{
				MemoryStream memoryStream = new MemoryStream();
				MemoryStream memoryStream2 = new MemoryStream();
				try
				{
					schemaSerializable.Write(memoryStream);
					IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
					while (enumerator.MoveNext())
					{
						XmlSchema xmlSchema = (XmlSchema)enumerator.Current;
						memoryStream2.SetLength(0L);
						xmlSchema.Write(memoryStream2);
						if (memoryStream.Length == memoryStream2.Length)
						{
							memoryStream.Position = 0L;
							memoryStream2.Position = 0L;
							while (memoryStream.Position != memoryStream.Length && memoryStream.ReadByte() == memoryStream2.ReadByte())
							{
							}
							if (memoryStream.Position == memoryStream.Length)
							{
								return xmlSchemaComplexType;
							}
						}
					}
				}
				finally
				{
					if (memoryStream != null)
					{
						memoryStream.Close();
					}
					if (memoryStream2 != null)
					{
						memoryStream2.Close();
					}
				}
			}
			xs.Add(schemaSerializable);
			return xmlSchemaComplexType;
		}
	}
	[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0")]
	public class LoanRow : DataRow
	{
		private OverDueBooks.LoanDataTable tableLoan;
		[DebuggerNonUserCode]
		public decimal Srn
		{
			get
			{
				return (decimal)base[this.tableLoan.SrnColumn];
			}
			set
			{
				base[this.tableLoan.SrnColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string BorrowerId
		{
			get
			{
				return (string)base[this.tableLoan.BorrowerIdColumn];
			}
			set
			{
				base[this.tableLoan.BorrowerIdColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Borrowers
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableLoan.BorrowersColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Borrowers' in table 'Loan' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableLoan.BorrowersColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string AccNo
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableLoan.AccNoColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'AccNo' in table 'Loan' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableLoan.AccNoColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Title
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableLoan.TitleColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Title' in table 'Loan' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableLoan.TitleColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string ISBN
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableLoan.ISBNColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'ISBN' in table 'Loan' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableLoan.ISBNColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string ShelfRef
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableLoan.ShelfRefColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'ShelfRef' in table 'Loan' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableLoan.ShelfRefColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Edition
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableLoan.EditionColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Edition' in table 'Loan' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableLoan.EditionColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string PublishedYear
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableLoan.PublishedYearColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'PublishedYear' in table 'Loan' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableLoan.PublishedYearColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public int Vol
		{
			get
			{
				int result;
				try
				{
					result = (int)base[this.tableLoan.VolColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Vol' in table 'Loan' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableLoan.VolColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public int No
		{
			get
			{
				int result;
				try
				{
					result = (int)base[this.tableLoan.NoColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'No' in table 'Loan' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableLoan.NoColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string imageurl
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableLoan.imageurlColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'imageurl' in table 'Loan' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableLoan.imageurlColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public DateTime DateBorrowed
		{
			get
			{
				DateTime result;
				try
				{
					result = (DateTime)base[this.tableLoan.DateBorrowedColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'DateBorrowed' in table 'Loan' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableLoan.DateBorrowedColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public DateTime ExpectedRetDate
		{
			get
			{
				DateTime result;
				try
				{
					result = (DateTime)base[this.tableLoan.ExpectedRetDateColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'ExpectedRetDate' in table 'Loan' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableLoan.ExpectedRetDateColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public DateTime DateReturned
		{
			get
			{
				DateTime result;
				try
				{
					result = (DateTime)base[this.tableLoan.DateReturnedColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'DateReturned' in table 'Loan' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableLoan.DateReturnedColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public decimal DaysBorrowed
		{
			get
			{
				decimal result;
				try
				{
					result = (decimal)base[this.tableLoan.DaysBorrowedColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'DaysBorrowed' in table 'Loan' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableLoan.DaysBorrowedColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Comment
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableLoan.CommentColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Comment' in table 'Loan' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableLoan.CommentColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public int RetStatus
		{
			get
			{
				int result;
				try
				{
					result = (int)base[this.tableLoan.RetStatusColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'RetStatus' in table 'Loan' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableLoan.RetStatusColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string BookIssuer
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableLoan.BookIssuerColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'BookIssuer' in table 'Loan' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableLoan.BookIssuerColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string BookReceiver
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableLoan.BookReceiverColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'BookReceiver' in table 'Loan' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableLoan.BookReceiverColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Author
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableLoan.AuthorColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Author' in table 'Loan' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableLoan.AuthorColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		internal LoanRow(DataRowBuilder rb) : base(rb)
		{
			this.tableLoan = (OverDueBooks.LoanDataTable)base.Table;
		}
		[DebuggerNonUserCode]
		public bool IsBorrowersNull()
		{
			return base.IsNull(this.tableLoan.BorrowersColumn);
		}
		[DebuggerNonUserCode]
		public void SetBorrowersNull()
		{
			base[this.tableLoan.BorrowersColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsAccNoNull()
		{
			return base.IsNull(this.tableLoan.AccNoColumn);
		}
		[DebuggerNonUserCode]
		public void SetAccNoNull()
		{
			base[this.tableLoan.AccNoColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsTitleNull()
		{
			return base.IsNull(this.tableLoan.TitleColumn);
		}
		[DebuggerNonUserCode]
		public void SetTitleNull()
		{
			base[this.tableLoan.TitleColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsISBNNull()
		{
			return base.IsNull(this.tableLoan.ISBNColumn);
		}
		[DebuggerNonUserCode]
		public void SetISBNNull()
		{
			base[this.tableLoan.ISBNColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsShelfRefNull()
		{
			return base.IsNull(this.tableLoan.ShelfRefColumn);
		}
		[DebuggerNonUserCode]
		public void SetShelfRefNull()
		{
			base[this.tableLoan.ShelfRefColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsEditionNull()
		{
			return base.IsNull(this.tableLoan.EditionColumn);
		}
		[DebuggerNonUserCode]
		public void SetEditionNull()
		{
			base[this.tableLoan.EditionColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsPublishedYearNull()
		{
			return base.IsNull(this.tableLoan.PublishedYearColumn);
		}
		[DebuggerNonUserCode]
		public void SetPublishedYearNull()
		{
			base[this.tableLoan.PublishedYearColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsVolNull()
		{
			return base.IsNull(this.tableLoan.VolColumn);
		}
		[DebuggerNonUserCode]
		public void SetVolNull()
		{
			base[this.tableLoan.VolColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsNoNull()
		{
			return base.IsNull(this.tableLoan.NoColumn);
		}
		[DebuggerNonUserCode]
		public void SetNoNull()
		{
			base[this.tableLoan.NoColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsimageurlNull()
		{
			return base.IsNull(this.tableLoan.imageurlColumn);
		}
		[DebuggerNonUserCode]
		public void SetimageurlNull()
		{
			base[this.tableLoan.imageurlColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsDateBorrowedNull()
		{
			return base.IsNull(this.tableLoan.DateBorrowedColumn);
		}
		[DebuggerNonUserCode]
		public void SetDateBorrowedNull()
		{
			base[this.tableLoan.DateBorrowedColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsExpectedRetDateNull()
		{
			return base.IsNull(this.tableLoan.ExpectedRetDateColumn);
		}
		[DebuggerNonUserCode]
		public void SetExpectedRetDateNull()
		{
			base[this.tableLoan.ExpectedRetDateColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsDateReturnedNull()
		{
			return base.IsNull(this.tableLoan.DateReturnedColumn);
		}
		[DebuggerNonUserCode]
		public void SetDateReturnedNull()
		{
			base[this.tableLoan.DateReturnedColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsDaysBorrowedNull()
		{
			return base.IsNull(this.tableLoan.DaysBorrowedColumn);
		}
		[DebuggerNonUserCode]
		public void SetDaysBorrowedNull()
		{
			base[this.tableLoan.DaysBorrowedColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsCommentNull()
		{
			return base.IsNull(this.tableLoan.CommentColumn);
		}
		[DebuggerNonUserCode]
		public void SetCommentNull()
		{
			base[this.tableLoan.CommentColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsRetStatusNull()
		{
			return base.IsNull(this.tableLoan.RetStatusColumn);
		}
		[DebuggerNonUserCode]
		public void SetRetStatusNull()
		{
			base[this.tableLoan.RetStatusColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsBookIssuerNull()
		{
			return base.IsNull(this.tableLoan.BookIssuerColumn);
		}
		[DebuggerNonUserCode]
		public void SetBookIssuerNull()
		{
			base[this.tableLoan.BookIssuerColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsBookReceiverNull()
		{
			return base.IsNull(this.tableLoan.BookReceiverColumn);
		}
		[DebuggerNonUserCode]
		public void SetBookReceiverNull()
		{
			base[this.tableLoan.BookReceiverColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsAuthorNull()
		{
			return base.IsNull(this.tableLoan.AuthorColumn);
		}
		[DebuggerNonUserCode]
		public void SetAuthorNull()
		{
			base[this.tableLoan.AuthorColumn] = Convert.DBNull;
		}
	}
	[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0")]
	public class LoanRowChangeEvent : EventArgs
	{
		private OverDueBooks.LoanRow eventRow;
		private DataRowAction eventAction;
		[DebuggerNonUserCode]
		public OverDueBooks.LoanRow Row
		{
			get
			{
				return this.eventRow;
			}
		}
		[DebuggerNonUserCode]
		public DataRowAction Action
		{
			get
			{
				return this.eventAction;
			}
		}
		[DebuggerNonUserCode]
		public LoanRowChangeEvent(OverDueBooks.LoanRow row, DataRowAction action)
		{
			this.eventRow = row;
			this.eventAction = action;
		}
	}
	private OverDueBooks.LoanDataTable tableLoan;
	private SchemaSerializationMode _schemaSerializationMode = SchemaSerializationMode.IncludeSchema;
	[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Content), DebuggerNonUserCode]
	public OverDueBooks.LoanDataTable Loan
	{
		get
		{
			return this.tableLoan;
		}
	}
	[Browsable(true), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible), DebuggerNonUserCode]
	public override SchemaSerializationMode SchemaSerializationMode
	{
		get
		{
			return this._schemaSerializationMode;
		}
		set
		{
			this._schemaSerializationMode = value;
		}
	}
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden), DebuggerNonUserCode]
	public new DataTableCollection Tables
	{
		get
		{
			return base.Tables;
		}
	}
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden), DebuggerNonUserCode]
	public new DataRelationCollection Relations
	{
		get
		{
			return base.Relations;
		}
	}
	[DebuggerNonUserCode]
	public OverDueBooks()
	{
		base.BeginInit();
		this.InitClass();
		CollectionChangeEventHandler value = new CollectionChangeEventHandler(this.SchemaChanged);
		base.Tables.CollectionChanged += value;
		base.Relations.CollectionChanged += value;
		base.EndInit();
	}
	[DebuggerNonUserCode]
	protected OverDueBooks(SerializationInfo info, StreamingContext context) : base(info, context, false)
	{
		if (base.IsBinarySerialized(info, context))
		{
			this.InitVars(false);
			CollectionChangeEventHandler value = new CollectionChangeEventHandler(this.SchemaChanged);
			this.Tables.CollectionChanged += value;
			this.Relations.CollectionChanged += value;
			return;
		}
		string s = (string)info.GetValue("XmlSchema", typeof(string));
		if (base.DetermineSchemaSerializationMode(info, context) == SchemaSerializationMode.IncludeSchema)
		{
			DataSet dataSet = new DataSet();
			dataSet.ReadXmlSchema(new XmlTextReader(new StringReader(s)));
			if (dataSet.Tables["Loan"] != null)
			{
				base.Tables.Add(new OverDueBooks.LoanDataTable(dataSet.Tables["Loan"]));
			}
			base.DataSetName = dataSet.DataSetName;
			base.Prefix = dataSet.Prefix;
			base.Namespace = dataSet.Namespace;
			base.Locale = dataSet.Locale;
			base.CaseSensitive = dataSet.CaseSensitive;
			base.EnforceConstraints = dataSet.EnforceConstraints;
			base.Merge(dataSet, false, MissingSchemaAction.Add);
			this.InitVars();
		}
		else
		{
			base.ReadXmlSchema(new XmlTextReader(new StringReader(s)));
		}
		base.GetSerializationData(info, context);
		CollectionChangeEventHandler value2 = new CollectionChangeEventHandler(this.SchemaChanged);
		base.Tables.CollectionChanged += value2;
		this.Relations.CollectionChanged += value2;
	}
	[DebuggerNonUserCode]
	protected override void InitializeDerivedDataSet()
	{
		base.BeginInit();
		this.InitClass();
		base.EndInit();
	}
	[DebuggerNonUserCode]
	public override DataSet Clone()
	{
		OverDueBooks overDueBooks = (OverDueBooks)base.Clone();
		overDueBooks.InitVars();
		overDueBooks.SchemaSerializationMode = this.SchemaSerializationMode;
		return overDueBooks;
	}
	[DebuggerNonUserCode]
	protected override bool ShouldSerializeTables()
	{
		return false;
	}
	[DebuggerNonUserCode]
	protected override bool ShouldSerializeRelations()
	{
		return false;
	}
	[DebuggerNonUserCode]
	protected override void ReadXmlSerializable(XmlReader reader)
	{
		if (base.DetermineSchemaSerializationMode(reader) == SchemaSerializationMode.IncludeSchema)
		{
			this.Reset();
			DataSet dataSet = new DataSet();
			dataSet.ReadXml(reader);
			if (dataSet.Tables["Loan"] != null)
			{
				base.Tables.Add(new OverDueBooks.LoanDataTable(dataSet.Tables["Loan"]));
			}
			base.DataSetName = dataSet.DataSetName;
			base.Prefix = dataSet.Prefix;
			base.Namespace = dataSet.Namespace;
			base.Locale = dataSet.Locale;
			base.CaseSensitive = dataSet.CaseSensitive;
			base.EnforceConstraints = dataSet.EnforceConstraints;
			base.Merge(dataSet, false, MissingSchemaAction.Add);
			this.InitVars();
			return;
		}
		base.ReadXml(reader);
		this.InitVars();
	}
	[DebuggerNonUserCode]
	protected override XmlSchema GetSchemaSerializable()
	{
		MemoryStream memoryStream = new MemoryStream();
		base.WriteXmlSchema(new XmlTextWriter(memoryStream, null));
		memoryStream.Position = 0L;
		return XmlSchema.Read(new XmlTextReader(memoryStream), null);
	}
	[DebuggerNonUserCode]
	internal void InitVars()
	{
		this.InitVars(true);
	}
	[DebuggerNonUserCode]
	internal void InitVars(bool initTable)
	{
		this.tableLoan = (OverDueBooks.LoanDataTable)base.Tables["Loan"];
		if (initTable && this.tableLoan != null)
		{
			this.tableLoan.InitVars();
		}
	}
	[DebuggerNonUserCode]
	private void InitClass()
	{
		base.DataSetName = "OverDueBooks";
		base.Prefix = "";
		base.Namespace = "http://tempuri.org/OverDueBooks.xsd";
		base.EnforceConstraints = true;
		this.SchemaSerializationMode = SchemaSerializationMode.IncludeSchema;
		this.tableLoan = new OverDueBooks.LoanDataTable();
		base.Tables.Add(this.tableLoan);
	}
	[DebuggerNonUserCode]
	private bool ShouldSerializeLoan()
	{
		return false;
	}
	[DebuggerNonUserCode]
	private void SchemaChanged(object sender, CollectionChangeEventArgs e)
	{
		if (e.Action == CollectionChangeAction.Remove)
		{
			this.InitVars();
		}
	}
	[DebuggerNonUserCode]
	public static XmlSchemaComplexType GetTypedDataSetSchema(XmlSchemaSet xs)
	{
		OverDueBooks overDueBooks = new OverDueBooks();
		XmlSchemaComplexType xmlSchemaComplexType = new XmlSchemaComplexType();
		XmlSchemaSequence xmlSchemaSequence = new XmlSchemaSequence();
		XmlSchemaAny xmlSchemaAny = new XmlSchemaAny();
		xmlSchemaAny.Namespace = overDueBooks.Namespace;
		xmlSchemaSequence.Items.Add(xmlSchemaAny);
		xmlSchemaComplexType.Particle = xmlSchemaSequence;
		XmlSchema schemaSerializable = overDueBooks.GetSchemaSerializable();
		if (xs.Contains(schemaSerializable.TargetNamespace))
		{
			MemoryStream memoryStream = new MemoryStream();
			MemoryStream memoryStream2 = new MemoryStream();
			try
			{
				schemaSerializable.Write(memoryStream);
				IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
				while (enumerator.MoveNext())
				{
					XmlSchema xmlSchema = (XmlSchema)enumerator.Current;
					memoryStream2.SetLength(0L);
					xmlSchema.Write(memoryStream2);
					if (memoryStream.Length == memoryStream2.Length)
					{
						memoryStream.Position = 0L;
						memoryStream2.Position = 0L;
						while (memoryStream.Position != memoryStream.Length && memoryStream.ReadByte() == memoryStream2.ReadByte())
						{
						}
						if (memoryStream.Position == memoryStream.Length)
						{
							return xmlSchemaComplexType;
						}
					}
				}
			}
			finally
			{
				if (memoryStream != null)
				{
					memoryStream.Close();
				}
				if (memoryStream2 != null)
				{
					memoryStream2.Close();
				}
			}
		}
		xs.Add(schemaSerializable);
		return xmlSchemaComplexType;
	}
}
