using System;
using System.Data;
using System.Data.OleDb;
public class CSheetname
{
	public string name(string fname)
	{
		string result = "";
		string connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + fname + ";Extended Properties=\"Excel 8.0;HDR=YES;IMEX=0\"";
		OleDbConnection oleDbConnection = null;
		DataTable dataTable = new DataTable();
		oleDbConnection = new OleDbConnection(connectionString);
		oleDbConnection.Open();
		dataTable = oleDbConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
		if (dataTable == null)
		{
			return null;
		}
		string[] array = new string[dataTable.Rows.Count];
		int num = 0;
		foreach (DataRow dataRow in dataTable.Rows)
		{
			array[num] = dataRow["TABLE_NAME"].ToString();
			num++;
		}
		if (array.Length > 0)
		{
			result = array[0].ToString().Replace("$", "");
		}
		oleDbConnection.Dispose();
		oleDbConnection.Close();
		return result;
	}
}
