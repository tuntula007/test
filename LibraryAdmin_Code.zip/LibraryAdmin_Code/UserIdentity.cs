using System;
public class UserIdentity
{
	private string m_Userid;
	private string m_Logintime;
	private string m_Computer;
	private string m_Hostname;
	private string m_IPAddress;
	private string m_FormNo;
	private string m_RegNo;
	private string m_MatricNo;
	private string m_PassportFile;
	private string m_CourseOfStudy;
	private bool m_SchoolFees;
	public string CourseOfStudy
	{
		get
		{
			return this.m_CourseOfStudy;
		}
		set
		{
			this.m_CourseOfStudy = value;
		}
	}
	public string FormNo
	{
		get
		{
			return this.m_FormNo;
		}
		set
		{
			this.m_FormNo = value;
		}
	}
	public string RegNo
	{
		get
		{
			return this.m_RegNo;
		}
		set
		{
			this.m_RegNo = value;
		}
	}
	public string MatricNo
	{
		get
		{
			return this.m_MatricNo;
		}
		set
		{
			this.m_MatricNo = value;
		}
	}
	public string Userid
	{
		get
		{
			return this.m_Userid;
		}
		set
		{
			this.m_Userid = value;
		}
	}
	public string Logintime
	{
		get
		{
			return this.m_Logintime;
		}
		set
		{
			this.m_Logintime = value;
		}
	}
	public string Computer
	{
		get
		{
			return this.m_Computer;
		}
		set
		{
			this.m_Computer = value;
		}
	}
	public string Hostname
	{
		get
		{
			return this.m_Hostname;
		}
		set
		{
			this.m_Hostname = value;
		}
	}
	public string IPAddress
	{
		get
		{
			return this.m_IPAddress;
		}
		set
		{
			this.m_IPAddress = value;
		}
	}
	public string PassportFile
	{
		get
		{
			return this.m_PassportFile;
		}
		set
		{
			this.m_PassportFile = value;
		}
	}
	public bool SchoolFees
	{
		get
		{
			return this.m_SchoolFees;
		}
		set
		{
			this.m_SchoolFees = value;
		}
	}
}
