using System;
using System.Text;
public class CParameters
{
	private StringBuilder parameters = new StringBuilder();
	public void Add(string pName, object pValue)
	{
		this.parameters.Append(pName);
		this.parameters.Append(";");
		this.parameters.Append(pValue);
		this.parameters.Append(";");
	}
	public override string ToString()
	{
		string text = this.parameters.ToString();
		return text.Substring(0, text.Length - 1);
	}
}
