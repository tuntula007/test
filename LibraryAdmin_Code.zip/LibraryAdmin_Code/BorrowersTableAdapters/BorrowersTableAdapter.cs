using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics;
namespace BorrowersTableAdapters
{
	[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0"), DataObject(true), HelpKeyword("vs.data.TableAdapter"), Designer("Microsoft.VSDesigner.DataSource.Design.TableAdapterDesigner, Microsoft.VSDesigner, Version=8.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a"), DesignerCategory("code"), ToolboxItem(true)]
	public class BorrowersTableAdapter : Component
	{
		private SqlDataAdapter _adapter;
		private SqlConnection _connection;
		private SqlCommand[] _commandCollection;
		private bool _clearBeforeFill;
		[DebuggerNonUserCode]
		private SqlDataAdapter Adapter
		{
			get
			{
				if (this._adapter == null)
				{
					this.InitAdapter();
				}
				return this._adapter;
			}
		}
		[DebuggerNonUserCode]
		internal SqlConnection Connection
		{
			get
			{
				if (this._connection == null)
				{
					this.InitConnection();
				}
				return this._connection;
			}
			set
			{
				this._connection = value;
				if (this.Adapter.InsertCommand != null)
				{
					this.Adapter.InsertCommand.Connection = value;
				}
				if (this.Adapter.DeleteCommand != null)
				{
					this.Adapter.DeleteCommand.Connection = value;
				}
				if (this.Adapter.UpdateCommand != null)
				{
					this.Adapter.UpdateCommand.Connection = value;
				}
				for (int i = 0; i < this.CommandCollection.Length; i++)
				{
					if (this.CommandCollection[i] != null)
					{
						this.CommandCollection[i].Connection = value;
					}
				}
			}
		}
		[DebuggerNonUserCode]
		protected SqlCommand[] CommandCollection
		{
			get
			{
				if (this._commandCollection == null)
				{
					this.InitCommandCollection();
				}
				return this._commandCollection;
			}
		}
		[DebuggerNonUserCode]
		public bool ClearBeforeFill
		{
			get
			{
				return this._clearBeforeFill;
			}
			set
			{
				this._clearBeforeFill = value;
			}
		}
		[DebuggerNonUserCode]
		public BorrowersTableAdapter()
		{
			this.ClearBeforeFill = true;
		}
		[DebuggerNonUserCode]
		private void InitAdapter()
		{
			this._adapter = new SqlDataAdapter();
			DataTableMapping dataTableMapping = new DataTableMapping();
			dataTableMapping.SourceTable = "Table";
			dataTableMapping.DataSetTable = "Borrowers";
			dataTableMapping.ColumnMappings.Add("Srn", "Srn");
			dataTableMapping.ColumnMappings.Add("BorrowerID", "BorrowerID");
			dataTableMapping.ColumnMappings.Add("Name", "Name");
			dataTableMapping.ColumnMappings.Add("Email", "Email");
			dataTableMapping.ColumnMappings.Add("Borrowertype", "Borrowertype");
			dataTableMapping.ColumnMappings.Add("Faculty", "Faculty");
			dataTableMapping.ColumnMappings.Add("Department", "Department");
			dataTableMapping.ColumnMappings.Add("DateRegistered", "DateRegistered");
			dataTableMapping.ColumnMappings.Add("Status", "Status");
			dataTableMapping.ColumnMappings.Add("password", "password");
			dataTableMapping.ColumnMappings.Add("Session", "Session");
			dataTableMapping.ColumnMappings.Add("ExpDate", "ExpDate");
			dataTableMapping.ColumnMappings.Add("RenewedDate", "RenewedDate");
			dataTableMapping.ColumnMappings.Add("RenewedStatus", "RenewedStatus");
			dataTableMapping.ColumnMappings.Add("Pixurl", "Pixurl");
			this._adapter.TableMappings.Add(dataTableMapping);
			this._adapter.DeleteCommand = new SqlCommand();
			this._adapter.DeleteCommand.Connection = this.Connection;
			this._adapter.DeleteCommand.CommandText = "DELETE FROM [dbo].[Borrowers] WHERE (([BorrowerID] = @Original_BorrowerID))";
			this._adapter.DeleteCommand.CommandType = CommandType.Text;
			this._adapter.DeleteCommand.Parameters.Add(new SqlParameter("@Original_BorrowerID", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "BorrowerID", DataRowVersion.Original, false, null, "", "", ""));
			this._adapter.InsertCommand = new SqlCommand();
			this._adapter.InsertCommand.Connection = this.Connection;
			this._adapter.InsertCommand.CommandText = "INSERT INTO [dbo].[Borrowers] ([BorrowerID], [Name], [Email], [Borrowertype], [Faculty], [Department], [DateRegistered], [Status], [password], [Session], [ExpDate], [RenewedDate], [RenewedStatus], [Pixurl]) VALUES (@BorrowerID, @Name, @Email, @Borrowertype, @Faculty, @Department, @DateRegistered, @Status, @password, @Session, @ExpDate, @RenewedDate, @RenewedStatus, @Pixurl)";
			this._adapter.InsertCommand.CommandType = CommandType.Text;
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@BorrowerID", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "BorrowerID", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Name", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Name", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Email", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Email", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Borrowertype", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Borrowertype", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Faculty", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Faculty", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Department", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Department", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@DateRegistered", SqlDbType.DateTime, 0, ParameterDirection.Input, 0, 0, "DateRegistered", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Status", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "Status", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@password", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "password", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Session", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Session", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@ExpDate", SqlDbType.DateTime, 0, ParameterDirection.Input, 0, 0, "ExpDate", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@RenewedDate", SqlDbType.DateTime, 0, ParameterDirection.Input, 0, 0, "RenewedDate", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@RenewedStatus", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "RenewedStatus", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Pixurl", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Pixurl", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand = new SqlCommand();
			this._adapter.UpdateCommand.Connection = this.Connection;
			this._adapter.UpdateCommand.CommandText = "UPDATE [dbo].[Borrowers] SET [BorrowerID] = @BorrowerID, [Name] = @Name, [Email] = @Email, [Borrowertype] = @Borrowertype, [Faculty] = @Faculty, [Department] = @Department, [DateRegistered] = @DateRegistered, [Status] = @Status, [password] = @password, [Session] = @Session, [ExpDate] = @ExpDate, [RenewedDate] = @RenewedDate, [RenewedStatus] = @RenewedStatus, [Pixurl] = @Pixurl WHERE (([BorrowerID] = @Original_BorrowerID))";
			this._adapter.UpdateCommand.CommandType = CommandType.Text;
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@BorrowerID", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "BorrowerID", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Name", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Name", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Email", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Email", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Borrowertype", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Borrowertype", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Faculty", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Faculty", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Department", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Department", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@DateRegistered", SqlDbType.DateTime, 0, ParameterDirection.Input, 0, 0, "DateRegistered", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Status", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "Status", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@password", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "password", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Session", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Session", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@ExpDate", SqlDbType.DateTime, 0, ParameterDirection.Input, 0, 0, "ExpDate", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@RenewedDate", SqlDbType.DateTime, 0, ParameterDirection.Input, 0, 0, "RenewedDate", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@RenewedStatus", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "RenewedStatus", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Pixurl", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Pixurl", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Original_BorrowerID", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "BorrowerID", DataRowVersion.Original, false, null, "", "", ""));
		}
		[DebuggerNonUserCode]
		private void InitConnection()
		{
			this._connection = new SqlConnection();
			this._connection.ConnectionString = ConfigurationManager.ConnectionStrings["LibraryAutomationConnectionString"].ConnectionString;
		}
		[DebuggerNonUserCode]
		private void InitCommandCollection()
		{
			this._commandCollection = new SqlCommand[1];
			this._commandCollection[0] = new SqlCommand();
			this._commandCollection[0].Connection = this.Connection;
			this._commandCollection[0].CommandText = "SELECT Srn, BorrowerID, Name, Email, Borrowertype, Faculty, Department, DateRegistered, Status, password, Session, ExpDate, RenewedDate, RenewedStatus, Pixurl FROM dbo.Borrowers";
			this._commandCollection[0].CommandType = CommandType.Text;
		}
		[DataObjectMethod(DataObjectMethodType.Fill, true), HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Fill(Borrowers.BorrowersDataTable dataTable)
		{
			this.Adapter.SelectCommand = this.CommandCollection[0];
			if (this.ClearBeforeFill)
			{
				dataTable.Clear();
			}
			return this.Adapter.Fill(dataTable);
		}
		[DataObjectMethod(DataObjectMethodType.Select, true), HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual Borrowers.BorrowersDataTable GetData()
		{
			this.Adapter.SelectCommand = this.CommandCollection[0];
			Borrowers.BorrowersDataTable borrowersDataTable = new Borrowers.BorrowersDataTable();
			this.Adapter.Fill(borrowersDataTable);
			return borrowersDataTable;
		}
		[HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Update(Borrowers.BorrowersDataTable dataTable)
		{
			return this.Adapter.Update(dataTable);
		}
		[HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Update(Borrowers dataSet)
		{
			return this.Adapter.Update(dataSet, "Borrowers");
		}
		[HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Update(DataRow dataRow)
		{
			return this.Adapter.Update(new DataRow[]
			{
				dataRow
			});
		}
		[HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Update(DataRow[] dataRows)
		{
			return this.Adapter.Update(dataRows);
		}
		[DataObjectMethod(DataObjectMethodType.Delete, true), HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Delete(string Original_BorrowerID)
		{
			if (Original_BorrowerID == null)
			{
				throw new ArgumentNullException("Original_BorrowerID");
			}
			this.Adapter.DeleteCommand.Parameters[0].Value = Original_BorrowerID;
			ConnectionState state = this.Adapter.DeleteCommand.Connection.State;
			if ((this.Adapter.DeleteCommand.Connection.State & ConnectionState.Open) != ConnectionState.Open)
			{
				this.Adapter.DeleteCommand.Connection.Open();
			}
			int result;
			try
			{
				int num = this.Adapter.DeleteCommand.ExecuteNonQuery();
				result = num;
			}
			finally
			{
				if (state == ConnectionState.Closed)
				{
					this.Adapter.DeleteCommand.Connection.Close();
				}
			}
			return result;
		}
		[DataObjectMethod(DataObjectMethodType.Insert, true), HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Insert(string BorrowerID, string Name, string Email, string Borrowertype, string Faculty, string Department, DateTime? DateRegistered, int? Status, string password, string Session, DateTime? ExpDate, DateTime? RenewedDate, int? RenewedStatus, string Pixurl)
		{
			if (BorrowerID == null)
			{
				throw new ArgumentNullException("BorrowerID");
			}
			this.Adapter.InsertCommand.Parameters[0].Value = BorrowerID;
			if (Name == null)
			{
				this.Adapter.InsertCommand.Parameters[1].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[1].Value = Name;
			}
			if (Email == null)
			{
				this.Adapter.InsertCommand.Parameters[2].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[2].Value = Email;
			}
			if (Borrowertype == null)
			{
				this.Adapter.InsertCommand.Parameters[3].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[3].Value = Borrowertype;
			}
			if (Faculty == null)
			{
				this.Adapter.InsertCommand.Parameters[4].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[4].Value = Faculty;
			}
			if (Department == null)
			{
				this.Adapter.InsertCommand.Parameters[5].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[5].Value = Department;
			}
			if (DateRegistered.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[6].Value = DateRegistered.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[6].Value = DBNull.Value;
			}
			if (Status.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[7].Value = Status.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[7].Value = DBNull.Value;
			}
			if (password == null)
			{
				this.Adapter.InsertCommand.Parameters[8].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[8].Value = password;
			}
			if (Session == null)
			{
				this.Adapter.InsertCommand.Parameters[9].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[9].Value = Session;
			}
			if (ExpDate.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[10].Value = ExpDate.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[10].Value = DBNull.Value;
			}
			if (RenewedDate.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[11].Value = RenewedDate.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[11].Value = DBNull.Value;
			}
			if (RenewedStatus.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[12].Value = RenewedStatus.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[12].Value = DBNull.Value;
			}
			if (Pixurl == null)
			{
				this.Adapter.InsertCommand.Parameters[13].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[13].Value = Pixurl;
			}
			ConnectionState state = this.Adapter.InsertCommand.Connection.State;
			if ((this.Adapter.InsertCommand.Connection.State & ConnectionState.Open) != ConnectionState.Open)
			{
				this.Adapter.InsertCommand.Connection.Open();
			}
			int result;
			try
			{
				int num = this.Adapter.InsertCommand.ExecuteNonQuery();
				result = num;
			}
			finally
			{
				if (state == ConnectionState.Closed)
				{
					this.Adapter.InsertCommand.Connection.Close();
				}
			}
			return result;
		}
		[DataObjectMethod(DataObjectMethodType.Update, true), HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Update(string BorrowerID, string Name, string Email, string Borrowertype, string Faculty, string Department, DateTime? DateRegistered, int? Status, string password, string Session, DateTime? ExpDate, DateTime? RenewedDate, int? RenewedStatus, string Pixurl, string Original_BorrowerID)
		{
			if (BorrowerID == null)
			{
				throw new ArgumentNullException("BorrowerID");
			}
			this.Adapter.UpdateCommand.Parameters[0].Value = BorrowerID;
			if (Name == null)
			{
				this.Adapter.UpdateCommand.Parameters[1].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[1].Value = Name;
			}
			if (Email == null)
			{
				this.Adapter.UpdateCommand.Parameters[2].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[2].Value = Email;
			}
			if (Borrowertype == null)
			{
				this.Adapter.UpdateCommand.Parameters[3].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[3].Value = Borrowertype;
			}
			if (Faculty == null)
			{
				this.Adapter.UpdateCommand.Parameters[4].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[4].Value = Faculty;
			}
			if (Department == null)
			{
				this.Adapter.UpdateCommand.Parameters[5].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[5].Value = Department;
			}
			if (DateRegistered.HasValue)
			{
				this.Adapter.UpdateCommand.Parameters[6].Value = DateRegistered.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[6].Value = DBNull.Value;
			}
			if (Status.HasValue)
			{
				this.Adapter.UpdateCommand.Parameters[7].Value = Status.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[7].Value = DBNull.Value;
			}
			if (password == null)
			{
				this.Adapter.UpdateCommand.Parameters[8].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[8].Value = password;
			}
			if (Session == null)
			{
				this.Adapter.UpdateCommand.Parameters[9].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[9].Value = Session;
			}
			if (ExpDate.HasValue)
			{
				this.Adapter.UpdateCommand.Parameters[10].Value = ExpDate.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[10].Value = DBNull.Value;
			}
			if (RenewedDate.HasValue)
			{
				this.Adapter.UpdateCommand.Parameters[11].Value = RenewedDate.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[11].Value = DBNull.Value;
			}
			if (RenewedStatus.HasValue)
			{
				this.Adapter.UpdateCommand.Parameters[12].Value = RenewedStatus.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[12].Value = DBNull.Value;
			}
			if (Pixurl == null)
			{
				this.Adapter.UpdateCommand.Parameters[13].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[13].Value = Pixurl;
			}
			if (Original_BorrowerID == null)
			{
				throw new ArgumentNullException("Original_BorrowerID");
			}
			this.Adapter.UpdateCommand.Parameters[14].Value = Original_BorrowerID;
			ConnectionState state = this.Adapter.UpdateCommand.Connection.State;
			if ((this.Adapter.UpdateCommand.Connection.State & ConnectionState.Open) != ConnectionState.Open)
			{
				this.Adapter.UpdateCommand.Connection.Open();
			}
			int result;
			try
			{
				int num = this.Adapter.UpdateCommand.ExecuteNonQuery();
				result = num;
			}
			finally
			{
				if (state == ConnectionState.Closed)
				{
					this.Adapter.UpdateCommand.Connection.Close();
				}
			}
			return result;
		}
		[DataObjectMethod(DataObjectMethodType.Update, true), HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Update(string Name, string Email, string Borrowertype, string Faculty, string Department, DateTime? DateRegistered, int? Status, string password, string Session, DateTime? ExpDate, DateTime? RenewedDate, int? RenewedStatus, string Pixurl, string Original_BorrowerID)
		{
			return this.Update(Original_BorrowerID, Name, Email, Borrowertype, Faculty, Department, DateRegistered, Status, password, Session, ExpDate, RenewedDate, RenewedStatus, Pixurl, Original_BorrowerID);
		}
	}
}
