using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
public class DBAccess : BaseBusiness, IDisposable
{
	private IDbCommand cmd = new SqlCommand();
	private string strConnectionString = "";
	private bool handleErrors;
	private string strLastError = "";
	private SqlConnection conn = new SqlConnection();
	private string key = "";
	public string CommandText
	{
		get
		{
			return this.cmd.CommandText;
		}
		set
		{
			this.cmd.CommandText = value;
			this.cmd.Parameters.Clear();
		}
	}
	public IDataParameterCollection Parameters
	{
		get
		{
			return this.cmd.Parameters;
		}
	}
	public string ConnectionString
	{
		get
		{
			return this.strConnectionString;
		}
		set
		{
			this.strConnectionString = value;
		}
	}
	public bool HandleExceptions
	{
		get
		{
			return this.handleErrors;
		}
		set
		{
			this.handleErrors = value;
		}
	}
	public string LastError
	{
		get
		{
			return this.strLastError;
		}
	}
	public DBAccess()
	{
		string connectionString = ConfigurationManager.AppSettings["conn"];
		SqlConnection sqlConnection = new SqlConnection();
		sqlConnection.ConnectionString = connectionString;
		this.cmd.Connection = sqlConnection;
		this.cmd.CommandType = CommandType.StoredProcedure;
		this.conn.ConnectionString = connectionString;
	}
	public DBAccess(string cachekey)
	{
		this.key = cachekey;
		string connectionString = ConfigurationManager.AppSettings["ConnString"];
		SqlConnection sqlConnection = new SqlConnection();
		sqlConnection.ConnectionString = connectionString;
		this.cmd.Connection = sqlConnection;
		this.cmd.CommandType = CommandType.StoredProcedure;
		this.conn.ConnectionString = connectionString;
	}
	public DBAccess(int k1, int k2)
	{
		string connectionString = ConfigurationManager.AppSettings["ConnString"];
		SqlConnection sqlConnection = new SqlConnection();
		sqlConnection.ConnectionString = connectionString;
		this.cmd.Connection = sqlConnection;
		this.cmd.CommandType = CommandType.Text;
		this.conn.ConnectionString = connectionString;
	}
	public DBAccess(int k)
	{
		string connectionString = ConfigurationManager.AppSettings["PortalConnString"];
		SqlConnection sqlConnection = new SqlConnection();
		sqlConnection.ConnectionString = connectionString;
		this.cmd.Connection = sqlConnection;
		this.cmd.CommandType = CommandType.StoredProcedure;
		this.conn.ConnectionString = connectionString;
	}
	public IDataReader ExecuteReader()
	{
		IDataReader result = null;
		try
		{
			this.Open();
			result = this.cmd.ExecuteReader(CommandBehavior.CloseConnection);
		}
		catch (Exception ex)
		{
			if (!this.handleErrors)
			{
				throw;
			}
			this.strLastError = ex.Message;
		}
		return result;
	}
	public IDataReader ExecuteReader(string commandtext)
	{
		IDataReader dataReader = null;
		if (BaseBusiness.enableCache && BizObject.Cache[this.key] != null)
		{
			dataReader = (SqlDataReader)BizObject.Cache[this.key];
		}
		else
		{
			try
			{
				this.cmd.CommandText = commandtext;
				dataReader = this.ExecuteReader();
				SqlDataReader data = (SqlDataReader)dataReader;
				if (!string.IsNullOrEmpty(this.key))
				{
					BaseBusiness.CacheData(this.key, data);
				}
			}
			catch (Exception ex)
			{
				if (!this.handleErrors)
				{
					throw;
				}
				this.strLastError = ex.Message;
			}
		}
		return dataReader;
	}
	public object ExecuteScalar()
	{
		object result = null;
		try
		{
			this.Open();
			result = this.cmd.ExecuteScalar();
			this.Close();
		}
		catch (Exception ex)
		{
			if (!this.handleErrors)
			{
				throw;
			}
			this.strLastError = ex.Message;
		}
		return result;
	}
	public object ExecuteScalar(string commandtext)
	{
		object obj = null;
		if (BaseBusiness.enableCache && BizObject.Cache[this.key] != null)
		{
			obj = BizObject.Cache[this.key];
		}
		else
		{
			try
			{
				this.cmd.CommandText = commandtext;
				obj = this.ExecuteScalar();
				if (!string.IsNullOrEmpty(this.key))
				{
					BaseBusiness.CacheData(this.key, obj);
				}
			}
			catch (Exception ex)
			{
				if (!this.handleErrors)
				{
					throw;
				}
				this.strLastError = ex.Message;
			}
		}
		return obj;
	}
	public int ExecuteNonQuery()
	{
		int result = -1;
		try
		{
			this.Open();
			result = this.cmd.ExecuteNonQuery();
			this.Close();
		}
		catch (Exception ex)
		{
			if (!this.handleErrors)
			{
				throw;
			}
			this.strLastError = ex.Message;
		}
		return result;
	}
	public int ExecuteNonQuery(string commandtext)
	{
		int result = -1;
		try
		{
			this.cmd.CommandText = commandtext;
			this.cmd.CommandTimeout = 1800;
			result = this.ExecuteNonQuery();
		}
		catch (Exception ex)
		{
			if (!this.handleErrors)
			{
				throw;
			}
			this.strLastError = ex.Message;
		}
		return result;
	}
	public DataSet ExecuteDataSet()
	{
		DataSet dataSet = null;
		try
		{
			SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
			sqlDataAdapter.SelectCommand = (SqlCommand)this.cmd;
			dataSet = new DataSet();
			sqlDataAdapter.Fill(dataSet);
		}
		catch (Exception ex)
		{
			if (!this.handleErrors)
			{
				throw;
			}
			this.strLastError = ex.Message;
		}
		return dataSet;
	}
	public DataSet ExecuteDataSet(string commandtext)
	{
		DataSet dataSet = null;
		if (BaseBusiness.enableCache && BizObject.Cache[this.key] != null)
		{
			dataSet = (DataSet)BizObject.Cache[this.key];
		}
		else
		{
			try
			{
				this.cmd.CommandText = commandtext;
				dataSet = this.ExecuteDataSet();
				if (!string.IsNullOrEmpty(this.key))
				{
					BaseBusiness.CacheData(this.key, dataSet);
				}
			}
			catch (Exception ex)
			{
				if (!this.handleErrors)
				{
					throw;
				}
				this.strLastError = ex.Message;
			}
		}
		return dataSet;
	}
	public void AddParameter(string paramname, object paramvalue)
	{
		SqlParameter value = new SqlParameter(paramname, paramvalue);
		this.cmd.Parameters.Add(value);
	}
	public void AddParameter(IDataParameter param)
	{
		this.cmd.Parameters.Add(param);
	}
	private void Open()
	{
		this.cmd.Connection.Open();
	}
	private void Close()
	{
		this.cmd.Connection.Close();
	}
	public void Dispose()
	{
		this.cmd.Dispose();
	}
	public SqlCommand OpenCommand(string sql)
	{
		this.conn.Open();
		return new SqlCommand(sql, this.conn);
	}
	public void setPara(SqlCommand cmd, string paraName, SqlDbType paraType, object paraValue)
	{
		cmd.Parameters.Add(paraName, paraType);
		cmd.Parameters[paraName].Value = paraValue;
	}
}
