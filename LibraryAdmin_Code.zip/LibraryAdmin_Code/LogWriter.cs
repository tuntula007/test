using AuditLogInfo;
using System;
using System.Configuration;
using System.Messaging;
public class LogWriter
{
	private string AuditLogPath = "";
	public LogWriter()
	{
		this.AuditLogPath = ".\\Private$\\" + ConfigurationManager.AppSettings["Auditlog"];
	}
	public void sendtoAuditQ(AuditInfo auditInfo)
	{
		try
		{
			DefaultPropertiesToSend defaultPropertiesToSend = new DefaultPropertiesToSend();
			defaultPropertiesToSend.AttachSenderId = true;
			defaultPropertiesToSend.Recoverable = true;
			MessageQueue messageQueue;
			if (!MessageQueue.Exists(this.AuditLogPath))
			{
				messageQueue = MessageQueue.Create(this.AuditLogPath);
				messageQueue.SetPermissions("Everyone", MessageQueueAccessRights.FullControl);
			}
			else
			{
				messageQueue = new MessageQueue(this.AuditLogPath);
				messageQueue.Formatter = new XmlMessageFormatter(new Type[]
				{
					typeof(AuditInfo)
				});
				messageQueue.DefaultPropertiesToSend = defaultPropertiesToSend;
			}
			messageQueue.DefaultPropertiesToSend.Recoverable = true;
			messageQueue.DefaultPropertiesToSend.AttachSenderId = true;
			messageQueue.DefaultPropertiesToSend.Label = string.Concat(new string[]
			{
				DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"),
				" ",
				auditInfo.Action,
				";",
				auditInfo.Logintime
			});
			messageQueue.Send(auditInfo);
			messageQueue.Dispose();
			messageQueue.Close();
		}
		catch (Exception)
		{
		}
	}
}
