using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;
[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0"), HelpKeyword("vs.data.DataSet"), DesignerCategory("code"), ToolboxItem(true), XmlRoot("Borrowers"), XmlSchemaProvider("GetTypedDataSetSchema")]
[Serializable]
public class Borrowers : DataSet
{
	public delegate void BorrowersRowChangeEventHandler(object sender, Borrowers.BorrowersRowChangeEvent e);
	[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0"), XmlSchemaProvider("GetTypedTableSchema")]
	[Serializable]
	public class BorrowersDataTable : TypedTableBase<Borrowers.BorrowersRow>
	{
		private DataColumn columnSrn;
		private DataColumn columnBorrowerID;
		private DataColumn columnName;
		private DataColumn columnEmail;
		private DataColumn columnBorrowertype;
		private DataColumn columnFaculty;
		private DataColumn columnDepartment;
		private DataColumn columnDateRegistered;
		private DataColumn columnStatus;
		private DataColumn columnpassword;
		private DataColumn columnSession;
		private DataColumn columnExpDate;
		private DataColumn columnRenewedDate;
		private DataColumn columnRenewedStatus;
		private DataColumn columnPixurl;
		private DataColumn columnPassport;
		public event Borrowers.BorrowersRowChangeEventHandler BorrowersRowChanging
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.BorrowersRowChanging = (Borrowers.BorrowersRowChangeEventHandler)Delegate.Combine(this.BorrowersRowChanging, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.BorrowersRowChanging = (Borrowers.BorrowersRowChangeEventHandler)Delegate.Remove(this.BorrowersRowChanging, value);
			}
		}
		public event Borrowers.BorrowersRowChangeEventHandler BorrowersRowChanged
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.BorrowersRowChanged = (Borrowers.BorrowersRowChangeEventHandler)Delegate.Combine(this.BorrowersRowChanged, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.BorrowersRowChanged = (Borrowers.BorrowersRowChangeEventHandler)Delegate.Remove(this.BorrowersRowChanged, value);
			}
		}
		public event Borrowers.BorrowersRowChangeEventHandler BorrowersRowDeleting
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.BorrowersRowDeleting = (Borrowers.BorrowersRowChangeEventHandler)Delegate.Combine(this.BorrowersRowDeleting, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.BorrowersRowDeleting = (Borrowers.BorrowersRowChangeEventHandler)Delegate.Remove(this.BorrowersRowDeleting, value);
			}
		}
		public event Borrowers.BorrowersRowChangeEventHandler BorrowersRowDeleted
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.BorrowersRowDeleted = (Borrowers.BorrowersRowChangeEventHandler)Delegate.Combine(this.BorrowersRowDeleted, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.BorrowersRowDeleted = (Borrowers.BorrowersRowChangeEventHandler)Delegate.Remove(this.BorrowersRowDeleted, value);
			}
		}
		[DebuggerNonUserCode]
		public DataColumn SrnColumn
		{
			get
			{
				return this.columnSrn;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn BorrowerIDColumn
		{
			get
			{
				return this.columnBorrowerID;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn NameColumn
		{
			get
			{
				return this.columnName;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn EmailColumn
		{
			get
			{
				return this.columnEmail;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn BorrowertypeColumn
		{
			get
			{
				return this.columnBorrowertype;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn FacultyColumn
		{
			get
			{
				return this.columnFaculty;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn DepartmentColumn
		{
			get
			{
				return this.columnDepartment;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn DateRegisteredColumn
		{
			get
			{
				return this.columnDateRegistered;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn StatusColumn
		{
			get
			{
				return this.columnStatus;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn passwordColumn
		{
			get
			{
				return this.columnpassword;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn SessionColumn
		{
			get
			{
				return this.columnSession;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn ExpDateColumn
		{
			get
			{
				return this.columnExpDate;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn RenewedDateColumn
		{
			get
			{
				return this.columnRenewedDate;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn RenewedStatusColumn
		{
			get
			{
				return this.columnRenewedStatus;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn PixurlColumn
		{
			get
			{
				return this.columnPixurl;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn PassportColumn
		{
			get
			{
				return this.columnPassport;
			}
		}
		[Browsable(false), DebuggerNonUserCode]
		public int Count
		{
			get
			{
				return base.Rows.Count;
			}
		}
		[DebuggerNonUserCode]
		public Borrowers.BorrowersRow this[int index]
		{
			get
			{
				return (Borrowers.BorrowersRow)base.Rows[index];
			}
		}
		[DebuggerNonUserCode]
		public BorrowersDataTable()
		{
			base.TableName = "Borrowers";
			this.BeginInit();
			this.InitClass();
			this.EndInit();
		}
		[DebuggerNonUserCode]
		internal BorrowersDataTable(DataTable table)
		{
			base.TableName = table.TableName;
			if (table.CaseSensitive != table.DataSet.CaseSensitive)
			{
				base.CaseSensitive = table.CaseSensitive;
			}
			if (table.Locale.ToString() != table.DataSet.Locale.ToString())
			{
				base.Locale = table.Locale;
			}
			if (table.Namespace != table.DataSet.Namespace)
			{
				base.Namespace = table.Namespace;
			}
			base.Prefix = table.Prefix;
			base.MinimumCapacity = table.MinimumCapacity;
		}
		[DebuggerNonUserCode]
		protected BorrowersDataTable(SerializationInfo info, StreamingContext context) : base(info, context)
		{
			this.InitVars();
		}
		[DebuggerNonUserCode]
		public void AddBorrowersRow(Borrowers.BorrowersRow row)
		{
			base.Rows.Add(row);
		}
		[DebuggerNonUserCode]
		public Borrowers.BorrowersRow AddBorrowersRow(string BorrowerID, string Name, string Email, string Borrowertype, string Faculty, string Department, DateTime DateRegistered, int Status, string password, string Session, DateTime ExpDate, DateTime RenewedDate, int RenewedStatus, string Pixurl, byte[] Passport)
		{
			Borrowers.BorrowersRow borrowersRow = (Borrowers.BorrowersRow)base.NewRow();
			object[] itemArray = new object[]
			{
				null,
				BorrowerID,
				Name,
				Email,
				Borrowertype,
				Faculty,
				Department,
				DateRegistered,
				Status,
				password,
				Session,
				ExpDate,
				RenewedDate,
				RenewedStatus,
				Pixurl,
				Passport
			};
			borrowersRow.ItemArray = itemArray;
			base.Rows.Add(borrowersRow);
			return borrowersRow;
		}
		[DebuggerNonUserCode]
		public Borrowers.BorrowersRow FindByBorrowerID(string BorrowerID)
		{
			return (Borrowers.BorrowersRow)base.Rows.Find(new object[]
			{
				BorrowerID
			});
		}
		[DebuggerNonUserCode]
		public override DataTable Clone()
		{
			Borrowers.BorrowersDataTable borrowersDataTable = (Borrowers.BorrowersDataTable)base.Clone();
			borrowersDataTable.InitVars();
			return borrowersDataTable;
		}
		[DebuggerNonUserCode]
		protected override DataTable CreateInstance()
		{
			return new Borrowers.BorrowersDataTable();
		}
		[DebuggerNonUserCode]
		internal void InitVars()
		{
			this.columnSrn = base.Columns["Srn"];
			this.columnBorrowerID = base.Columns["BorrowerID"];
			this.columnName = base.Columns["Name"];
			this.columnEmail = base.Columns["Email"];
			this.columnBorrowertype = base.Columns["Borrowertype"];
			this.columnFaculty = base.Columns["Faculty"];
			this.columnDepartment = base.Columns["Department"];
			this.columnDateRegistered = base.Columns["DateRegistered"];
			this.columnStatus = base.Columns["Status"];
			this.columnpassword = base.Columns["password"];
			this.columnSession = base.Columns["Session"];
			this.columnExpDate = base.Columns["ExpDate"];
			this.columnRenewedDate = base.Columns["RenewedDate"];
			this.columnRenewedStatus = base.Columns["RenewedStatus"];
			this.columnPixurl = base.Columns["Pixurl"];
			this.columnPassport = base.Columns["Passport"];
		}
		[DebuggerNonUserCode]
		private void InitClass()
		{
			this.columnSrn = new DataColumn("Srn", typeof(decimal), null, MappingType.Element);
			base.Columns.Add(this.columnSrn);
			this.columnBorrowerID = new DataColumn("BorrowerID", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnBorrowerID);
			this.columnName = new DataColumn("Name", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnName);
			this.columnEmail = new DataColumn("Email", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnEmail);
			this.columnBorrowertype = new DataColumn("Borrowertype", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnBorrowertype);
			this.columnFaculty = new DataColumn("Faculty", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnFaculty);
			this.columnDepartment = new DataColumn("Department", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnDepartment);
			this.columnDateRegistered = new DataColumn("DateRegistered", typeof(DateTime), null, MappingType.Element);
			base.Columns.Add(this.columnDateRegistered);
			this.columnStatus = new DataColumn("Status", typeof(int), null, MappingType.Element);
			base.Columns.Add(this.columnStatus);
			this.columnpassword = new DataColumn("password", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnpassword);
			this.columnSession = new DataColumn("Session", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnSession);
			this.columnExpDate = new DataColumn("ExpDate", typeof(DateTime), null, MappingType.Element);
			base.Columns.Add(this.columnExpDate);
			this.columnRenewedDate = new DataColumn("RenewedDate", typeof(DateTime), null, MappingType.Element);
			base.Columns.Add(this.columnRenewedDate);
			this.columnRenewedStatus = new DataColumn("RenewedStatus", typeof(int), null, MappingType.Element);
			base.Columns.Add(this.columnRenewedStatus);
			this.columnPixurl = new DataColumn("Pixurl", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnPixurl);
			this.columnPassport = new DataColumn("Passport", typeof(byte[]), null, MappingType.Element);
			base.Columns.Add(this.columnPassport);
			base.Constraints.Add(new UniqueConstraint("Constraint1", new DataColumn[]
			{
				this.columnBorrowerID
			}, true));
			this.columnSrn.AutoIncrement = true;
			this.columnSrn.AutoIncrementSeed = -1L;
			this.columnSrn.AutoIncrementStep = -1L;
			this.columnSrn.AllowDBNull = false;
			this.columnSrn.ReadOnly = true;
			this.columnBorrowerID.AllowDBNull = false;
			this.columnBorrowerID.Unique = true;
			this.columnBorrowerID.MaxLength = 50;
			this.columnName.MaxLength = 50;
			this.columnEmail.MaxLength = 50;
			this.columnBorrowertype.MaxLength = 50;
			this.columnFaculty.MaxLength = 50;
			this.columnDepartment.MaxLength = 50;
			this.columnpassword.MaxLength = 50;
			this.columnSession.MaxLength = 50;
			this.columnPixurl.MaxLength = 250;
			base.ExtendedProperties.Add("Generator_TablePropName", "_Borrowers");
			base.ExtendedProperties.Add("Generator_UserTableName", "Borrowers");
		}
		[DebuggerNonUserCode]
		public Borrowers.BorrowersRow NewBorrowersRow()
		{
			return (Borrowers.BorrowersRow)base.NewRow();
		}
		[DebuggerNonUserCode]
		protected override DataRow NewRowFromBuilder(DataRowBuilder builder)
		{
			return new Borrowers.BorrowersRow(builder);
		}
		[DebuggerNonUserCode]
		protected override Type GetRowType()
		{
			return typeof(Borrowers.BorrowersRow);
		}
		[DebuggerNonUserCode]
		protected override void OnRowChanged(DataRowChangeEventArgs e)
		{
			base.OnRowChanged(e);
			if (this.BorrowersRowChanged != null)
			{
				this.BorrowersRowChanged(this, new Borrowers.BorrowersRowChangeEvent((Borrowers.BorrowersRow)e.Row, e.Action));
			}
		}
		[DebuggerNonUserCode]
		protected override void OnRowChanging(DataRowChangeEventArgs e)
		{
			base.OnRowChanging(e);
			if (this.BorrowersRowChanging != null)
			{
				this.BorrowersRowChanging(this, new Borrowers.BorrowersRowChangeEvent((Borrowers.BorrowersRow)e.Row, e.Action));
			}
		}
		[DebuggerNonUserCode]
		protected override void OnRowDeleted(DataRowChangeEventArgs e)
		{
			base.OnRowDeleted(e);
			if (this.BorrowersRowDeleted != null)
			{
				this.BorrowersRowDeleted(this, new Borrowers.BorrowersRowChangeEvent((Borrowers.BorrowersRow)e.Row, e.Action));
			}
		}
		[DebuggerNonUserCode]
		protected override void OnRowDeleting(DataRowChangeEventArgs e)
		{
			base.OnRowDeleting(e);
			if (this.BorrowersRowDeleting != null)
			{
				this.BorrowersRowDeleting(this, new Borrowers.BorrowersRowChangeEvent((Borrowers.BorrowersRow)e.Row, e.Action));
			}
		}
		[DebuggerNonUserCode]
		public void RemoveBorrowersRow(Borrowers.BorrowersRow row)
		{
			base.Rows.Remove(row);
		}
		[DebuggerNonUserCode]
		public static XmlSchemaComplexType GetTypedTableSchema(XmlSchemaSet xs)
		{
			XmlSchemaComplexType xmlSchemaComplexType = new XmlSchemaComplexType();
			XmlSchemaSequence xmlSchemaSequence = new XmlSchemaSequence();
			Borrowers borrowers = new Borrowers();
			XmlSchemaAny xmlSchemaAny = new XmlSchemaAny();
			xmlSchemaAny.Namespace = "http://www.w3.org/2001/XMLSchema";
			xmlSchemaAny.MinOccurs = 0m;
			xmlSchemaAny.MaxOccurs = 79228162514264337593543950335m;
			xmlSchemaAny.ProcessContents = XmlSchemaContentProcessing.Lax;
			xmlSchemaSequence.Items.Add(xmlSchemaAny);
			XmlSchemaAny xmlSchemaAny2 = new XmlSchemaAny();
			xmlSchemaAny2.Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1";
			xmlSchemaAny2.MinOccurs = 1m;
			xmlSchemaAny2.ProcessContents = XmlSchemaContentProcessing.Lax;
			xmlSchemaSequence.Items.Add(xmlSchemaAny2);
			XmlSchemaAttribute xmlSchemaAttribute = new XmlSchemaAttribute();
			xmlSchemaAttribute.Name = "namespace";
			xmlSchemaAttribute.FixedValue = borrowers.Namespace;
			xmlSchemaComplexType.Attributes.Add(xmlSchemaAttribute);
			XmlSchemaAttribute xmlSchemaAttribute2 = new XmlSchemaAttribute();
			xmlSchemaAttribute2.Name = "tableTypeName";
			xmlSchemaAttribute2.FixedValue = "BorrowersDataTable";
			xmlSchemaComplexType.Attributes.Add(xmlSchemaAttribute2);
			xmlSchemaComplexType.Particle = xmlSchemaSequence;
			XmlSchema schemaSerializable = borrowers.GetSchemaSerializable();
			if (xs.Contains(schemaSerializable.TargetNamespace))
			{
				MemoryStream memoryStream = new MemoryStream();
				MemoryStream memoryStream2 = new MemoryStream();
				try
				{
					schemaSerializable.Write(memoryStream);
					IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
					while (enumerator.MoveNext())
					{
						XmlSchema xmlSchema = (XmlSchema)enumerator.Current;
						memoryStream2.SetLength(0L);
						xmlSchema.Write(memoryStream2);
						if (memoryStream.Length == memoryStream2.Length)
						{
							memoryStream.Position = 0L;
							memoryStream2.Position = 0L;
							while (memoryStream.Position != memoryStream.Length && memoryStream.ReadByte() == memoryStream2.ReadByte())
							{
							}
							if (memoryStream.Position == memoryStream.Length)
							{
								return xmlSchemaComplexType;
							}
						}
					}
				}
				finally
				{
					if (memoryStream != null)
					{
						memoryStream.Close();
					}
					if (memoryStream2 != null)
					{
						memoryStream2.Close();
					}
				}
			}
			xs.Add(schemaSerializable);
			return xmlSchemaComplexType;
		}
	}
	[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0")]
	public class BorrowersRow : DataRow
	{
		private Borrowers.BorrowersDataTable tableBorrowers;
		[DebuggerNonUserCode]
		public decimal Srn
		{
			get
			{
				return (decimal)base[this.tableBorrowers.SrnColumn];
			}
			set
			{
				base[this.tableBorrowers.SrnColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string BorrowerID
		{
			get
			{
				return (string)base[this.tableBorrowers.BorrowerIDColumn];
			}
			set
			{
				base[this.tableBorrowers.BorrowerIDColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Name
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBorrowers.NameColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Name' in table 'Borrowers' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBorrowers.NameColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Email
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBorrowers.EmailColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Email' in table 'Borrowers' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBorrowers.EmailColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Borrowertype
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBorrowers.BorrowertypeColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Borrowertype' in table 'Borrowers' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBorrowers.BorrowertypeColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Faculty
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBorrowers.FacultyColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Faculty' in table 'Borrowers' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBorrowers.FacultyColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Department
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBorrowers.DepartmentColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Department' in table 'Borrowers' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBorrowers.DepartmentColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public DateTime DateRegistered
		{
			get
			{
				DateTime result;
				try
				{
					result = (DateTime)base[this.tableBorrowers.DateRegisteredColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'DateRegistered' in table 'Borrowers' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBorrowers.DateRegisteredColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public int Status
		{
			get
			{
				int result;
				try
				{
					result = (int)base[this.tableBorrowers.StatusColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Status' in table 'Borrowers' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBorrowers.StatusColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string password
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBorrowers.passwordColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'password' in table 'Borrowers' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBorrowers.passwordColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Session
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBorrowers.SessionColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Session' in table 'Borrowers' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBorrowers.SessionColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public DateTime ExpDate
		{
			get
			{
				DateTime result;
				try
				{
					result = (DateTime)base[this.tableBorrowers.ExpDateColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'ExpDate' in table 'Borrowers' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBorrowers.ExpDateColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public DateTime RenewedDate
		{
			get
			{
				DateTime result;
				try
				{
					result = (DateTime)base[this.tableBorrowers.RenewedDateColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'RenewedDate' in table 'Borrowers' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBorrowers.RenewedDateColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public int RenewedStatus
		{
			get
			{
				int result;
				try
				{
					result = (int)base[this.tableBorrowers.RenewedStatusColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'RenewedStatus' in table 'Borrowers' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBorrowers.RenewedStatusColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Pixurl
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBorrowers.PixurlColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Pixurl' in table 'Borrowers' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBorrowers.PixurlColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public byte[] Passport
		{
			get
			{
				byte[] result;
				try
				{
					result = (byte[])base[this.tableBorrowers.PassportColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Passport' in table 'Borrowers' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBorrowers.PassportColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		internal BorrowersRow(DataRowBuilder rb) : base(rb)
		{
			this.tableBorrowers = (Borrowers.BorrowersDataTable)base.Table;
		}
		[DebuggerNonUserCode]
		public bool IsNameNull()
		{
			return base.IsNull(this.tableBorrowers.NameColumn);
		}
		[DebuggerNonUserCode]
		public void SetNameNull()
		{
			base[this.tableBorrowers.NameColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsEmailNull()
		{
			return base.IsNull(this.tableBorrowers.EmailColumn);
		}
		[DebuggerNonUserCode]
		public void SetEmailNull()
		{
			base[this.tableBorrowers.EmailColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsBorrowertypeNull()
		{
			return base.IsNull(this.tableBorrowers.BorrowertypeColumn);
		}
		[DebuggerNonUserCode]
		public void SetBorrowertypeNull()
		{
			base[this.tableBorrowers.BorrowertypeColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsFacultyNull()
		{
			return base.IsNull(this.tableBorrowers.FacultyColumn);
		}
		[DebuggerNonUserCode]
		public void SetFacultyNull()
		{
			base[this.tableBorrowers.FacultyColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsDepartmentNull()
		{
			return base.IsNull(this.tableBorrowers.DepartmentColumn);
		}
		[DebuggerNonUserCode]
		public void SetDepartmentNull()
		{
			base[this.tableBorrowers.DepartmentColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsDateRegisteredNull()
		{
			return base.IsNull(this.tableBorrowers.DateRegisteredColumn);
		}
		[DebuggerNonUserCode]
		public void SetDateRegisteredNull()
		{
			base[this.tableBorrowers.DateRegisteredColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsStatusNull()
		{
			return base.IsNull(this.tableBorrowers.StatusColumn);
		}
		[DebuggerNonUserCode]
		public void SetStatusNull()
		{
			base[this.tableBorrowers.StatusColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IspasswordNull()
		{
			return base.IsNull(this.tableBorrowers.passwordColumn);
		}
		[DebuggerNonUserCode]
		public void SetpasswordNull()
		{
			base[this.tableBorrowers.passwordColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsSessionNull()
		{
			return base.IsNull(this.tableBorrowers.SessionColumn);
		}
		[DebuggerNonUserCode]
		public void SetSessionNull()
		{
			base[this.tableBorrowers.SessionColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsExpDateNull()
		{
			return base.IsNull(this.tableBorrowers.ExpDateColumn);
		}
		[DebuggerNonUserCode]
		public void SetExpDateNull()
		{
			base[this.tableBorrowers.ExpDateColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsRenewedDateNull()
		{
			return base.IsNull(this.tableBorrowers.RenewedDateColumn);
		}
		[DebuggerNonUserCode]
		public void SetRenewedDateNull()
		{
			base[this.tableBorrowers.RenewedDateColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsRenewedStatusNull()
		{
			return base.IsNull(this.tableBorrowers.RenewedStatusColumn);
		}
		[DebuggerNonUserCode]
		public void SetRenewedStatusNull()
		{
			base[this.tableBorrowers.RenewedStatusColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsPixurlNull()
		{
			return base.IsNull(this.tableBorrowers.PixurlColumn);
		}
		[DebuggerNonUserCode]
		public void SetPixurlNull()
		{
			base[this.tableBorrowers.PixurlColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsPassportNull()
		{
			return base.IsNull(this.tableBorrowers.PassportColumn);
		}
		[DebuggerNonUserCode]
		public void SetPassportNull()
		{
			base[this.tableBorrowers.PassportColumn] = Convert.DBNull;
		}
	}
	[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0")]
	public class BorrowersRowChangeEvent : EventArgs
	{
		private Borrowers.BorrowersRow eventRow;
		private DataRowAction eventAction;
		[DebuggerNonUserCode]
		public Borrowers.BorrowersRow Row
		{
			get
			{
				return this.eventRow;
			}
		}
		[DebuggerNonUserCode]
		public DataRowAction Action
		{
			get
			{
				return this.eventAction;
			}
		}
		[DebuggerNonUserCode]
		public BorrowersRowChangeEvent(Borrowers.BorrowersRow row, DataRowAction action)
		{
			this.eventRow = row;
			this.eventAction = action;
		}
	}
	private Borrowers.BorrowersDataTable tableBorrowers;
	private SchemaSerializationMode _schemaSerializationMode = SchemaSerializationMode.IncludeSchema;
	[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Content), DebuggerNonUserCode]
	public Borrowers.BorrowersDataTable _Borrowers
	{
		get
		{
			return this.tableBorrowers;
		}
	}
	[Browsable(true), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible), DebuggerNonUserCode]
	public override SchemaSerializationMode SchemaSerializationMode
	{
		get
		{
			return this._schemaSerializationMode;
		}
		set
		{
			this._schemaSerializationMode = value;
		}
	}
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden), DebuggerNonUserCode]
	public new DataTableCollection Tables
	{
		get
		{
			return base.Tables;
		}
	}
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden), DebuggerNonUserCode]
	public new DataRelationCollection Relations
	{
		get
		{
			return base.Relations;
		}
	}
	[DebuggerNonUserCode]
	public Borrowers()
	{
		base.BeginInit();
		this.InitClass();
		CollectionChangeEventHandler value = new CollectionChangeEventHandler(this.SchemaChanged);
		base.Tables.CollectionChanged += value;
		base.Relations.CollectionChanged += value;
		base.EndInit();
	}
	[DebuggerNonUserCode]
	protected Borrowers(SerializationInfo info, StreamingContext context) : base(info, context, false)
	{
		if (base.IsBinarySerialized(info, context))
		{
			this.InitVars(false);
			CollectionChangeEventHandler value = new CollectionChangeEventHandler(this.SchemaChanged);
			this.Tables.CollectionChanged += value;
			this.Relations.CollectionChanged += value;
			return;
		}
		string s = (string)info.GetValue("XmlSchema", typeof(string));
		if (base.DetermineSchemaSerializationMode(info, context) == SchemaSerializationMode.IncludeSchema)
		{
			DataSet dataSet = new DataSet();
			dataSet.ReadXmlSchema(new XmlTextReader(new StringReader(s)));
			if (dataSet.Tables["Borrowers"] != null)
			{
				base.Tables.Add(new Borrowers.BorrowersDataTable(dataSet.Tables["Borrowers"]));
			}
			base.DataSetName = dataSet.DataSetName;
			base.Prefix = dataSet.Prefix;
			base.Namespace = dataSet.Namespace;
			base.Locale = dataSet.Locale;
			base.CaseSensitive = dataSet.CaseSensitive;
			base.EnforceConstraints = dataSet.EnforceConstraints;
			base.Merge(dataSet, false, MissingSchemaAction.Add);
			this.InitVars();
		}
		else
		{
			base.ReadXmlSchema(new XmlTextReader(new StringReader(s)));
		}
		base.GetSerializationData(info, context);
		CollectionChangeEventHandler value2 = new CollectionChangeEventHandler(this.SchemaChanged);
		base.Tables.CollectionChanged += value2;
		this.Relations.CollectionChanged += value2;
	}
	[DebuggerNonUserCode]
	protected override void InitializeDerivedDataSet()
	{
		base.BeginInit();
		this.InitClass();
		base.EndInit();
	}
	[DebuggerNonUserCode]
	public override DataSet Clone()
	{
		Borrowers borrowers = (Borrowers)base.Clone();
		borrowers.InitVars();
		borrowers.SchemaSerializationMode = this.SchemaSerializationMode;
		return borrowers;
	}
	[DebuggerNonUserCode]
	protected override bool ShouldSerializeTables()
	{
		return false;
	}
	[DebuggerNonUserCode]
	protected override bool ShouldSerializeRelations()
	{
		return false;
	}
	[DebuggerNonUserCode]
	protected override void ReadXmlSerializable(XmlReader reader)
	{
		if (base.DetermineSchemaSerializationMode(reader) == SchemaSerializationMode.IncludeSchema)
		{
			this.Reset();
			DataSet dataSet = new DataSet();
			dataSet.ReadXml(reader);
			if (dataSet.Tables["Borrowers"] != null)
			{
				base.Tables.Add(new Borrowers.BorrowersDataTable(dataSet.Tables["Borrowers"]));
			}
			base.DataSetName = dataSet.DataSetName;
			base.Prefix = dataSet.Prefix;
			base.Namespace = dataSet.Namespace;
			base.Locale = dataSet.Locale;
			base.CaseSensitive = dataSet.CaseSensitive;
			base.EnforceConstraints = dataSet.EnforceConstraints;
			base.Merge(dataSet, false, MissingSchemaAction.Add);
			this.InitVars();
			return;
		}
		base.ReadXml(reader);
		this.InitVars();
	}
	[DebuggerNonUserCode]
	protected override XmlSchema GetSchemaSerializable()
	{
		MemoryStream memoryStream = new MemoryStream();
		base.WriteXmlSchema(new XmlTextWriter(memoryStream, null));
		memoryStream.Position = 0L;
		return XmlSchema.Read(new XmlTextReader(memoryStream), null);
	}
	[DebuggerNonUserCode]
	internal void InitVars()
	{
		this.InitVars(true);
	}
	[DebuggerNonUserCode]
	internal void InitVars(bool initTable)
	{
		this.tableBorrowers = (Borrowers.BorrowersDataTable)base.Tables["Borrowers"];
		if (initTable && this.tableBorrowers != null)
		{
			this.tableBorrowers.InitVars();
		}
	}
	[DebuggerNonUserCode]
	private void InitClass()
	{
		base.DataSetName = "Borrowers";
		base.Prefix = "";
		base.Namespace = "http://tempuri.org/Borrowers.xsd";
		base.EnforceConstraints = true;
		this.SchemaSerializationMode = SchemaSerializationMode.IncludeSchema;
		this.tableBorrowers = new Borrowers.BorrowersDataTable();
		base.Tables.Add(this.tableBorrowers);
	}
	[DebuggerNonUserCode]
	private bool ShouldSerialize_Borrowers()
	{
		return false;
	}
	[DebuggerNonUserCode]
	private void SchemaChanged(object sender, CollectionChangeEventArgs e)
	{
		if (e.Action == CollectionChangeAction.Remove)
		{
			this.InitVars();
		}
	}
	[DebuggerNonUserCode]
	public static XmlSchemaComplexType GetTypedDataSetSchema(XmlSchemaSet xs)
	{
		Borrowers borrowers = new Borrowers();
		XmlSchemaComplexType xmlSchemaComplexType = new XmlSchemaComplexType();
		XmlSchemaSequence xmlSchemaSequence = new XmlSchemaSequence();
		XmlSchemaAny xmlSchemaAny = new XmlSchemaAny();
		xmlSchemaAny.Namespace = borrowers.Namespace;
		xmlSchemaSequence.Items.Add(xmlSchemaAny);
		xmlSchemaComplexType.Particle = xmlSchemaSequence;
		XmlSchema schemaSerializable = borrowers.GetSchemaSerializable();
		if (xs.Contains(schemaSerializable.TargetNamespace))
		{
			MemoryStream memoryStream = new MemoryStream();
			MemoryStream memoryStream2 = new MemoryStream();
			try
			{
				schemaSerializable.Write(memoryStream);
				IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
				while (enumerator.MoveNext())
				{
					XmlSchema xmlSchema = (XmlSchema)enumerator.Current;
					memoryStream2.SetLength(0L);
					xmlSchema.Write(memoryStream2);
					if (memoryStream.Length == memoryStream2.Length)
					{
						memoryStream.Position = 0L;
						memoryStream2.Position = 0L;
						while (memoryStream.Position != memoryStream.Length && memoryStream.ReadByte() == memoryStream2.ReadByte())
						{
						}
						if (memoryStream.Position == memoryStream.Length)
						{
							return xmlSchemaComplexType;
						}
					}
				}
			}
			finally
			{
				if (memoryStream != null)
				{
					memoryStream.Close();
				}
				if (memoryStream2 != null)
				{
					memoryStream2.Close();
				}
			}
		}
		xs.Add(schemaSerializable);
		return xmlSchemaComplexType;
	}
}
