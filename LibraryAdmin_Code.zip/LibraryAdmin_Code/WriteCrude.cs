using Cyberspace.ServiceBrocker;
using System;
using System.Messaging;
public class WriteCrude
{
	public void WriteCrudeQ(CSingleAttribute cs, string strCrudqueries)
	{
		try
		{
			DefaultPropertiesToSend defaultPropertiesToSend = new DefaultPropertiesToSend();
			defaultPropertiesToSend.AttachSenderId = true;
			defaultPropertiesToSend.Recoverable = true;
			MessageQueue messageQueue;
			if (!MessageQueue.Exists(strCrudqueries))
			{
				messageQueue = MessageQueue.Create(strCrudqueries);
				messageQueue.SetPermissions("Everyone", MessageQueueAccessRights.FullControl);
			}
			else
			{
				messageQueue = new MessageQueue(strCrudqueries);
				messageQueue.Formatter = new XmlMessageFormatter(new Type[]
				{
					typeof(CSingleAttribute)
				});
				messageQueue.DefaultPropertiesToSend = defaultPropertiesToSend;
			}
			messageQueue.DefaultPropertiesToSend.Recoverable = true;
			messageQueue.DefaultPropertiesToSend.AttachSenderId = true;
			messageQueue.DefaultPropertiesToSend.Label = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + " " + cs.SourceApplication;
			messageQueue.Send(cs);
			messageQueue.Dispose();
			messageQueue.Close();
		}
		catch (Exception)
		{
		}
	}
}
