using System;
namespace CybSoft.Library.Data
{
	public class PolicyNames
	{
		private string names;
		public string Names
		{
			get
			{
				return this.names;
			}
			set
			{
				this.names = value;
			}
		}
	}
}
