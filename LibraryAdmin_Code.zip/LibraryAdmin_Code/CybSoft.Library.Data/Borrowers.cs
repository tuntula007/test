using System;
namespace CybSoft.Library.Data
{
	public class Borrowers
	{
		private string borrowerID;
		private string borrowertype;
		private string session;
		private string expDate;
		private string departmant;
		private string name;
		private byte passport;
		private string faculty;
		private string email;
		private string dateRegistered;
		private string password;
		private string renewedDate;
		private int renewedStatus;
		private int status;
		public string BorrowerID
		{
			get
			{
				return this.borrowerID;
			}
			set
			{
				this.borrowerID = value;
			}
		}
		public string Borrowertype
		{
			get
			{
				return this.borrowertype;
			}
			set
			{
				this.borrowertype = value;
			}
		}
		public string Session
		{
			get
			{
				return this.session;
			}
			set
			{
				this.session = value;
			}
		}
		public string ExpDate
		{
			get
			{
				return this.expDate;
			}
			set
			{
				this.expDate = value;
			}
		}
		public string Departmant
		{
			get
			{
				return this.departmant;
			}
			set
			{
				this.departmant = value;
			}
		}
		public string Name
		{
			get
			{
				return this.name;
			}
			set
			{
				this.name = value;
			}
		}
		public byte Passport
		{
			get
			{
				return this.passport;
			}
			set
			{
				this.passport = value;
			}
		}
		public string Faculty
		{
			get
			{
				return this.faculty;
			}
			set
			{
				this.faculty = value;
			}
		}
		public string RenewedDate
		{
			get
			{
				return this.renewedDate;
			}
			set
			{
				this.renewedDate = value;
			}
		}
		public int RenewedStatus
		{
			get
			{
				return this.renewedStatus;
			}
			set
			{
				this.renewedStatus = value;
			}
		}
		public string Email
		{
			get
			{
				return this.email;
			}
			set
			{
				this.email = value;
			}
		}
		public string DateRegistered
		{
			get
			{
				return this.dateRegistered;
			}
			set
			{
				this.dateRegistered = value;
			}
		}
		public string Password
		{
			get
			{
				return this.password;
			}
			set
			{
				this.password = value;
			}
		}
		public int Status
		{
			get
			{
				return this.status;
			}
			set
			{
				this.status = value;
			}
		}
	}
}
