using System;
namespace CybSoft.Library.Data
{
	public class Shelf
	{
		private string description;
		private string shelfCOde;
		private string shelfName;
		public string Description
		{
			get
			{
				return this.description;
			}
			set
			{
				this.description = value;
			}
		}
		public string ShelfCOde
		{
			get
			{
				return this.shelfCOde;
			}
			set
			{
				this.shelfCOde = value;
			}
		}
		public string ShelfName
		{
			get
			{
				return this.shelfName;
			}
			set
			{
				this.shelfName = value;
			}
		}
		public Shelf Clone()
		{
			return new Shelf
			{
				description = this.Description,
				shelfCOde = this.ShelfCOde,
				shelfName = this.ShelfName
			};
		}
	}
}
