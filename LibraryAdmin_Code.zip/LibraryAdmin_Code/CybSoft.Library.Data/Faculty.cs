using System;
namespace CybSoft.Library.Data
{
	public class Faculty
	{
		private string createdBy;
		private string createdDate;
		private string deanOfFaculty;
		private int facultyID;
		private string facultyName;
		private string facultyPrefix;
		private bool delete;
		public string CreatedBy
		{
			get
			{
				return this.createdBy;
			}
			set
			{
				this.createdBy = value;
			}
		}
		public string CreatedDate
		{
			get
			{
				return this.createdDate;
			}
			set
			{
				this.createdDate = value;
			}
		}
		public string DeanOfFaculty
		{
			get
			{
				return this.deanOfFaculty;
			}
			set
			{
				this.deanOfFaculty = value;
			}
		}
		public int FacultyID
		{
			get
			{
				return this.facultyID;
			}
		}
		public string FacultyName
		{
			get
			{
				return this.facultyName;
			}
			set
			{
				this.facultyName = value;
			}
		}
		public string FacultyPrefix
		{
			get
			{
				return this.facultyPrefix;
			}
			set
			{
				this.facultyPrefix = value;
			}
		}
		public bool Delete
		{
			get
			{
				return this.delete;
			}
			set
			{
				this.delete = value;
			}
		}
		public Faculty Clone()
		{
			return new Faculty
			{
				createdBy = this.CreatedBy,
				createdDate = this.CreatedDate,
				deanOfFaculty = this.DeanOfFaculty,
				facultyID = this.FacultyID,
				facultyName = this.FacultyName,
				facultyPrefix = this.FacultyPrefix
			};
		}
	}
}
