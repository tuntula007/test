using System;
namespace CybSoft.Library.Data
{
	public class Loan
	{
		private string bookCode;
		private string borrower;
		private string comment;
		private string dateBorrowed;
		private string dateReturned;
		private int daysBorrowed;
		private string borrowerId;
		private string expectedRetDate;
		private int retStatus;
		private string bookIssuer;
		private string bookReceiver;
		public string BookCode
		{
			get
			{
				return this.bookCode;
			}
			set
			{
				this.bookCode = value;
			}
		}
		public string Borrower
		{
			get
			{
				return this.borrower;
			}
			set
			{
				this.borrower = value;
			}
		}
		public string Comment
		{
			get
			{
				return this.comment;
			}
			set
			{
				this.comment = value;
			}
		}
		public string DateBorrowed
		{
			get
			{
				return this.dateBorrowed;
			}
			set
			{
				this.dateBorrowed = value;
			}
		}
		public string DateReturned
		{
			get
			{
				return this.dateReturned;
			}
			set
			{
				this.dateReturned = value;
			}
		}
		public int DaysBorrowed
		{
			get
			{
				return this.daysBorrowed;
			}
			set
			{
				this.daysBorrowed = value;
			}
		}
		public string BorrowerId
		{
			get
			{
				return this.borrowerId;
			}
			set
			{
				this.borrowerId = value;
			}
		}
		public string ExpectedRetDate
		{
			get
			{
				return this.expectedRetDate;
			}
			set
			{
				this.expectedRetDate = value;
			}
		}
		public int RetStatus
		{
			get
			{
				return this.retStatus;
			}
			set
			{
				this.retStatus = value;
			}
		}
		public string BookIssuer
		{
			get
			{
				return this.bookIssuer;
			}
			set
			{
				this.bookIssuer = value;
			}
		}
		public string BookReceiver
		{
			get
			{
				return this.bookReceiver;
			}
			set
			{
				this.bookReceiver = value;
			}
		}
	}
}
