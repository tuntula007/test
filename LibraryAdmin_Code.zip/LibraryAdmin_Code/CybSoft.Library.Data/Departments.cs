using System;
namespace CybSoft.Library.Data
{
	public class Departments
	{
		private string departmentCode;
		private int departmentId;
		private string departmentName;
		private string olddepartmentCode;
		private string facultyName;
		private int facultyID;
		private string hod;
		private bool delete;
		public string DepartmentCode
		{
			get
			{
				return this.departmentCode;
			}
			set
			{
				this.departmentCode = value;
			}
		}
		public int DepartmentId
		{
			get
			{
				return this.departmentId;
			}
		}
		public string OlddepartmentCode
		{
			get
			{
				return this.olddepartmentCode;
			}
			set
			{
				this.olddepartmentCode = value;
			}
		}
		public string DepartmentName
		{
			get
			{
				return this.departmentName;
			}
			set
			{
				this.departmentName = value;
			}
		}
		public string FacultyName
		{
			get
			{
				return this.facultyName;
			}
			set
			{
				this.facultyName = value;
			}
		}
		public int FacultyID
		{
			get
			{
				return this.facultyID;
			}
			set
			{
				this.facultyID = value;
			}
		}
		public string Hod
		{
			get
			{
				return this.hod;
			}
			set
			{
				this.hod = value;
			}
		}
		public bool Delete
		{
			get
			{
				return this.delete;
			}
			set
			{
				this.delete = value;
			}
		}
	}
}
