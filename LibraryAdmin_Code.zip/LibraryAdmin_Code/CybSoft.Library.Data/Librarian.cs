using System;
namespace CybSoft.Library.Data
{
	public class Librarian
	{
		private string active;
		private string firstName;
		private string lastName;
		private string password;
		private string userName;
		public string Active
		{
			get
			{
				return this.active;
			}
			set
			{
				this.active = value;
			}
		}
		public string FirstName
		{
			get
			{
				return this.firstName;
			}
			set
			{
				this.firstName = value;
			}
		}
		public string LastName
		{
			get
			{
				return this.lastName;
			}
			set
			{
				this.lastName = value;
			}
		}
		public string Password
		{
			get
			{
				return this.password;
			}
			set
			{
				this.password = value;
			}
		}
		public string UserName
		{
			get
			{
				return this.userName;
			}
			set
			{
				this.userName = value;
			}
		}
		public Librarian Clone()
		{
			return new Librarian
			{
				active = this.Active,
				firstName = this.FirstName,
				lastName = this.LastName,
				password = this.Password,
				userName = this.UserName
			};
		}
	}
}
