using System;
namespace CybSoft.Library.Data
{
	public class Reservation
	{
		private string bookCode;
		private string borrowerID;
		private DateTime dateReserved;
		private string reservationStatus;
		public string BookCode
		{
			get
			{
				return this.bookCode;
			}
			set
			{
				this.bookCode = value;
			}
		}
		public string BorrowerID
		{
			get
			{
				return this.borrowerID;
			}
			set
			{
				this.borrowerID = value;
			}
		}
		public DateTime DateReserved
		{
			get
			{
				return this.dateReserved;
			}
			set
			{
				this.dateReserved = value;
			}
		}
		public string ReservationStatus
		{
			get
			{
				return this.reservationStatus;
			}
			set
			{
				this.reservationStatus = value;
			}
		}
		public Reservation Clone()
		{
			return new Reservation
			{
				bookCode = this.BookCode,
				borrowerID = this.BorrowerID,
				dateReserved = this.DateReserved,
				reservationStatus = this.ReservationStatus
			};
		}
	}
}
