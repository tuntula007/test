using System;
namespace CybSoft.Library.Data
{
	public class BorrowerType
	{
		private string names;
		public string Names
		{
			get
			{
				return this.names;
			}
			set
			{
				this.names = value;
			}
		}
	}
}
