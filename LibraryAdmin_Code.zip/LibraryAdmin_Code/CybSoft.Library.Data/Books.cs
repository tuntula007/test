using System;
namespace CybSoft.Library.Data
{
	public class Books
	{
		private string author;
		private string clasification;
		private string copyright;
		private string image;
		private string iSBN;
		private string otherInfo;
		private string publisher;
		private string title;
		private string setupby;
		private string datesetupby;
		private string imgurl;
		public string Author
		{
			get
			{
				return this.author;
			}
			set
			{
				this.author = value;
			}
		}
		public string Clasification
		{
			get
			{
				return this.clasification;
			}
			set
			{
				this.clasification = value;
			}
		}
		public string Copyright
		{
			get
			{
				return this.copyright;
			}
			set
			{
				this.copyright = value;
			}
		}
		public string Image
		{
			get
			{
				return this.image;
			}
			set
			{
				this.image = value;
			}
		}
		public string ISBN
		{
			get
			{
				return this.iSBN;
			}
			set
			{
				this.iSBN = value;
			}
		}
		public string OtherInfo
		{
			get
			{
				return this.otherInfo;
			}
			set
			{
				this.otherInfo = value;
			}
		}
		public string Publisher
		{
			get
			{
				return this.publisher;
			}
			set
			{
				this.publisher = value;
			}
		}
		public string Title
		{
			get
			{
				return this.title;
			}
			set
			{
				this.title = value;
			}
		}
		public string Setupby
		{
			get
			{
				return this.setupby;
			}
			set
			{
				this.setupby = value;
			}
		}
		public string Datesetupby
		{
			get
			{
				return this.datesetupby;
			}
			set
			{
				this.datesetupby = value;
			}
		}
		public string Imgurl
		{
			get
			{
				return this.imgurl;
			}
			set
			{
				this.imgurl = value;
			}
		}
	}
}
