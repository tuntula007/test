using System;
namespace CybSoft.Library.Data
{
	public class Policy
	{
		private string policyName;
		private string borrowertype;
		private int maxPeriod;
		private string comment;
		private string setupby;
		private string datesetupby;
		private int status;
		public string PolicyName
		{
			get
			{
				return this.policyName;
			}
			set
			{
				this.policyName = value;
			}
		}
		public string Borrowertype
		{
			get
			{
				return this.borrowertype;
			}
			set
			{
				this.borrowertype = value;
			}
		}
		public string Comment
		{
			get
			{
				return this.comment;
			}
			set
			{
				this.comment = value;
			}
		}
		public string Setupby
		{
			get
			{
				return this.setupby;
			}
			set
			{
				this.setupby = value;
			}
		}
		public string Datesetupby
		{
			get
			{
				return this.datesetupby;
			}
			set
			{
				this.datesetupby = value;
			}
		}
		public int MaxPeriod
		{
			get
			{
				return this.maxPeriod;
			}
			set
			{
				this.maxPeriod = value;
			}
		}
	}
}
