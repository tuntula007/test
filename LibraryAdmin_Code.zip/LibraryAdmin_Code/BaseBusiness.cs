using System;
using System.Configuration;
public class BaseBusiness : BizObject
{
	public static bool enableCache = bool.Parse(ConfigurationManager.AppSettings["EnableCaching"]);
	public static bool enableRegCache = bool.Parse(ConfigurationManager.AppSettings["EnableCaching"]);
	public static int cacheDura = int.Parse(ConfigurationManager.AppSettings["CacheDuration"]);
	public static int cacheDuraLong = int.Parse(ConfigurationManager.AppSettings["CacheDuration"]);
	public static void CacheData(string key, object data)
	{
		if (BaseBusiness.enableCache && data != null)
		{
			BizObject.Cache.Insert(key, data, null, DateTime.Now.AddSeconds((double)BaseBusiness.cacheDura), TimeSpan.Zero);
		}
	}
	public static void CacheRegData(string key, object data)
	{
		if (BaseBusiness.enableRegCache && data != null)
		{
			BizObject.Cache.Insert(key, data, null, DateTime.Now.AddSeconds((double)BaseBusiness.cacheDura), TimeSpan.Zero);
		}
	}
	public static void CacheRegData(string key, object data, int cachelonger)
	{
		if (BaseBusiness.enableRegCache && data != null)
		{
			if (cachelonger == 1)
			{
				BizObject.Cache.Insert(key, data, null, DateTime.Now.AddSeconds((double)BaseBusiness.cacheDuraLong), TimeSpan.Zero);
				return;
			}
			BizObject.Cache.Insert(key, data, null, DateTime.Now.AddSeconds((double)cachelonger), TimeSpan.Zero);
		}
	}
}
