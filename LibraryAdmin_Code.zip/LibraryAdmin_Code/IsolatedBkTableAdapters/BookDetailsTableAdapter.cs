using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics;
namespace IsolatedBkTableAdapters
{
	[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0"), DataObject(true), HelpKeyword("vs.data.TableAdapter"), Designer("Microsoft.VSDesigner.DataSource.Design.TableAdapterDesigner, Microsoft.VSDesigner, Version=8.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a"), DesignerCategory("code"), ToolboxItem(true)]
	public class BookDetailsTableAdapter : Component
	{
		private SqlDataAdapter _adapter;
		private SqlConnection _connection;
		private SqlCommand[] _commandCollection;
		private bool _clearBeforeFill;
		[DebuggerNonUserCode]
		private SqlDataAdapter Adapter
		{
			get
			{
				if (this._adapter == null)
				{
					this.InitAdapter();
				}
				return this._adapter;
			}
		}
		[DebuggerNonUserCode]
		internal SqlConnection Connection
		{
			get
			{
				if (this._connection == null)
				{
					this.InitConnection();
				}
				return this._connection;
			}
			set
			{
				this._connection = value;
				if (this.Adapter.InsertCommand != null)
				{
					this.Adapter.InsertCommand.Connection = value;
				}
				if (this.Adapter.DeleteCommand != null)
				{
					this.Adapter.DeleteCommand.Connection = value;
				}
				if (this.Adapter.UpdateCommand != null)
				{
					this.Adapter.UpdateCommand.Connection = value;
				}
				for (int i = 0; i < this.CommandCollection.Length; i++)
				{
					if (this.CommandCollection[i] != null)
					{
						this.CommandCollection[i].Connection = value;
					}
				}
			}
		}
		[DebuggerNonUserCode]
		protected SqlCommand[] CommandCollection
		{
			get
			{
				if (this._commandCollection == null)
				{
					this.InitCommandCollection();
				}
				return this._commandCollection;
			}
		}
		[DebuggerNonUserCode]
		public bool ClearBeforeFill
		{
			get
			{
				return this._clearBeforeFill;
			}
			set
			{
				this._clearBeforeFill = value;
			}
		}
		[DebuggerNonUserCode]
		public BookDetailsTableAdapter()
		{
			this.ClearBeforeFill = true;
		}
		[DebuggerNonUserCode]
		private void InitAdapter()
		{
			this._adapter = new SqlDataAdapter();
			DataTableMapping dataTableMapping = new DataTableMapping();
			dataTableMapping.SourceTable = "Table";
			dataTableMapping.DataSetTable = "BookDetails";
			dataTableMapping.ColumnMappings.Add("Srn", "Srn");
			dataTableMapping.ColumnMappings.Add("OrderNo", "OrderNo");
			dataTableMapping.ColumnMappings.Add("Title", "Title");
			dataTableMapping.ColumnMappings.Add("Author", "Author");
			dataTableMapping.ColumnMappings.Add("Publisher", "Publisher");
			dataTableMapping.ColumnMappings.Add("BookType", "BookType");
			dataTableMapping.ColumnMappings.Add("Dealer", "Dealer");
			dataTableMapping.ColumnMappings.Add("AquisitionType", "AquisitionType");
			dataTableMapping.ColumnMappings.Add("ReceivedGroup", "ReceivedGroup");
			dataTableMapping.ColumnMappings.Add("SetupBy", "SetupBy");
			dataTableMapping.ColumnMappings.Add("Datesetup", "Datesetup");
			dataTableMapping.ColumnMappings.Add("ReceivedStatus", "ReceivedStatus");
			dataTableMapping.ColumnMappings.Add("CatalogStatus", "CatalogStatus");
			dataTableMapping.ColumnMappings.Add("Copies", "Copies");
			dataTableMapping.ColumnMappings.Add("PublishedDate", "PublishedDate");
			dataTableMapping.ColumnMappings.Add("PublishedYear", "PublishedYear");
			dataTableMapping.ColumnMappings.Add("Vol", "Vol");
			dataTableMapping.ColumnMappings.Add("No", "No");
			dataTableMapping.ColumnMappings.Add("Edition", "Edition");
			dataTableMapping.ColumnMappings.Add("Cost", "Cost");
			dataTableMapping.ColumnMappings.Add("TotalCost", "TotalCost");
			dataTableMapping.ColumnMappings.Add("ISBN", "ISBN");
			dataTableMapping.ColumnMappings.Add("ACCNO", "ACCNO");
			dataTableMapping.ColumnMappings.Add("GRNumber", "GRNumber");
			dataTableMapping.ColumnMappings.Add("Availability", "Availability");
			dataTableMapping.ColumnMappings.Add("AccYear", "AccYear");
			dataTableMapping.ColumnMappings.Add("ParallelTitle", "ParallelTitle");
			dataTableMapping.ColumnMappings.Add("Editors", "Editors");
			dataTableMapping.ColumnMappings.Add("Meetings", "Meetings");
			dataTableMapping.ColumnMappings.Add("PubPlace", "PubPlace");
			dataTableMapping.ColumnMappings.Add("ClassNo", "ClassNo");
			dataTableMapping.ColumnMappings.Add("Language", "Language");
			dataTableMapping.ColumnMappings.Add("Binding", "Binding");
			dataTableMapping.ColumnMappings.Add("Pages", "Pages");
			dataTableMapping.ColumnMappings.Add("SpineLabel", "SpineLabel");
			dataTableMapping.ColumnMappings.Add("PubType", "PubType");
			dataTableMapping.ColumnMappings.Add("Medium", "Medium");
			dataTableMapping.ColumnMappings.Add("Abstract", "Abstract");
			dataTableMapping.ColumnMappings.Add("ShelfRef", "ShelfRef");
			dataTableMapping.ColumnMappings.Add("Keywords", "Keywords");
			dataTableMapping.ColumnMappings.Add("Subject", "Subject");
			dataTableMapping.ColumnMappings.Add("LibraryBranch", "LibraryBranch");
			dataTableMapping.ColumnMappings.Add("imageurl", "imageurl");
			dataTableMapping.ColumnMappings.Add("Navigatelink", "Navigatelink");
			dataTableMapping.ColumnMappings.Add("CatLogNo", "CatLogNo");
			dataTableMapping.ColumnMappings.Add("Object", "Object");
			this._adapter.TableMappings.Add(dataTableMapping);
			this._adapter.DeleteCommand = new SqlCommand();
			this._adapter.DeleteCommand.Connection = this.Connection;
			this._adapter.DeleteCommand.CommandText = "DELETE FROM [dbo].[BookDetails] WHERE (([ACCNO] = @Original_ACCNO))";
			this._adapter.DeleteCommand.CommandType = CommandType.Text;
			this._adapter.DeleteCommand.Parameters.Add(new SqlParameter("@Original_ACCNO", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "ACCNO", DataRowVersion.Original, false, null, "", "", ""));
			this._adapter.InsertCommand = new SqlCommand();
			this._adapter.InsertCommand.Connection = this.Connection;
			this._adapter.InsertCommand.CommandText = "INSERT INTO [dbo].[BookDetails] ([OrderNo], [Title], [Author], [Publisher], [BookType], [Dealer], [AquisitionType], [ReceivedGroup], [SetupBy], [Datesetup], [ReceivedStatus], [CatalogStatus], [Copies], [PublishedDate], [PublishedYear], [Vol], [No], [Edition], [Cost], [TotalCost], [ISBN], [ACCNO], [GRNumber], [Availability], [AccYear], [ParallelTitle], [Editors], [Meetings], [PubPlace], [ClassNo], [Language], [Binding], [Pages], [SpineLabel], [PubType], [Medium], [Abstract], [ShelfRef], [Keywords], [Subject], [LibraryBranch], [imageurl], [Navigatelink], [CatLogNo], [Object]) VALUES (@OrderNo, @Title, @Author, @Publisher, @BookType, @Dealer, @AquisitionType, @ReceivedGroup, @SetupBy, @Datesetup, @ReceivedStatus, @CatalogStatus, @Copies, @PublishedDate, @PublishedYear, @Vol, @No, @Edition, @Cost, @TotalCost, @ISBN, @ACCNO, @GRNumber, @Availability, @AccYear, @ParallelTitle, @Editors, @Meetings, @PubPlace, @ClassNo, @Language, @Binding, @Pages, @SpineLabel, @PubType, @Medium, @Abstract, @ShelfRef, @Keywords, @Subject, @LibraryBranch, @imageurl, @Navigatelink, @CatLogNo, @Object)";
			this._adapter.InsertCommand.CommandType = CommandType.Text;
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@OrderNo", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "OrderNo", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Title", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Author", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Author", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Publisher", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Publisher", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@BookType", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "BookType", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Dealer", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Dealer", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@AquisitionType", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "AquisitionType", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@ReceivedGroup", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "ReceivedGroup", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@SetupBy", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "SetupBy", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Datesetup", SqlDbType.DateTime, 0, ParameterDirection.Input, 0, 0, "Datesetup", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@ReceivedStatus", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "ReceivedStatus", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@CatalogStatus", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "CatalogStatus", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Copies", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "Copies", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@PublishedDate", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "PublishedDate", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@PublishedYear", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "PublishedYear", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Vol", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "Vol", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@No", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "No", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Edition", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Edition", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Cost", SqlDbType.Money, 0, ParameterDirection.Input, 0, 0, "Cost", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@TotalCost", SqlDbType.Money, 0, ParameterDirection.Input, 0, 0, "TotalCost", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@ISBN", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "ISBN", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@ACCNO", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "ACCNO", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@GRNumber", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "GRNumber", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Availability", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "Availability", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@AccYear", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "AccYear", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@ParallelTitle", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "ParallelTitle", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Editors", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Editors", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Meetings", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Meetings", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@PubPlace", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "PubPlace", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@ClassNo", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "ClassNo", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Language", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Language", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Binding", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Binding", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Pages", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Pages", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@SpineLabel", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "SpineLabel", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@PubType", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "PubType", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Medium", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Medium", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Abstract", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Abstract", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@ShelfRef", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "ShelfRef", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Keywords", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Keywords", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Subject", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Subject", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@LibraryBranch", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "LibraryBranch", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@imageurl", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "imageurl", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Navigatelink", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Navigatelink", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@CatLogNo", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "CatLogNo", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Object", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Object", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand = new SqlCommand();
			this._adapter.UpdateCommand.Connection = this.Connection;
			this._adapter.UpdateCommand.CommandText = "UPDATE [dbo].[BookDetails] SET [OrderNo] = @OrderNo, [Title] = @Title, [Author] = @Author, [Publisher] = @Publisher, [BookType] = @BookType, [Dealer] = @Dealer, [AquisitionType] = @AquisitionType, [ReceivedGroup] = @ReceivedGroup, [SetupBy] = @SetupBy, [Datesetup] = @Datesetup, [ReceivedStatus] = @ReceivedStatus, [CatalogStatus] = @CatalogStatus, [Copies] = @Copies, [PublishedDate] = @PublishedDate, [PublishedYear] = @PublishedYear, [Vol] = @Vol, [No] = @No, [Edition] = @Edition, [Cost] = @Cost, [TotalCost] = @TotalCost, [ISBN] = @ISBN, [ACCNO] = @ACCNO, [GRNumber] = @GRNumber, [Availability] = @Availability, [AccYear] = @AccYear, [ParallelTitle] = @ParallelTitle, [Editors] = @Editors, [Meetings] = @Meetings, [PubPlace] = @PubPlace, [ClassNo] = @ClassNo, [Language] = @Language, [Binding] = @Binding, [Pages] = @Pages, [SpineLabel] = @SpineLabel, [PubType] = @PubType, [Medium] = @Medium, [Abstract] = @Abstract, [ShelfRef] = @ShelfRef, [Keywords] = @Keywords, [Subject] = @Subject, [LibraryBranch] = @LibraryBranch, [imageurl] = @imageurl, [Navigatelink] = @Navigatelink, [CatLogNo] = @CatLogNo, [Object] = @Object WHERE (([ACCNO] = @Original_ACCNO))";
			this._adapter.UpdateCommand.CommandType = CommandType.Text;
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@OrderNo", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "OrderNo", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Title", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Author", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Author", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Publisher", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Publisher", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@BookType", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "BookType", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Dealer", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Dealer", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@AquisitionType", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "AquisitionType", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@ReceivedGroup", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "ReceivedGroup", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@SetupBy", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "SetupBy", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Datesetup", SqlDbType.DateTime, 0, ParameterDirection.Input, 0, 0, "Datesetup", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@ReceivedStatus", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "ReceivedStatus", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@CatalogStatus", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "CatalogStatus", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Copies", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "Copies", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@PublishedDate", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "PublishedDate", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@PublishedYear", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "PublishedYear", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Vol", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "Vol", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@No", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "No", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Edition", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Edition", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Cost", SqlDbType.Money, 0, ParameterDirection.Input, 0, 0, "Cost", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@TotalCost", SqlDbType.Money, 0, ParameterDirection.Input, 0, 0, "TotalCost", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@ISBN", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "ISBN", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@ACCNO", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "ACCNO", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@GRNumber", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "GRNumber", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Availability", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "Availability", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@AccYear", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "AccYear", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@ParallelTitle", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "ParallelTitle", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Editors", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Editors", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Meetings", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Meetings", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@PubPlace", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "PubPlace", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@ClassNo", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "ClassNo", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Language", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Language", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Binding", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Binding", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Pages", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Pages", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@SpineLabel", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "SpineLabel", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@PubType", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "PubType", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Medium", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Medium", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Abstract", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Abstract", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@ShelfRef", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "ShelfRef", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Keywords", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Keywords", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Subject", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Subject", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@LibraryBranch", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "LibraryBranch", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@imageurl", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "imageurl", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Navigatelink", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Navigatelink", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@CatLogNo", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "CatLogNo", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Object", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Object", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.UpdateCommand.Parameters.Add(new SqlParameter("@Original_ACCNO", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "ACCNO", DataRowVersion.Original, false, null, "", "", ""));
		}
		[DebuggerNonUserCode]
		private void InitConnection()
		{
			this._connection = new SqlConnection();
			this._connection.ConnectionString = ConfigurationManager.ConnectionStrings["LibraryAutomationConnectionString1"].ConnectionString;
		}
		[DebuggerNonUserCode]
		private void InitCommandCollection()
		{
			this._commandCollection = new SqlCommand[1];
			this._commandCollection[0] = new SqlCommand();
			this._commandCollection[0].Connection = this.Connection;
			this._commandCollection[0].CommandText = "SELECT Srn, OrderNo, Title, Author, Publisher, BookType, Dealer, AquisitionType, ReceivedGroup, SetupBy, Datesetup, ReceivedStatus, CatalogStatus, Copies, PublishedDate, PublishedYear, Vol, No, Edition, Cost, TotalCost, ISBN, ACCNO, GRNumber, Availability, AccYear, ParallelTitle, Editors, Meetings, PubPlace, ClassNo, Language, Binding, Pages, SpineLabel, PubType, Medium, Abstract, ShelfRef, Keywords, Subject, LibraryBranch, imageurl, Navigatelink, CatLogNo, Object FROM dbo.BookDetails";
			this._commandCollection[0].CommandType = CommandType.Text;
		}
		[DataObjectMethod(DataObjectMethodType.Fill, true), HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Fill(IsolatedBk.BookDetailsDataTable dataTable)
		{
			this.Adapter.SelectCommand = this.CommandCollection[0];
			if (this.ClearBeforeFill)
			{
				dataTable.Clear();
			}
			return this.Adapter.Fill(dataTable);
		}
		[DataObjectMethod(DataObjectMethodType.Select, true), HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual IsolatedBk.BookDetailsDataTable GetData()
		{
			this.Adapter.SelectCommand = this.CommandCollection[0];
			IsolatedBk.BookDetailsDataTable bookDetailsDataTable = new IsolatedBk.BookDetailsDataTable();
			this.Adapter.Fill(bookDetailsDataTable);
			return bookDetailsDataTable;
		}
		[HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Update(IsolatedBk.BookDetailsDataTable dataTable)
		{
			return this.Adapter.Update(dataTable);
		}
		[HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Update(IsolatedBk dataSet)
		{
			return this.Adapter.Update(dataSet, "BookDetails");
		}
		[HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Update(DataRow dataRow)
		{
			return this.Adapter.Update(new DataRow[]
			{
				dataRow
			});
		}
		[HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Update(DataRow[] dataRows)
		{
			return this.Adapter.Update(dataRows);
		}
		[DataObjectMethod(DataObjectMethodType.Delete, true), HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Delete(string Original_ACCNO)
		{
			if (Original_ACCNO == null)
			{
				throw new ArgumentNullException("Original_ACCNO");
			}
			this.Adapter.DeleteCommand.Parameters[0].Value = Original_ACCNO;
			ConnectionState state = this.Adapter.DeleteCommand.Connection.State;
			if ((this.Adapter.DeleteCommand.Connection.State & ConnectionState.Open) != ConnectionState.Open)
			{
				this.Adapter.DeleteCommand.Connection.Open();
			}
			int result;
			try
			{
				int num = this.Adapter.DeleteCommand.ExecuteNonQuery();
				result = num;
			}
			finally
			{
				if (state == ConnectionState.Closed)
				{
					this.Adapter.DeleteCommand.Connection.Close();
				}
			}
			return result;
		}
		[DataObjectMethod(DataObjectMethodType.Insert, true), HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Insert(string OrderNo, string Title, string Author, string Publisher, string BookType, string Dealer, string AquisitionType, string ReceivedGroup, string SetupBy, DateTime? Datesetup, int ReceivedStatus, int CatalogStatus, int? Copies, string PublishedDate, string PublishedYear, int? Vol, int? No, string Edition, decimal? Cost, decimal? TotalCost, string ISBN, string ACCNO, string GRNumber, int? Availability, string AccYear, string ParallelTitle, string Editors, string Meetings, string PubPlace, string ClassNo, string Language, string Binding, string Pages, string SpineLabel, string PubType, string Medium, string Abstract, string ShelfRef, string Keywords, string Subject, string LibraryBranch, string imageurl, string Navigatelink, string CatLogNo, string Object)
		{
			if (OrderNo == null)
			{
				throw new ArgumentNullException("OrderNo");
			}
			this.Adapter.InsertCommand.Parameters[0].Value = OrderNo;
			if (Title == null)
			{
				this.Adapter.InsertCommand.Parameters[1].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[1].Value = Title;
			}
			if (Author == null)
			{
				this.Adapter.InsertCommand.Parameters[2].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[2].Value = Author;
			}
			if (Publisher == null)
			{
				this.Adapter.InsertCommand.Parameters[3].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[3].Value = Publisher;
			}
			if (BookType == null)
			{
				this.Adapter.InsertCommand.Parameters[4].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[4].Value = BookType;
			}
			if (Dealer == null)
			{
				this.Adapter.InsertCommand.Parameters[5].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[5].Value = Dealer;
			}
			if (AquisitionType == null)
			{
				this.Adapter.InsertCommand.Parameters[6].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[6].Value = AquisitionType;
			}
			if (ReceivedGroup == null)
			{
				this.Adapter.InsertCommand.Parameters[7].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[7].Value = ReceivedGroup;
			}
			if (SetupBy == null)
			{
				this.Adapter.InsertCommand.Parameters[8].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[8].Value = SetupBy;
			}
			if (Datesetup.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[9].Value = Datesetup.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[9].Value = DBNull.Value;
			}
			this.Adapter.InsertCommand.Parameters[10].Value = ReceivedStatus;
			this.Adapter.InsertCommand.Parameters[11].Value = CatalogStatus;
			if (Copies.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[12].Value = Copies.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[12].Value = DBNull.Value;
			}
			if (PublishedDate == null)
			{
				this.Adapter.InsertCommand.Parameters[13].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[13].Value = PublishedDate;
			}
			if (PublishedYear == null)
			{
				this.Adapter.InsertCommand.Parameters[14].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[14].Value = PublishedYear;
			}
			if (Vol.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[15].Value = Vol.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[15].Value = DBNull.Value;
			}
			if (No.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[16].Value = No.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[16].Value = DBNull.Value;
			}
			if (Edition == null)
			{
				this.Adapter.InsertCommand.Parameters[17].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[17].Value = Edition;
			}
			if (Cost.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[18].Value = Cost.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[18].Value = DBNull.Value;
			}
			if (TotalCost.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[19].Value = TotalCost.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[19].Value = DBNull.Value;
			}
			if (ISBN == null)
			{
				this.Adapter.InsertCommand.Parameters[20].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[20].Value = ISBN;
			}
			if (ACCNO == null)
			{
				throw new ArgumentNullException("ACCNO");
			}
			this.Adapter.InsertCommand.Parameters[21].Value = ACCNO;
			if (GRNumber == null)
			{
				this.Adapter.InsertCommand.Parameters[22].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[22].Value = GRNumber;
			}
			if (Availability.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[23].Value = Availability.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[23].Value = DBNull.Value;
			}
			if (AccYear == null)
			{
				this.Adapter.InsertCommand.Parameters[24].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[24].Value = AccYear;
			}
			if (ParallelTitle == null)
			{
				this.Adapter.InsertCommand.Parameters[25].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[25].Value = ParallelTitle;
			}
			if (Editors == null)
			{
				this.Adapter.InsertCommand.Parameters[26].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[26].Value = Editors;
			}
			if (Meetings == null)
			{
				this.Adapter.InsertCommand.Parameters[27].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[27].Value = Meetings;
			}
			if (PubPlace == null)
			{
				this.Adapter.InsertCommand.Parameters[28].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[28].Value = PubPlace;
			}
			if (ClassNo == null)
			{
				this.Adapter.InsertCommand.Parameters[29].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[29].Value = ClassNo;
			}
			if (Language == null)
			{
				this.Adapter.InsertCommand.Parameters[30].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[30].Value = Language;
			}
			if (Binding == null)
			{
				this.Adapter.InsertCommand.Parameters[31].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[31].Value = Binding;
			}
			if (Pages == null)
			{
				this.Adapter.InsertCommand.Parameters[32].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[32].Value = Pages;
			}
			if (SpineLabel == null)
			{
				this.Adapter.InsertCommand.Parameters[33].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[33].Value = SpineLabel;
			}
			if (PubType == null)
			{
				this.Adapter.InsertCommand.Parameters[34].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[34].Value = PubType;
			}
			if (Medium == null)
			{
				this.Adapter.InsertCommand.Parameters[35].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[35].Value = Medium;
			}
			if (Abstract == null)
			{
				this.Adapter.InsertCommand.Parameters[36].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[36].Value = Abstract;
			}
			if (ShelfRef == null)
			{
				this.Adapter.InsertCommand.Parameters[37].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[37].Value = ShelfRef;
			}
			if (Keywords == null)
			{
				this.Adapter.InsertCommand.Parameters[38].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[38].Value = Keywords;
			}
			if (Subject == null)
			{
				this.Adapter.InsertCommand.Parameters[39].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[39].Value = Subject;
			}
			if (LibraryBranch == null)
			{
				this.Adapter.InsertCommand.Parameters[40].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[40].Value = LibraryBranch;
			}
			if (imageurl == null)
			{
				this.Adapter.InsertCommand.Parameters[41].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[41].Value = imageurl;
			}
			if (Navigatelink == null)
			{
				this.Adapter.InsertCommand.Parameters[42].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[42].Value = Navigatelink;
			}
			if (CatLogNo == null)
			{
				this.Adapter.InsertCommand.Parameters[43].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[43].Value = CatLogNo;
			}
			if (Object == null)
			{
				this.Adapter.InsertCommand.Parameters[44].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[44].Value = Object;
			}
			ConnectionState state = this.Adapter.InsertCommand.Connection.State;
			if ((this.Adapter.InsertCommand.Connection.State & ConnectionState.Open) != ConnectionState.Open)
			{
				this.Adapter.InsertCommand.Connection.Open();
			}
			int result;
			try
			{
				int num = this.Adapter.InsertCommand.ExecuteNonQuery();
				result = num;
			}
			finally
			{
				if (state == ConnectionState.Closed)
				{
					this.Adapter.InsertCommand.Connection.Close();
				}
			}
			return result;
		}
		[DataObjectMethod(DataObjectMethodType.Update, true), HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Update(string OrderNo, string Title, string Author, string Publisher, string BookType, string Dealer, string AquisitionType, string ReceivedGroup, string SetupBy, DateTime? Datesetup, int ReceivedStatus, int CatalogStatus, int? Copies, string PublishedDate, string PublishedYear, int? Vol, int? No, string Edition, decimal? Cost, decimal? TotalCost, string ISBN, string ACCNO, string GRNumber, int? Availability, string AccYear, string ParallelTitle, string Editors, string Meetings, string PubPlace, string ClassNo, string Language, string Binding, string Pages, string SpineLabel, string PubType, string Medium, string Abstract, string ShelfRef, string Keywords, string Subject, string LibraryBranch, string imageurl, string Navigatelink, string CatLogNo, string Object, string Original_ACCNO)
		{
			if (OrderNo == null)
			{
				throw new ArgumentNullException("OrderNo");
			}
			this.Adapter.UpdateCommand.Parameters[0].Value = OrderNo;
			if (Title == null)
			{
				this.Adapter.UpdateCommand.Parameters[1].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[1].Value = Title;
			}
			if (Author == null)
			{
				this.Adapter.UpdateCommand.Parameters[2].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[2].Value = Author;
			}
			if (Publisher == null)
			{
				this.Adapter.UpdateCommand.Parameters[3].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[3].Value = Publisher;
			}
			if (BookType == null)
			{
				this.Adapter.UpdateCommand.Parameters[4].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[4].Value = BookType;
			}
			if (Dealer == null)
			{
				this.Adapter.UpdateCommand.Parameters[5].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[5].Value = Dealer;
			}
			if (AquisitionType == null)
			{
				this.Adapter.UpdateCommand.Parameters[6].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[6].Value = AquisitionType;
			}
			if (ReceivedGroup == null)
			{
				this.Adapter.UpdateCommand.Parameters[7].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[7].Value = ReceivedGroup;
			}
			if (SetupBy == null)
			{
				this.Adapter.UpdateCommand.Parameters[8].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[8].Value = SetupBy;
			}
			if (Datesetup.HasValue)
			{
				this.Adapter.UpdateCommand.Parameters[9].Value = Datesetup.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[9].Value = DBNull.Value;
			}
			this.Adapter.UpdateCommand.Parameters[10].Value = ReceivedStatus;
			this.Adapter.UpdateCommand.Parameters[11].Value = CatalogStatus;
			if (Copies.HasValue)
			{
				this.Adapter.UpdateCommand.Parameters[12].Value = Copies.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[12].Value = DBNull.Value;
			}
			if (PublishedDate == null)
			{
				this.Adapter.UpdateCommand.Parameters[13].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[13].Value = PublishedDate;
			}
			if (PublishedYear == null)
			{
				this.Adapter.UpdateCommand.Parameters[14].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[14].Value = PublishedYear;
			}
			if (Vol.HasValue)
			{
				this.Adapter.UpdateCommand.Parameters[15].Value = Vol.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[15].Value = DBNull.Value;
			}
			if (No.HasValue)
			{
				this.Adapter.UpdateCommand.Parameters[16].Value = No.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[16].Value = DBNull.Value;
			}
			if (Edition == null)
			{
				this.Adapter.UpdateCommand.Parameters[17].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[17].Value = Edition;
			}
			if (Cost.HasValue)
			{
				this.Adapter.UpdateCommand.Parameters[18].Value = Cost.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[18].Value = DBNull.Value;
			}
			if (TotalCost.HasValue)
			{
				this.Adapter.UpdateCommand.Parameters[19].Value = TotalCost.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[19].Value = DBNull.Value;
			}
			if (ISBN == null)
			{
				this.Adapter.UpdateCommand.Parameters[20].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[20].Value = ISBN;
			}
			if (ACCNO == null)
			{
				throw new ArgumentNullException("ACCNO");
			}
			this.Adapter.UpdateCommand.Parameters[21].Value = ACCNO;
			if (GRNumber == null)
			{
				this.Adapter.UpdateCommand.Parameters[22].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[22].Value = GRNumber;
			}
			if (Availability.HasValue)
			{
				this.Adapter.UpdateCommand.Parameters[23].Value = Availability.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[23].Value = DBNull.Value;
			}
			if (AccYear == null)
			{
				this.Adapter.UpdateCommand.Parameters[24].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[24].Value = AccYear;
			}
			if (ParallelTitle == null)
			{
				this.Adapter.UpdateCommand.Parameters[25].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[25].Value = ParallelTitle;
			}
			if (Editors == null)
			{
				this.Adapter.UpdateCommand.Parameters[26].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[26].Value = Editors;
			}
			if (Meetings == null)
			{
				this.Adapter.UpdateCommand.Parameters[27].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[27].Value = Meetings;
			}
			if (PubPlace == null)
			{
				this.Adapter.UpdateCommand.Parameters[28].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[28].Value = PubPlace;
			}
			if (ClassNo == null)
			{
				this.Adapter.UpdateCommand.Parameters[29].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[29].Value = ClassNo;
			}
			if (Language == null)
			{
				this.Adapter.UpdateCommand.Parameters[30].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[30].Value = Language;
			}
			if (Binding == null)
			{
				this.Adapter.UpdateCommand.Parameters[31].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[31].Value = Binding;
			}
			if (Pages == null)
			{
				this.Adapter.UpdateCommand.Parameters[32].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[32].Value = Pages;
			}
			if (SpineLabel == null)
			{
				this.Adapter.UpdateCommand.Parameters[33].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[33].Value = SpineLabel;
			}
			if (PubType == null)
			{
				this.Adapter.UpdateCommand.Parameters[34].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[34].Value = PubType;
			}
			if (Medium == null)
			{
				this.Adapter.UpdateCommand.Parameters[35].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[35].Value = Medium;
			}
			if (Abstract == null)
			{
				this.Adapter.UpdateCommand.Parameters[36].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[36].Value = Abstract;
			}
			if (ShelfRef == null)
			{
				this.Adapter.UpdateCommand.Parameters[37].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[37].Value = ShelfRef;
			}
			if (Keywords == null)
			{
				this.Adapter.UpdateCommand.Parameters[38].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[38].Value = Keywords;
			}
			if (Subject == null)
			{
				this.Adapter.UpdateCommand.Parameters[39].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[39].Value = Subject;
			}
			if (LibraryBranch == null)
			{
				this.Adapter.UpdateCommand.Parameters[40].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[40].Value = LibraryBranch;
			}
			if (imageurl == null)
			{
				this.Adapter.UpdateCommand.Parameters[41].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[41].Value = imageurl;
			}
			if (Navigatelink == null)
			{
				this.Adapter.UpdateCommand.Parameters[42].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[42].Value = Navigatelink;
			}
			if (CatLogNo == null)
			{
				this.Adapter.UpdateCommand.Parameters[43].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[43].Value = CatLogNo;
			}
			if (Object == null)
			{
				this.Adapter.UpdateCommand.Parameters[44].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.UpdateCommand.Parameters[44].Value = Object;
			}
			if (Original_ACCNO == null)
			{
				throw new ArgumentNullException("Original_ACCNO");
			}
			this.Adapter.UpdateCommand.Parameters[45].Value = Original_ACCNO;
			ConnectionState state = this.Adapter.UpdateCommand.Connection.State;
			if ((this.Adapter.UpdateCommand.Connection.State & ConnectionState.Open) != ConnectionState.Open)
			{
				this.Adapter.UpdateCommand.Connection.Open();
			}
			int result;
			try
			{
				int num = this.Adapter.UpdateCommand.ExecuteNonQuery();
				result = num;
			}
			finally
			{
				if (state == ConnectionState.Closed)
				{
					this.Adapter.UpdateCommand.Connection.Close();
				}
			}
			return result;
		}
		[DataObjectMethod(DataObjectMethodType.Update, true), HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Update(string OrderNo, string Title, string Author, string Publisher, string BookType, string Dealer, string AquisitionType, string ReceivedGroup, string SetupBy, DateTime? Datesetup, int ReceivedStatus, int CatalogStatus, int? Copies, string PublishedDate, string PublishedYear, int? Vol, int? No, string Edition, decimal? Cost, decimal? TotalCost, string ISBN, string GRNumber, int? Availability, string AccYear, string ParallelTitle, string Editors, string Meetings, string PubPlace, string ClassNo, string Language, string Binding, string Pages, string SpineLabel, string PubType, string Medium, string Abstract, string ShelfRef, string Keywords, string Subject, string LibraryBranch, string imageurl, string Navigatelink, string CatLogNo, string Object, string Original_ACCNO)
		{
			return this.Update(OrderNo, Title, Author, Publisher, BookType, Dealer, AquisitionType, ReceivedGroup, SetupBy, Datesetup, ReceivedStatus, CatalogStatus, Copies, PublishedDate, PublishedYear, Vol, No, Edition, Cost, TotalCost, ISBN, Original_ACCNO, GRNumber, Availability, AccYear, ParallelTitle, Editors, Meetings, PubPlace, ClassNo, Language, Binding, Pages, SpineLabel, PubType, Medium, Abstract, ShelfRef, Keywords, Subject, LibraryBranch, imageurl, Navigatelink, CatLogNo, Object, Original_ACCNO);
		}
	}
}
