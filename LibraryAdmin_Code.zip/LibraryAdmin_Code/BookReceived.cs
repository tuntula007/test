using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;
[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0"), HelpKeyword("vs.data.DataSet"), DesignerCategory("code"), ToolboxItem(true), XmlRoot("BookReceived"), XmlSchemaProvider("GetTypedDataSetSchema")]
[Serializable]
public class BookReceived : DataSet
{
	public delegate void BookRecievedDetailsRowChangeEventHandler(object sender, BookReceived.BookRecievedDetailsRowChangeEvent e);
	[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0"), XmlSchemaProvider("GetTypedTableSchema")]
	[Serializable]
	public class BookRecievedDetailsDataTable : TypedTableBase<BookReceived.BookRecievedDetailsRow>
	{
		private DataColumn columnSrn;
		private DataColumn columnOrderNo;
		private DataColumn columnTitle;
		private DataColumn columnAuthor;
		private DataColumn columnPublisher;
		private DataColumn columnBookType;
		private DataColumn columnDealer;
		private DataColumn columnAquisitionType;
		private DataColumn columnReceivedGroup;
		private DataColumn columnSetupBy;
		private DataColumn columnDatesetup;
		private DataColumn columnReceivedStatus;
		private DataColumn columnCatalogStatus;
		private DataColumn columnCopies;
		private DataColumn columnPublishedDate;
		private DataColumn columnPublishedYear;
		private DataColumn columnVol;
		private DataColumn columnNo;
		private DataColumn columnEdition;
		private DataColumn columnCost;
		private DataColumn columnTotalCost;
		private DataColumn columnISBN;
		private DataColumn columnACCNO;
		private DataColumn columnGRNumber;
		private DataColumn columnTransId;
		private DataColumn columnNumber;
		public event BookReceived.BookRecievedDetailsRowChangeEventHandler BookRecievedDetailsRowChanging
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.BookRecievedDetailsRowChanging = (BookReceived.BookRecievedDetailsRowChangeEventHandler)Delegate.Combine(this.BookRecievedDetailsRowChanging, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.BookRecievedDetailsRowChanging = (BookReceived.BookRecievedDetailsRowChangeEventHandler)Delegate.Remove(this.BookRecievedDetailsRowChanging, value);
			}
		}
		public event BookReceived.BookRecievedDetailsRowChangeEventHandler BookRecievedDetailsRowChanged
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.BookRecievedDetailsRowChanged = (BookReceived.BookRecievedDetailsRowChangeEventHandler)Delegate.Combine(this.BookRecievedDetailsRowChanged, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.BookRecievedDetailsRowChanged = (BookReceived.BookRecievedDetailsRowChangeEventHandler)Delegate.Remove(this.BookRecievedDetailsRowChanged, value);
			}
		}
		public event BookReceived.BookRecievedDetailsRowChangeEventHandler BookRecievedDetailsRowDeleting
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.BookRecievedDetailsRowDeleting = (BookReceived.BookRecievedDetailsRowChangeEventHandler)Delegate.Combine(this.BookRecievedDetailsRowDeleting, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.BookRecievedDetailsRowDeleting = (BookReceived.BookRecievedDetailsRowChangeEventHandler)Delegate.Remove(this.BookRecievedDetailsRowDeleting, value);
			}
		}
		public event BookReceived.BookRecievedDetailsRowChangeEventHandler BookRecievedDetailsRowDeleted
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.BookRecievedDetailsRowDeleted = (BookReceived.BookRecievedDetailsRowChangeEventHandler)Delegate.Combine(this.BookRecievedDetailsRowDeleted, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.BookRecievedDetailsRowDeleted = (BookReceived.BookRecievedDetailsRowChangeEventHandler)Delegate.Remove(this.BookRecievedDetailsRowDeleted, value);
			}
		}
		[DebuggerNonUserCode]
		public DataColumn SrnColumn
		{
			get
			{
				return this.columnSrn;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn OrderNoColumn
		{
			get
			{
				return this.columnOrderNo;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn TitleColumn
		{
			get
			{
				return this.columnTitle;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn AuthorColumn
		{
			get
			{
				return this.columnAuthor;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn PublisherColumn
		{
			get
			{
				return this.columnPublisher;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn BookTypeColumn
		{
			get
			{
				return this.columnBookType;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn DealerColumn
		{
			get
			{
				return this.columnDealer;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn AquisitionTypeColumn
		{
			get
			{
				return this.columnAquisitionType;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn ReceivedGroupColumn
		{
			get
			{
				return this.columnReceivedGroup;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn SetupByColumn
		{
			get
			{
				return this.columnSetupBy;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn DatesetupColumn
		{
			get
			{
				return this.columnDatesetup;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn ReceivedStatusColumn
		{
			get
			{
				return this.columnReceivedStatus;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn CatalogStatusColumn
		{
			get
			{
				return this.columnCatalogStatus;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn CopiesColumn
		{
			get
			{
				return this.columnCopies;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn PublishedDateColumn
		{
			get
			{
				return this.columnPublishedDate;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn PublishedYearColumn
		{
			get
			{
				return this.columnPublishedYear;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn VolColumn
		{
			get
			{
				return this.columnVol;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn NoColumn
		{
			get
			{
				return this.columnNo;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn EditionColumn
		{
			get
			{
				return this.columnEdition;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn CostColumn
		{
			get
			{
				return this.columnCost;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn TotalCostColumn
		{
			get
			{
				return this.columnTotalCost;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn ISBNColumn
		{
			get
			{
				return this.columnISBN;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn ACCNOColumn
		{
			get
			{
				return this.columnACCNO;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn GRNumberColumn
		{
			get
			{
				return this.columnGRNumber;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn TransIdColumn
		{
			get
			{
				return this.columnTransId;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn NumberColumn
		{
			get
			{
				return this.columnNumber;
			}
		}
		[Browsable(false), DebuggerNonUserCode]
		public int Count
		{
			get
			{
				return base.Rows.Count;
			}
		}
		[DebuggerNonUserCode]
		public BookReceived.BookRecievedDetailsRow this[int index]
		{
			get
			{
				return (BookReceived.BookRecievedDetailsRow)base.Rows[index];
			}
		}
		[DebuggerNonUserCode]
		public BookRecievedDetailsDataTable()
		{
			base.TableName = "BookRecievedDetails";
			this.BeginInit();
			this.InitClass();
			this.EndInit();
		}
		[DebuggerNonUserCode]
		internal BookRecievedDetailsDataTable(DataTable table)
		{
			base.TableName = table.TableName;
			if (table.CaseSensitive != table.DataSet.CaseSensitive)
			{
				base.CaseSensitive = table.CaseSensitive;
			}
			if (table.Locale.ToString() != table.DataSet.Locale.ToString())
			{
				base.Locale = table.Locale;
			}
			if (table.Namespace != table.DataSet.Namespace)
			{
				base.Namespace = table.Namespace;
			}
			base.Prefix = table.Prefix;
			base.MinimumCapacity = table.MinimumCapacity;
		}
		[DebuggerNonUserCode]
		protected BookRecievedDetailsDataTable(SerializationInfo info, StreamingContext context) : base(info, context)
		{
			this.InitVars();
		}
		[DebuggerNonUserCode]
		public void AddBookRecievedDetailsRow(BookReceived.BookRecievedDetailsRow row)
		{
			base.Rows.Add(row);
		}
		[DebuggerNonUserCode]
		public BookReceived.BookRecievedDetailsRow AddBookRecievedDetailsRow(string OrderNo, string Title, string Author, string Publisher, string BookType, string Dealer, string AquisitionType, string ReceivedGroup, string SetupBy, DateTime Datesetup, int ReceivedStatus, int CatalogStatus, int Copies, string PublishedDate, string PublishedYear, int Vol, int No, string Edition, decimal Cost, decimal TotalCost, string ISBN, string ACCNO, string GRNumber, string TransId, long Number)
		{
			BookReceived.BookRecievedDetailsRow bookRecievedDetailsRow = (BookReceived.BookRecievedDetailsRow)base.NewRow();
			object[] itemArray = new object[]
			{
				null,
				OrderNo,
				Title,
				Author,
				Publisher,
				BookType,
				Dealer,
				AquisitionType,
				ReceivedGroup,
				SetupBy,
				Datesetup,
				ReceivedStatus,
				CatalogStatus,
				Copies,
				PublishedDate,
				PublishedYear,
				Vol,
				No,
				Edition,
				Cost,
				TotalCost,
				ISBN,
				ACCNO,
				GRNumber,
				TransId,
				Number
			};
			bookRecievedDetailsRow.ItemArray = itemArray;
			base.Rows.Add(bookRecievedDetailsRow);
			return bookRecievedDetailsRow;
		}
		[DebuggerNonUserCode]
		public override DataTable Clone()
		{
			BookReceived.BookRecievedDetailsDataTable bookRecievedDetailsDataTable = (BookReceived.BookRecievedDetailsDataTable)base.Clone();
			bookRecievedDetailsDataTable.InitVars();
			return bookRecievedDetailsDataTable;
		}
		[DebuggerNonUserCode]
		protected override DataTable CreateInstance()
		{
			return new BookReceived.BookRecievedDetailsDataTable();
		}
		[DebuggerNonUserCode]
		internal void InitVars()
		{
			this.columnSrn = base.Columns["Srn"];
			this.columnOrderNo = base.Columns["OrderNo"];
			this.columnTitle = base.Columns["Title"];
			this.columnAuthor = base.Columns["Author"];
			this.columnPublisher = base.Columns["Publisher"];
			this.columnBookType = base.Columns["BookType"];
			this.columnDealer = base.Columns["Dealer"];
			this.columnAquisitionType = base.Columns["AquisitionType"];
			this.columnReceivedGroup = base.Columns["ReceivedGroup"];
			this.columnSetupBy = base.Columns["SetupBy"];
			this.columnDatesetup = base.Columns["Datesetup"];
			this.columnReceivedStatus = base.Columns["ReceivedStatus"];
			this.columnCatalogStatus = base.Columns["CatalogStatus"];
			this.columnCopies = base.Columns["Copies"];
			this.columnPublishedDate = base.Columns["PublishedDate"];
			this.columnPublishedYear = base.Columns["PublishedYear"];
			this.columnVol = base.Columns["Vol"];
			this.columnNo = base.Columns["No"];
			this.columnEdition = base.Columns["Edition"];
			this.columnCost = base.Columns["Cost"];
			this.columnTotalCost = base.Columns["TotalCost"];
			this.columnISBN = base.Columns["ISBN"];
			this.columnACCNO = base.Columns["ACCNO"];
			this.columnGRNumber = base.Columns["GRNumber"];
			this.columnTransId = base.Columns["TransId"];
			this.columnNumber = base.Columns["Number"];
		}
		[DebuggerNonUserCode]
		private void InitClass()
		{
			this.columnSrn = new DataColumn("Srn", typeof(decimal), null, MappingType.Element);
			base.Columns.Add(this.columnSrn);
			this.columnOrderNo = new DataColumn("OrderNo", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnOrderNo);
			this.columnTitle = new DataColumn("Title", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnTitle);
			this.columnAuthor = new DataColumn("Author", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnAuthor);
			this.columnPublisher = new DataColumn("Publisher", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnPublisher);
			this.columnBookType = new DataColumn("BookType", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnBookType);
			this.columnDealer = new DataColumn("Dealer", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnDealer);
			this.columnAquisitionType = new DataColumn("AquisitionType", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnAquisitionType);
			this.columnReceivedGroup = new DataColumn("ReceivedGroup", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnReceivedGroup);
			this.columnSetupBy = new DataColumn("SetupBy", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnSetupBy);
			this.columnDatesetup = new DataColumn("Datesetup", typeof(DateTime), null, MappingType.Element);
			base.Columns.Add(this.columnDatesetup);
			this.columnReceivedStatus = new DataColumn("ReceivedStatus", typeof(int), null, MappingType.Element);
			base.Columns.Add(this.columnReceivedStatus);
			this.columnCatalogStatus = new DataColumn("CatalogStatus", typeof(int), null, MappingType.Element);
			base.Columns.Add(this.columnCatalogStatus);
			this.columnCopies = new DataColumn("Copies", typeof(int), null, MappingType.Element);
			base.Columns.Add(this.columnCopies);
			this.columnPublishedDate = new DataColumn("PublishedDate", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnPublishedDate);
			this.columnPublishedYear = new DataColumn("PublishedYear", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnPublishedYear);
			this.columnVol = new DataColumn("Vol", typeof(int), null, MappingType.Element);
			base.Columns.Add(this.columnVol);
			this.columnNo = new DataColumn("No", typeof(int), null, MappingType.Element);
			base.Columns.Add(this.columnNo);
			this.columnEdition = new DataColumn("Edition", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnEdition);
			this.columnCost = new DataColumn("Cost", typeof(decimal), null, MappingType.Element);
			base.Columns.Add(this.columnCost);
			this.columnTotalCost = new DataColumn("TotalCost", typeof(decimal), null, MappingType.Element);
			base.Columns.Add(this.columnTotalCost);
			this.columnISBN = new DataColumn("ISBN", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnISBN);
			this.columnACCNO = new DataColumn("ACCNO", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnACCNO);
			this.columnGRNumber = new DataColumn("GRNumber", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnGRNumber);
			this.columnTransId = new DataColumn("TransId", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnTransId);
			this.columnNumber = new DataColumn("Number", typeof(long), null, MappingType.Element);
			base.Columns.Add(this.columnNumber);
			this.columnSrn.AutoIncrement = true;
			this.columnSrn.AutoIncrementSeed = -1L;
			this.columnSrn.AutoIncrementStep = -1L;
			this.columnSrn.AllowDBNull = false;
			this.columnSrn.ReadOnly = true;
			this.columnOrderNo.AllowDBNull = false;
			this.columnOrderNo.MaxLength = 50;
			this.columnTitle.MaxLength = 200;
			this.columnAuthor.MaxLength = 50;
			this.columnPublisher.MaxLength = 50;
			this.columnBookType.MaxLength = 50;
			this.columnDealer.MaxLength = 50;
			this.columnAquisitionType.MaxLength = 50;
			this.columnReceivedGroup.MaxLength = 100;
			this.columnSetupBy.MaxLength = 50;
			this.columnReceivedStatus.AllowDBNull = false;
			this.columnCatalogStatus.AllowDBNull = false;
			this.columnPublishedDate.MaxLength = 50;
			this.columnPublishedYear.MaxLength = 50;
			this.columnEdition.MaxLength = 50;
			this.columnISBN.MaxLength = 50;
			this.columnACCNO.MaxLength = 50;
			this.columnGRNumber.MaxLength = 50;
			this.columnTransId.MaxLength = 50;
		}
		[DebuggerNonUserCode]
		public BookReceived.BookRecievedDetailsRow NewBookRecievedDetailsRow()
		{
			return (BookReceived.BookRecievedDetailsRow)base.NewRow();
		}
		[DebuggerNonUserCode]
		protected override DataRow NewRowFromBuilder(DataRowBuilder builder)
		{
			return new BookReceived.BookRecievedDetailsRow(builder);
		}
		[DebuggerNonUserCode]
		protected override Type GetRowType()
		{
			return typeof(BookReceived.BookRecievedDetailsRow);
		}
		[DebuggerNonUserCode]
		protected override void OnRowChanged(DataRowChangeEventArgs e)
		{
			base.OnRowChanged(e);
			if (this.BookRecievedDetailsRowChanged != null)
			{
				this.BookRecievedDetailsRowChanged(this, new BookReceived.BookRecievedDetailsRowChangeEvent((BookReceived.BookRecievedDetailsRow)e.Row, e.Action));
			}
		}
		[DebuggerNonUserCode]
		protected override void OnRowChanging(DataRowChangeEventArgs e)
		{
			base.OnRowChanging(e);
			if (this.BookRecievedDetailsRowChanging != null)
			{
				this.BookRecievedDetailsRowChanging(this, new BookReceived.BookRecievedDetailsRowChangeEvent((BookReceived.BookRecievedDetailsRow)e.Row, e.Action));
			}
		}
		[DebuggerNonUserCode]
		protected override void OnRowDeleted(DataRowChangeEventArgs e)
		{
			base.OnRowDeleted(e);
			if (this.BookRecievedDetailsRowDeleted != null)
			{
				this.BookRecievedDetailsRowDeleted(this, new BookReceived.BookRecievedDetailsRowChangeEvent((BookReceived.BookRecievedDetailsRow)e.Row, e.Action));
			}
		}
		[DebuggerNonUserCode]
		protected override void OnRowDeleting(DataRowChangeEventArgs e)
		{
			base.OnRowDeleting(e);
			if (this.BookRecievedDetailsRowDeleting != null)
			{
				this.BookRecievedDetailsRowDeleting(this, new BookReceived.BookRecievedDetailsRowChangeEvent((BookReceived.BookRecievedDetailsRow)e.Row, e.Action));
			}
		}
		[DebuggerNonUserCode]
		public void RemoveBookRecievedDetailsRow(BookReceived.BookRecievedDetailsRow row)
		{
			base.Rows.Remove(row);
		}
		[DebuggerNonUserCode]
		public static XmlSchemaComplexType GetTypedTableSchema(XmlSchemaSet xs)
		{
			XmlSchemaComplexType xmlSchemaComplexType = new XmlSchemaComplexType();
			XmlSchemaSequence xmlSchemaSequence = new XmlSchemaSequence();
			BookReceived bookReceived = new BookReceived();
			XmlSchemaAny xmlSchemaAny = new XmlSchemaAny();
			xmlSchemaAny.Namespace = "http://www.w3.org/2001/XMLSchema";
			xmlSchemaAny.MinOccurs = 0m;
			xmlSchemaAny.MaxOccurs = 79228162514264337593543950335m;
			xmlSchemaAny.ProcessContents = XmlSchemaContentProcessing.Lax;
			xmlSchemaSequence.Items.Add(xmlSchemaAny);
			XmlSchemaAny xmlSchemaAny2 = new XmlSchemaAny();
			xmlSchemaAny2.Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1";
			xmlSchemaAny2.MinOccurs = 1m;
			xmlSchemaAny2.ProcessContents = XmlSchemaContentProcessing.Lax;
			xmlSchemaSequence.Items.Add(xmlSchemaAny2);
			XmlSchemaAttribute xmlSchemaAttribute = new XmlSchemaAttribute();
			xmlSchemaAttribute.Name = "namespace";
			xmlSchemaAttribute.FixedValue = bookReceived.Namespace;
			xmlSchemaComplexType.Attributes.Add(xmlSchemaAttribute);
			XmlSchemaAttribute xmlSchemaAttribute2 = new XmlSchemaAttribute();
			xmlSchemaAttribute2.Name = "tableTypeName";
			xmlSchemaAttribute2.FixedValue = "BookRecievedDetailsDataTable";
			xmlSchemaComplexType.Attributes.Add(xmlSchemaAttribute2);
			xmlSchemaComplexType.Particle = xmlSchemaSequence;
			XmlSchema schemaSerializable = bookReceived.GetSchemaSerializable();
			if (xs.Contains(schemaSerializable.TargetNamespace))
			{
				MemoryStream memoryStream = new MemoryStream();
				MemoryStream memoryStream2 = new MemoryStream();
				try
				{
					schemaSerializable.Write(memoryStream);
					IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
					while (enumerator.MoveNext())
					{
						XmlSchema xmlSchema = (XmlSchema)enumerator.Current;
						memoryStream2.SetLength(0L);
						xmlSchema.Write(memoryStream2);
						if (memoryStream.Length == memoryStream2.Length)
						{
							memoryStream.Position = 0L;
							memoryStream2.Position = 0L;
							while (memoryStream.Position != memoryStream.Length && memoryStream.ReadByte() == memoryStream2.ReadByte())
							{
							}
							if (memoryStream.Position == memoryStream.Length)
							{
								return xmlSchemaComplexType;
							}
						}
					}
				}
				finally
				{
					if (memoryStream != null)
					{
						memoryStream.Close();
					}
					if (memoryStream2 != null)
					{
						memoryStream2.Close();
					}
				}
			}
			xs.Add(schemaSerializable);
			return xmlSchemaComplexType;
		}
	}
	[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0")]
	public class BookRecievedDetailsRow : DataRow
	{
		private BookReceived.BookRecievedDetailsDataTable tableBookRecievedDetails;
		[DebuggerNonUserCode]
		public decimal Srn
		{
			get
			{
				return (decimal)base[this.tableBookRecievedDetails.SrnColumn];
			}
			set
			{
				base[this.tableBookRecievedDetails.SrnColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string OrderNo
		{
			get
			{
				return (string)base[this.tableBookRecievedDetails.OrderNoColumn];
			}
			set
			{
				base[this.tableBookRecievedDetails.OrderNoColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Title
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookRecievedDetails.TitleColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Title' in table 'BookRecievedDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookRecievedDetails.TitleColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Author
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookRecievedDetails.AuthorColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Author' in table 'BookRecievedDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookRecievedDetails.AuthorColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Publisher
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookRecievedDetails.PublisherColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Publisher' in table 'BookRecievedDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookRecievedDetails.PublisherColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string BookType
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookRecievedDetails.BookTypeColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'BookType' in table 'BookRecievedDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookRecievedDetails.BookTypeColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Dealer
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookRecievedDetails.DealerColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Dealer' in table 'BookRecievedDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookRecievedDetails.DealerColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string AquisitionType
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookRecievedDetails.AquisitionTypeColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'AquisitionType' in table 'BookRecievedDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookRecievedDetails.AquisitionTypeColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string ReceivedGroup
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookRecievedDetails.ReceivedGroupColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'ReceivedGroup' in table 'BookRecievedDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookRecievedDetails.ReceivedGroupColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string SetupBy
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookRecievedDetails.SetupByColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'SetupBy' in table 'BookRecievedDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookRecievedDetails.SetupByColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public DateTime Datesetup
		{
			get
			{
				DateTime result;
				try
				{
					result = (DateTime)base[this.tableBookRecievedDetails.DatesetupColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Datesetup' in table 'BookRecievedDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookRecievedDetails.DatesetupColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public int ReceivedStatus
		{
			get
			{
				return (int)base[this.tableBookRecievedDetails.ReceivedStatusColumn];
			}
			set
			{
				base[this.tableBookRecievedDetails.ReceivedStatusColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public int CatalogStatus
		{
			get
			{
				return (int)base[this.tableBookRecievedDetails.CatalogStatusColumn];
			}
			set
			{
				base[this.tableBookRecievedDetails.CatalogStatusColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public int Copies
		{
			get
			{
				int result;
				try
				{
					result = (int)base[this.tableBookRecievedDetails.CopiesColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Copies' in table 'BookRecievedDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookRecievedDetails.CopiesColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string PublishedDate
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookRecievedDetails.PublishedDateColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'PublishedDate' in table 'BookRecievedDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookRecievedDetails.PublishedDateColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string PublishedYear
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookRecievedDetails.PublishedYearColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'PublishedYear' in table 'BookRecievedDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookRecievedDetails.PublishedYearColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public int Vol
		{
			get
			{
				int result;
				try
				{
					result = (int)base[this.tableBookRecievedDetails.VolColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Vol' in table 'BookRecievedDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookRecievedDetails.VolColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public int No
		{
			get
			{
				int result;
				try
				{
					result = (int)base[this.tableBookRecievedDetails.NoColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'No' in table 'BookRecievedDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookRecievedDetails.NoColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Edition
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookRecievedDetails.EditionColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Edition' in table 'BookRecievedDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookRecievedDetails.EditionColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public decimal Cost
		{
			get
			{
				decimal result;
				try
				{
					result = (decimal)base[this.tableBookRecievedDetails.CostColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Cost' in table 'BookRecievedDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookRecievedDetails.CostColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public decimal TotalCost
		{
			get
			{
				decimal result;
				try
				{
					result = (decimal)base[this.tableBookRecievedDetails.TotalCostColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'TotalCost' in table 'BookRecievedDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookRecievedDetails.TotalCostColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string ISBN
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookRecievedDetails.ISBNColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'ISBN' in table 'BookRecievedDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookRecievedDetails.ISBNColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string ACCNO
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookRecievedDetails.ACCNOColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'ACCNO' in table 'BookRecievedDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookRecievedDetails.ACCNOColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string GRNumber
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookRecievedDetails.GRNumberColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'GRNumber' in table 'BookRecievedDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookRecievedDetails.GRNumberColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string TransId
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookRecievedDetails.TransIdColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'TransId' in table 'BookRecievedDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookRecievedDetails.TransIdColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public long Number
		{
			get
			{
				long result;
				try
				{
					result = (long)base[this.tableBookRecievedDetails.NumberColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Number' in table 'BookRecievedDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookRecievedDetails.NumberColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		internal BookRecievedDetailsRow(DataRowBuilder rb) : base(rb)
		{
			this.tableBookRecievedDetails = (BookReceived.BookRecievedDetailsDataTable)base.Table;
		}
		[DebuggerNonUserCode]
		public bool IsTitleNull()
		{
			return base.IsNull(this.tableBookRecievedDetails.TitleColumn);
		}
		[DebuggerNonUserCode]
		public void SetTitleNull()
		{
			base[this.tableBookRecievedDetails.TitleColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsAuthorNull()
		{
			return base.IsNull(this.tableBookRecievedDetails.AuthorColumn);
		}
		[DebuggerNonUserCode]
		public void SetAuthorNull()
		{
			base[this.tableBookRecievedDetails.AuthorColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsPublisherNull()
		{
			return base.IsNull(this.tableBookRecievedDetails.PublisherColumn);
		}
		[DebuggerNonUserCode]
		public void SetPublisherNull()
		{
			base[this.tableBookRecievedDetails.PublisherColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsBookTypeNull()
		{
			return base.IsNull(this.tableBookRecievedDetails.BookTypeColumn);
		}
		[DebuggerNonUserCode]
		public void SetBookTypeNull()
		{
			base[this.tableBookRecievedDetails.BookTypeColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsDealerNull()
		{
			return base.IsNull(this.tableBookRecievedDetails.DealerColumn);
		}
		[DebuggerNonUserCode]
		public void SetDealerNull()
		{
			base[this.tableBookRecievedDetails.DealerColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsAquisitionTypeNull()
		{
			return base.IsNull(this.tableBookRecievedDetails.AquisitionTypeColumn);
		}
		[DebuggerNonUserCode]
		public void SetAquisitionTypeNull()
		{
			base[this.tableBookRecievedDetails.AquisitionTypeColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsReceivedGroupNull()
		{
			return base.IsNull(this.tableBookRecievedDetails.ReceivedGroupColumn);
		}
		[DebuggerNonUserCode]
		public void SetReceivedGroupNull()
		{
			base[this.tableBookRecievedDetails.ReceivedGroupColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsSetupByNull()
		{
			return base.IsNull(this.tableBookRecievedDetails.SetupByColumn);
		}
		[DebuggerNonUserCode]
		public void SetSetupByNull()
		{
			base[this.tableBookRecievedDetails.SetupByColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsDatesetupNull()
		{
			return base.IsNull(this.tableBookRecievedDetails.DatesetupColumn);
		}
		[DebuggerNonUserCode]
		public void SetDatesetupNull()
		{
			base[this.tableBookRecievedDetails.DatesetupColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsCopiesNull()
		{
			return base.IsNull(this.tableBookRecievedDetails.CopiesColumn);
		}
		[DebuggerNonUserCode]
		public void SetCopiesNull()
		{
			base[this.tableBookRecievedDetails.CopiesColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsPublishedDateNull()
		{
			return base.IsNull(this.tableBookRecievedDetails.PublishedDateColumn);
		}
		[DebuggerNonUserCode]
		public void SetPublishedDateNull()
		{
			base[this.tableBookRecievedDetails.PublishedDateColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsPublishedYearNull()
		{
			return base.IsNull(this.tableBookRecievedDetails.PublishedYearColumn);
		}
		[DebuggerNonUserCode]
		public void SetPublishedYearNull()
		{
			base[this.tableBookRecievedDetails.PublishedYearColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsVolNull()
		{
			return base.IsNull(this.tableBookRecievedDetails.VolColumn);
		}
		[DebuggerNonUserCode]
		public void SetVolNull()
		{
			base[this.tableBookRecievedDetails.VolColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsNoNull()
		{
			return base.IsNull(this.tableBookRecievedDetails.NoColumn);
		}
		[DebuggerNonUserCode]
		public void SetNoNull()
		{
			base[this.tableBookRecievedDetails.NoColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsEditionNull()
		{
			return base.IsNull(this.tableBookRecievedDetails.EditionColumn);
		}
		[DebuggerNonUserCode]
		public void SetEditionNull()
		{
			base[this.tableBookRecievedDetails.EditionColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsCostNull()
		{
			return base.IsNull(this.tableBookRecievedDetails.CostColumn);
		}
		[DebuggerNonUserCode]
		public void SetCostNull()
		{
			base[this.tableBookRecievedDetails.CostColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsTotalCostNull()
		{
			return base.IsNull(this.tableBookRecievedDetails.TotalCostColumn);
		}
		[DebuggerNonUserCode]
		public void SetTotalCostNull()
		{
			base[this.tableBookRecievedDetails.TotalCostColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsISBNNull()
		{
			return base.IsNull(this.tableBookRecievedDetails.ISBNColumn);
		}
		[DebuggerNonUserCode]
		public void SetISBNNull()
		{
			base[this.tableBookRecievedDetails.ISBNColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsACCNONull()
		{
			return base.IsNull(this.tableBookRecievedDetails.ACCNOColumn);
		}
		[DebuggerNonUserCode]
		public void SetACCNONull()
		{
			base[this.tableBookRecievedDetails.ACCNOColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsGRNumberNull()
		{
			return base.IsNull(this.tableBookRecievedDetails.GRNumberColumn);
		}
		[DebuggerNonUserCode]
		public void SetGRNumberNull()
		{
			base[this.tableBookRecievedDetails.GRNumberColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsTransIdNull()
		{
			return base.IsNull(this.tableBookRecievedDetails.TransIdColumn);
		}
		[DebuggerNonUserCode]
		public void SetTransIdNull()
		{
			base[this.tableBookRecievedDetails.TransIdColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsNumberNull()
		{
			return base.IsNull(this.tableBookRecievedDetails.NumberColumn);
		}
		[DebuggerNonUserCode]
		public void SetNumberNull()
		{
			base[this.tableBookRecievedDetails.NumberColumn] = Convert.DBNull;
		}
	}
	[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0")]
	public class BookRecievedDetailsRowChangeEvent : EventArgs
	{
		private BookReceived.BookRecievedDetailsRow eventRow;
		private DataRowAction eventAction;
		[DebuggerNonUserCode]
		public BookReceived.BookRecievedDetailsRow Row
		{
			get
			{
				return this.eventRow;
			}
		}
		[DebuggerNonUserCode]
		public DataRowAction Action
		{
			get
			{
				return this.eventAction;
			}
		}
		[DebuggerNonUserCode]
		public BookRecievedDetailsRowChangeEvent(BookReceived.BookRecievedDetailsRow row, DataRowAction action)
		{
			this.eventRow = row;
			this.eventAction = action;
		}
	}
	private BookReceived.BookRecievedDetailsDataTable tableBookRecievedDetails;
	private SchemaSerializationMode _schemaSerializationMode = SchemaSerializationMode.IncludeSchema;
	[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Content), DebuggerNonUserCode]
	public BookReceived.BookRecievedDetailsDataTable BookRecievedDetails
	{
		get
		{
			return this.tableBookRecievedDetails;
		}
	}
	[Browsable(true), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible), DebuggerNonUserCode]
	public override SchemaSerializationMode SchemaSerializationMode
	{
		get
		{
			return this._schemaSerializationMode;
		}
		set
		{
			this._schemaSerializationMode = value;
		}
	}
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden), DebuggerNonUserCode]
	public new DataTableCollection Tables
	{
		get
		{
			return base.Tables;
		}
	}
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden), DebuggerNonUserCode]
	public new DataRelationCollection Relations
	{
		get
		{
			return base.Relations;
		}
	}
	[DebuggerNonUserCode]
	public BookReceived()
	{
		base.BeginInit();
		this.InitClass();
		CollectionChangeEventHandler value = new CollectionChangeEventHandler(this.SchemaChanged);
		base.Tables.CollectionChanged += value;
		base.Relations.CollectionChanged += value;
		base.EndInit();
	}
	[DebuggerNonUserCode]
	protected BookReceived(SerializationInfo info, StreamingContext context) : base(info, context, false)
	{
		if (base.IsBinarySerialized(info, context))
		{
			this.InitVars(false);
			CollectionChangeEventHandler value = new CollectionChangeEventHandler(this.SchemaChanged);
			this.Tables.CollectionChanged += value;
			this.Relations.CollectionChanged += value;
			return;
		}
		string s = (string)info.GetValue("XmlSchema", typeof(string));
		if (base.DetermineSchemaSerializationMode(info, context) == SchemaSerializationMode.IncludeSchema)
		{
			DataSet dataSet = new DataSet();
			dataSet.ReadXmlSchema(new XmlTextReader(new StringReader(s)));
			if (dataSet.Tables["BookRecievedDetails"] != null)
			{
				base.Tables.Add(new BookReceived.BookRecievedDetailsDataTable(dataSet.Tables["BookRecievedDetails"]));
			}
			base.DataSetName = dataSet.DataSetName;
			base.Prefix = dataSet.Prefix;
			base.Namespace = dataSet.Namespace;
			base.Locale = dataSet.Locale;
			base.CaseSensitive = dataSet.CaseSensitive;
			base.EnforceConstraints = dataSet.EnforceConstraints;
			base.Merge(dataSet, false, MissingSchemaAction.Add);
			this.InitVars();
		}
		else
		{
			base.ReadXmlSchema(new XmlTextReader(new StringReader(s)));
		}
		base.GetSerializationData(info, context);
		CollectionChangeEventHandler value2 = new CollectionChangeEventHandler(this.SchemaChanged);
		base.Tables.CollectionChanged += value2;
		this.Relations.CollectionChanged += value2;
	}
	[DebuggerNonUserCode]
	protected override void InitializeDerivedDataSet()
	{
		base.BeginInit();
		this.InitClass();
		base.EndInit();
	}
	[DebuggerNonUserCode]
	public override DataSet Clone()
	{
		BookReceived bookReceived = (BookReceived)base.Clone();
		bookReceived.InitVars();
		bookReceived.SchemaSerializationMode = this.SchemaSerializationMode;
		return bookReceived;
	}
	[DebuggerNonUserCode]
	protected override bool ShouldSerializeTables()
	{
		return false;
	}
	[DebuggerNonUserCode]
	protected override bool ShouldSerializeRelations()
	{
		return false;
	}
	[DebuggerNonUserCode]
	protected override void ReadXmlSerializable(XmlReader reader)
	{
		if (base.DetermineSchemaSerializationMode(reader) == SchemaSerializationMode.IncludeSchema)
		{
			this.Reset();
			DataSet dataSet = new DataSet();
			dataSet.ReadXml(reader);
			if (dataSet.Tables["BookRecievedDetails"] != null)
			{
				base.Tables.Add(new BookReceived.BookRecievedDetailsDataTable(dataSet.Tables["BookRecievedDetails"]));
			}
			base.DataSetName = dataSet.DataSetName;
			base.Prefix = dataSet.Prefix;
			base.Namespace = dataSet.Namespace;
			base.Locale = dataSet.Locale;
			base.CaseSensitive = dataSet.CaseSensitive;
			base.EnforceConstraints = dataSet.EnforceConstraints;
			base.Merge(dataSet, false, MissingSchemaAction.Add);
			this.InitVars();
			return;
		}
		base.ReadXml(reader);
		this.InitVars();
	}
	[DebuggerNonUserCode]
	protected override XmlSchema GetSchemaSerializable()
	{
		MemoryStream memoryStream = new MemoryStream();
		base.WriteXmlSchema(new XmlTextWriter(memoryStream, null));
		memoryStream.Position = 0L;
		return XmlSchema.Read(new XmlTextReader(memoryStream), null);
	}
	[DebuggerNonUserCode]
	internal void InitVars()
	{
		this.InitVars(true);
	}
	[DebuggerNonUserCode]
	internal void InitVars(bool initTable)
	{
		this.tableBookRecievedDetails = (BookReceived.BookRecievedDetailsDataTable)base.Tables["BookRecievedDetails"];
		if (initTable && this.tableBookRecievedDetails != null)
		{
			this.tableBookRecievedDetails.InitVars();
		}
	}
	[DebuggerNonUserCode]
	private void InitClass()
	{
		base.DataSetName = "BookReceived";
		base.Prefix = "";
		base.Namespace = "http://tempuri.org/BookReceived.xsd";
		base.EnforceConstraints = true;
		this.SchemaSerializationMode = SchemaSerializationMode.IncludeSchema;
		this.tableBookRecievedDetails = new BookReceived.BookRecievedDetailsDataTable();
		base.Tables.Add(this.tableBookRecievedDetails);
	}
	[DebuggerNonUserCode]
	private bool ShouldSerializeBookRecievedDetails()
	{
		return false;
	}
	[DebuggerNonUserCode]
	private void SchemaChanged(object sender, CollectionChangeEventArgs e)
	{
		if (e.Action == CollectionChangeAction.Remove)
		{
			this.InitVars();
		}
	}
	[DebuggerNonUserCode]
	public static XmlSchemaComplexType GetTypedDataSetSchema(XmlSchemaSet xs)
	{
		BookReceived bookReceived = new BookReceived();
		XmlSchemaComplexType xmlSchemaComplexType = new XmlSchemaComplexType();
		XmlSchemaSequence xmlSchemaSequence = new XmlSchemaSequence();
		XmlSchemaAny xmlSchemaAny = new XmlSchemaAny();
		xmlSchemaAny.Namespace = bookReceived.Namespace;
		xmlSchemaSequence.Items.Add(xmlSchemaAny);
		xmlSchemaComplexType.Particle = xmlSchemaSequence;
		XmlSchema schemaSerializable = bookReceived.GetSchemaSerializable();
		if (xs.Contains(schemaSerializable.TargetNamespace))
		{
			MemoryStream memoryStream = new MemoryStream();
			MemoryStream memoryStream2 = new MemoryStream();
			try
			{
				schemaSerializable.Write(memoryStream);
				IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
				while (enumerator.MoveNext())
				{
					XmlSchema xmlSchema = (XmlSchema)enumerator.Current;
					memoryStream2.SetLength(0L);
					xmlSchema.Write(memoryStream2);
					if (memoryStream.Length == memoryStream2.Length)
					{
						memoryStream.Position = 0L;
						memoryStream2.Position = 0L;
						while (memoryStream.Position != memoryStream.Length && memoryStream.ReadByte() == memoryStream2.ReadByte())
						{
						}
						if (memoryStream.Position == memoryStream.Length)
						{
							return xmlSchemaComplexType;
						}
					}
				}
			}
			finally
			{
				if (memoryStream != null)
				{
					memoryStream.Close();
				}
				if (memoryStream2 != null)
				{
					memoryStream2.Close();
				}
			}
		}
		xs.Add(schemaSerializable);
		return xmlSchemaComplexType;
	}
}
