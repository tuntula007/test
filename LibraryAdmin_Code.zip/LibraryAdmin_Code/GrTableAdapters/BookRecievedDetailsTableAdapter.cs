using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics;
namespace GrTableAdapters
{
	[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0"), DataObject(true), HelpKeyword("vs.data.TableAdapter"), Designer("Microsoft.VSDesigner.DataSource.Design.TableAdapterDesigner, Microsoft.VSDesigner, Version=8.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a"), DesignerCategory("code"), ToolboxItem(true)]
	public class BookRecievedDetailsTableAdapter : Component
	{
		private SqlDataAdapter _adapter;
		private SqlConnection _connection;
		private SqlCommand[] _commandCollection;
		private bool _clearBeforeFill;
		[DebuggerNonUserCode]
		private SqlDataAdapter Adapter
		{
			get
			{
				if (this._adapter == null)
				{
					this.InitAdapter();
				}
				return this._adapter;
			}
		}
		[DebuggerNonUserCode]
		internal SqlConnection Connection
		{
			get
			{
				if (this._connection == null)
				{
					this.InitConnection();
				}
				return this._connection;
			}
			set
			{
				this._connection = value;
				if (this.Adapter.InsertCommand != null)
				{
					this.Adapter.InsertCommand.Connection = value;
				}
				if (this.Adapter.DeleteCommand != null)
				{
					this.Adapter.DeleteCommand.Connection = value;
				}
				if (this.Adapter.UpdateCommand != null)
				{
					this.Adapter.UpdateCommand.Connection = value;
				}
				for (int i = 0; i < this.CommandCollection.Length; i++)
				{
					if (this.CommandCollection[i] != null)
					{
						this.CommandCollection[i].Connection = value;
					}
				}
			}
		}
		[DebuggerNonUserCode]
		protected SqlCommand[] CommandCollection
		{
			get
			{
				if (this._commandCollection == null)
				{
					this.InitCommandCollection();
				}
				return this._commandCollection;
			}
		}
		[DebuggerNonUserCode]
		public bool ClearBeforeFill
		{
			get
			{
				return this._clearBeforeFill;
			}
			set
			{
				this._clearBeforeFill = value;
			}
		}
		[DebuggerNonUserCode]
		public BookRecievedDetailsTableAdapter()
		{
			this.ClearBeforeFill = true;
		}
		[DebuggerNonUserCode]
		private void InitAdapter()
		{
			this._adapter = new SqlDataAdapter();
			DataTableMapping dataTableMapping = new DataTableMapping();
			dataTableMapping.SourceTable = "Table";
			dataTableMapping.DataSetTable = "BookRecievedDetails";
			dataTableMapping.ColumnMappings.Add("Srn", "Srn");
			dataTableMapping.ColumnMappings.Add("OrderNo", "OrderNo");
			dataTableMapping.ColumnMappings.Add("Title", "Title");
			dataTableMapping.ColumnMappings.Add("Author", "Author");
			dataTableMapping.ColumnMappings.Add("Publisher", "Publisher");
			dataTableMapping.ColumnMappings.Add("BookType", "BookType");
			dataTableMapping.ColumnMappings.Add("Dealer", "Dealer");
			dataTableMapping.ColumnMappings.Add("AquisitionType", "AquisitionType");
			dataTableMapping.ColumnMappings.Add("ReceivedGroup", "ReceivedGroup");
			dataTableMapping.ColumnMappings.Add("SetupBy", "SetupBy");
			dataTableMapping.ColumnMappings.Add("Datesetup", "Datesetup");
			dataTableMapping.ColumnMappings.Add("ReceivedStatus", "ReceivedStatus");
			dataTableMapping.ColumnMappings.Add("CatalogStatus", "CatalogStatus");
			dataTableMapping.ColumnMappings.Add("Copies", "Copies");
			dataTableMapping.ColumnMappings.Add("PublishedDate", "PublishedDate");
			dataTableMapping.ColumnMappings.Add("PublishedYear", "PublishedYear");
			dataTableMapping.ColumnMappings.Add("Vol", "Vol");
			dataTableMapping.ColumnMappings.Add("No", "No");
			dataTableMapping.ColumnMappings.Add("Edition", "Edition");
			dataTableMapping.ColumnMappings.Add("Cost", "Cost");
			dataTableMapping.ColumnMappings.Add("TotalCost", "TotalCost");
			dataTableMapping.ColumnMappings.Add("ISBN", "ISBN");
			dataTableMapping.ColumnMappings.Add("ACCNO", "ACCNO");
			dataTableMapping.ColumnMappings.Add("GRNumber", "GRNumber");
			dataTableMapping.ColumnMappings.Add("TransId", "TransId");
			this._adapter.TableMappings.Add(dataTableMapping);
			this._adapter.InsertCommand = new SqlCommand();
			this._adapter.InsertCommand.Connection = this.Connection;
			this._adapter.InsertCommand.CommandText = "INSERT INTO [dbo].[BookRecievedDetails] ([OrderNo], [Title], [Author], [Publisher], [BookType], [Dealer], [AquisitionType], [ReceivedGroup], [SetupBy], [Datesetup], [ReceivedStatus], [CatalogStatus], [Copies], [PublishedDate], [PublishedYear], [Vol], [No], [Edition], [Cost], [TotalCost], [ISBN], [ACCNO], [GRNumber], [TransId]) VALUES (@OrderNo, @Title, @Author, @Publisher, @BookType, @Dealer, @AquisitionType, @ReceivedGroup, @SetupBy, @Datesetup, @ReceivedStatus, @CatalogStatus, @Copies, @PublishedDate, @PublishedYear, @Vol, @No, @Edition, @Cost, @TotalCost, @ISBN, @ACCNO, @GRNumber, @TransId)";
			this._adapter.InsertCommand.CommandType = CommandType.Text;
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@OrderNo", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "OrderNo", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Title", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Author", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Author", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Publisher", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Publisher", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@BookType", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "BookType", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Dealer", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Dealer", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@AquisitionType", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "AquisitionType", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@ReceivedGroup", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "ReceivedGroup", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@SetupBy", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "SetupBy", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Datesetup", SqlDbType.DateTime, 0, ParameterDirection.Input, 0, 0, "Datesetup", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@ReceivedStatus", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "ReceivedStatus", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@CatalogStatus", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "CatalogStatus", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Copies", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "Copies", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@PublishedDate", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "PublishedDate", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@PublishedYear", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "PublishedYear", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Vol", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "Vol", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@No", SqlDbType.Int, 0, ParameterDirection.Input, 0, 0, "No", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Edition", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "Edition", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@Cost", SqlDbType.Money, 0, ParameterDirection.Input, 0, 0, "Cost", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@TotalCost", SqlDbType.Money, 0, ParameterDirection.Input, 0, 0, "TotalCost", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@ISBN", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "ISBN", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@ACCNO", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "ACCNO", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@GRNumber", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "GRNumber", DataRowVersion.Current, false, null, "", "", ""));
			this._adapter.InsertCommand.Parameters.Add(new SqlParameter("@TransId", SqlDbType.NVarChar, 0, ParameterDirection.Input, 0, 0, "TransId", DataRowVersion.Current, false, null, "", "", ""));
		}
		[DebuggerNonUserCode]
		private void InitConnection()
		{
			this._connection = new SqlConnection();
			this._connection.ConnectionString = ConfigurationManager.ConnectionStrings["LibraryAutomationConnectionString"].ConnectionString;
		}
		[DebuggerNonUserCode]
		private void InitCommandCollection()
		{
			this._commandCollection = new SqlCommand[1];
			this._commandCollection[0] = new SqlCommand();
			this._commandCollection[0].Connection = this.Connection;
			this._commandCollection[0].CommandText = "SELECT Srn, OrderNo, Title, Author, Publisher, BookType, Dealer, AquisitionType, ReceivedGroup, SetupBy, Datesetup, ReceivedStatus, CatalogStatus, Copies, PublishedDate, PublishedYear, Vol, No, Edition, Cost, TotalCost, ISBN, ACCNO, GRNumber, TransId FROM dbo.BookRecievedDetails";
			this._commandCollection[0].CommandType = CommandType.Text;
		}
		[DataObjectMethod(DataObjectMethodType.Fill, true), HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Fill(Gr.BookRecievedDetailsDataTable dataTable)
		{
			this.Adapter.SelectCommand = this.CommandCollection[0];
			if (this.ClearBeforeFill)
			{
				dataTable.Clear();
			}
			return this.Adapter.Fill(dataTable);
		}
		[DataObjectMethod(DataObjectMethodType.Select, true), HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual Gr.BookRecievedDetailsDataTable GetData()
		{
			this.Adapter.SelectCommand = this.CommandCollection[0];
			Gr.BookRecievedDetailsDataTable bookRecievedDetailsDataTable = new Gr.BookRecievedDetailsDataTable();
			this.Adapter.Fill(bookRecievedDetailsDataTable);
			return bookRecievedDetailsDataTable;
		}
		[HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Update(Gr.BookRecievedDetailsDataTable dataTable)
		{
			return this.Adapter.Update(dataTable);
		}
		[HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Update(Gr dataSet)
		{
			return this.Adapter.Update(dataSet, "BookRecievedDetails");
		}
		[HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Update(DataRow dataRow)
		{
			return this.Adapter.Update(new DataRow[]
			{
				dataRow
			});
		}
		[HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Update(DataRow[] dataRows)
		{
			return this.Adapter.Update(dataRows);
		}
		[DataObjectMethod(DataObjectMethodType.Insert, true), HelpKeyword("vs.data.TableAdapter"), DebuggerNonUserCode]
		public virtual int Insert(string OrderNo, string Title, string Author, string Publisher, string BookType, string Dealer, string AquisitionType, string ReceivedGroup, string SetupBy, DateTime? Datesetup, int ReceivedStatus, int CatalogStatus, int? Copies, string PublishedDate, string PublishedYear, int? Vol, int? No, string Edition, decimal? Cost, decimal? TotalCost, string ISBN, string ACCNO, string GRNumber, string TransId)
		{
			if (OrderNo == null)
			{
				throw new ArgumentNullException("OrderNo");
			}
			this.Adapter.InsertCommand.Parameters[0].Value = OrderNo;
			if (Title == null)
			{
				this.Adapter.InsertCommand.Parameters[1].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[1].Value = Title;
			}
			if (Author == null)
			{
				this.Adapter.InsertCommand.Parameters[2].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[2].Value = Author;
			}
			if (Publisher == null)
			{
				this.Adapter.InsertCommand.Parameters[3].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[3].Value = Publisher;
			}
			if (BookType == null)
			{
				this.Adapter.InsertCommand.Parameters[4].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[4].Value = BookType;
			}
			if (Dealer == null)
			{
				this.Adapter.InsertCommand.Parameters[5].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[5].Value = Dealer;
			}
			if (AquisitionType == null)
			{
				this.Adapter.InsertCommand.Parameters[6].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[6].Value = AquisitionType;
			}
			if (ReceivedGroup == null)
			{
				this.Adapter.InsertCommand.Parameters[7].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[7].Value = ReceivedGroup;
			}
			if (SetupBy == null)
			{
				this.Adapter.InsertCommand.Parameters[8].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[8].Value = SetupBy;
			}
			if (Datesetup.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[9].Value = Datesetup.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[9].Value = DBNull.Value;
			}
			this.Adapter.InsertCommand.Parameters[10].Value = ReceivedStatus;
			this.Adapter.InsertCommand.Parameters[11].Value = CatalogStatus;
			if (Copies.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[12].Value = Copies.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[12].Value = DBNull.Value;
			}
			if (PublishedDate == null)
			{
				this.Adapter.InsertCommand.Parameters[13].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[13].Value = PublishedDate;
			}
			if (PublishedYear == null)
			{
				this.Adapter.InsertCommand.Parameters[14].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[14].Value = PublishedYear;
			}
			if (Vol.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[15].Value = Vol.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[15].Value = DBNull.Value;
			}
			if (No.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[16].Value = No.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[16].Value = DBNull.Value;
			}
			if (Edition == null)
			{
				this.Adapter.InsertCommand.Parameters[17].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[17].Value = Edition;
			}
			if (Cost.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[18].Value = Cost.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[18].Value = DBNull.Value;
			}
			if (TotalCost.HasValue)
			{
				this.Adapter.InsertCommand.Parameters[19].Value = TotalCost.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[19].Value = DBNull.Value;
			}
			if (ISBN == null)
			{
				this.Adapter.InsertCommand.Parameters[20].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[20].Value = ISBN;
			}
			if (ACCNO == null)
			{
				this.Adapter.InsertCommand.Parameters[21].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[21].Value = ACCNO;
			}
			if (GRNumber == null)
			{
				this.Adapter.InsertCommand.Parameters[22].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[22].Value = GRNumber;
			}
			if (TransId == null)
			{
				this.Adapter.InsertCommand.Parameters[23].Value = DBNull.Value;
			}
			else
			{
				this.Adapter.InsertCommand.Parameters[23].Value = TransId;
			}
			ConnectionState state = this.Adapter.InsertCommand.Connection.State;
			if ((this.Adapter.InsertCommand.Connection.State & ConnectionState.Open) != ConnectionState.Open)
			{
				this.Adapter.InsertCommand.Connection.Open();
			}
			int result;
			try
			{
				int num = this.Adapter.InsertCommand.ExecuteNonQuery();
				result = num;
			}
			finally
			{
				if (state == ConnectionState.Closed)
				{
					this.Adapter.InsertCommand.Connection.Close();
				}
			}
			return result;
		}
	}
}
