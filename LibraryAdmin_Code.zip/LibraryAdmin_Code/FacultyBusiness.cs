using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
[Serializable]
public class FacultyBusiness
{
	private static string str = ConfigurationManager.AppSettings["conn"];
	public static DataSet GetFacultys()
	{
		DataSet dataSet = new DataSet();
		try
		{
			string selectCommandText = "SELECT [FacultyName],[FacultyID] FROM [Faculty]";
			SqlConnection sqlConnection = new SqlConnection(FacultyBusiness.str);
			sqlConnection.Open();
			SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(selectCommandText, sqlConnection);
			sqlDataAdapter.Fill(dataSet);
			sqlConnection.Dispose();
			sqlConnection.Close();
		}
		catch (Exception ex)
		{
			string arg_44_0 = ex.Message;
		}
		return dataSet;
	}
	public static DataSet GetDept(string factid)
	{
		DataSet dataSet = new DataSet();
		try
		{
			string selectCommandText = "SELECT [DepartmentName] FROM [Departments] where [FacultyID]='" + factid + "'";
			SqlConnection sqlConnection = new SqlConnection(FacultyBusiness.str);
			sqlConnection.Open();
			SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(selectCommandText, sqlConnection);
			sqlDataAdapter.Fill(dataSet);
			sqlConnection.Dispose();
			sqlConnection.Close();
		}
		catch (Exception ex)
		{
			string arg_4F_0 = ex.Message;
		}
		return dataSet;
	}
	public static DataSet GetDuration()
	{
		DataSet dataSet = new DataSet();
		try
		{
			string selectCommandText = "SELECT [Duration] FROM [CourseDuration]";
			SqlConnection sqlConnection = new SqlConnection(FacultyBusiness.str);
			sqlConnection.Open();
			SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(selectCommandText, sqlConnection);
			sqlDataAdapter.Fill(dataSet);
			sqlConnection.Dispose();
			sqlConnection.Close();
		}
		catch (Exception ex)
		{
			string arg_44_0 = ex.Message;
		}
		return dataSet;
	}
	public static DataSet GetProg()
	{
		DataSet dataSet = new DataSet();
		try
		{
			string selectCommandText = "SELECT [Programme] FROM [SchProgramme]";
			SqlConnection sqlConnection = new SqlConnection(FacultyBusiness.str);
			sqlConnection.Open();
			SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(selectCommandText, sqlConnection);
			sqlDataAdapter.Fill(dataSet);
			sqlConnection.Dispose();
			sqlConnection.Close();
		}
		catch (Exception ex)
		{
			string arg_44_0 = ex.Message;
		}
		return dataSet;
	}
	public static DataSet GetHonor()
	{
		DataSet dataSet = new DataSet();
		try
		{
			string selectCommandText = "SELECT [Honour] FROM [CourseHonour]";
			SqlConnection sqlConnection = new SqlConnection(FacultyBusiness.str);
			sqlConnection.Open();
			SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(selectCommandText, sqlConnection);
			sqlDataAdapter.Fill(dataSet);
			sqlConnection.Dispose();
			sqlConnection.Close();
		}
		catch (Exception ex)
		{
			string arg_44_0 = ex.Message;
		}
		return dataSet;
	}
	public static DataSet GetStudyMode()
	{
		DataSet dataSet = new DataSet();
		try
		{
			string selectCommandText = "SELECT [ModeOfStudy] FROM [ModeOfStudy]";
			SqlConnection sqlConnection = new SqlConnection(FacultyBusiness.str);
			sqlConnection.Open();
			SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(selectCommandText, sqlConnection);
			sqlDataAdapter.Fill(dataSet);
			sqlConnection.Dispose();
			sqlConnection.Close();
		}
		catch (Exception ex)
		{
			string arg_44_0 = ex.Message;
		}
		return dataSet;
	}
	public static DataSet GetLevel()
	{
		DataSet dataSet = new DataSet();
		try
		{
			string selectCommandText = "SELECT [AcademicLevel] FROM [Levels] order by [AcademicLevel] asc";
			SqlConnection sqlConnection = new SqlConnection(FacultyBusiness.str);
			sqlConnection.Open();
			SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(selectCommandText, sqlConnection);
			sqlDataAdapter.Fill(dataSet);
			sqlConnection.Dispose();
			sqlConnection.Close();
		}
		catch (Exception ex)
		{
			string arg_44_0 = ex.Message;
		}
		return dataSet;
	}
	public static DataSet GetSemester()
	{
		DataSet dataSet = new DataSet();
		try
		{
			string selectCommandText = "SELECT [Semester] FROM [Semesters] order by [Semester] asc";
			SqlConnection sqlConnection = new SqlConnection(FacultyBusiness.str);
			sqlConnection.Open();
			SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(selectCommandText, sqlConnection);
			sqlDataAdapter.Fill(dataSet);
			sqlConnection.Dispose();
			sqlConnection.Close();
		}
		catch (Exception ex)
		{
			string arg_44_0 = ex.Message;
		}
		return dataSet;
	}
	public static DataSet GetCourseType()
	{
		DataSet dataSet = new DataSet();
		try
		{
			string selectCommandText = "SELECT [CourseType] FROM [CourseTypes] order by [CourseType] asc";
			SqlConnection sqlConnection = new SqlConnection(FacultyBusiness.str);
			sqlConnection.Open();
			SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(selectCommandText, sqlConnection);
			sqlDataAdapter.Fill(dataSet);
			sqlConnection.Dispose();
			sqlConnection.Close();
		}
		catch (Exception ex)
		{
			string arg_44_0 = ex.Message;
		}
		return dataSet;
	}
	public static DataSet GetGroups()
	{
		DataSet dataSet = new DataSet();
		try
		{
			string selectCommandText = "SELECT [Usergroup] FROM [TUsergroups] order by [Usergroup] asc";
			SqlConnection sqlConnection = new SqlConnection(FacultyBusiness.str);
			sqlConnection.Open();
			SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(selectCommandText, sqlConnection);
			sqlDataAdapter.Fill(dataSet);
			sqlConnection.Dispose();
			sqlConnection.Close();
		}
		catch (Exception ex)
		{
			string arg_44_0 = ex.Message;
		}
		return dataSet;
	}
}
