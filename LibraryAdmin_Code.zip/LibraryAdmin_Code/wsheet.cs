using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;
[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0"), HelpKeyword("vs.data.DataSet"), DesignerCategory("code"), ToolboxItem(true), XmlRoot("wsheet"), XmlSchemaProvider("GetTypedDataSetSchema")]
[Serializable]
public class wsheet : DataSet
{
	public delegate void BookDetailsRowChangeEventHandler(object sender, wsheet.BookDetailsRowChangeEvent e);
	[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0"), XmlSchemaProvider("GetTypedTableSchema")]
	[Serializable]
	public class BookDetailsDataTable : TypedTableBase<wsheet.BookDetailsRow>
	{
		private DataColumn columnSrn;
		private DataColumn columnOrderNo;
		private DataColumn columnTitle;
		private DataColumn columnAuthor;
		private DataColumn columnPublisher;
		private DataColumn columnBookType;
		private DataColumn columnDealer;
		private DataColumn columnAquisitionType;
		private DataColumn columnReceivedGroup;
		private DataColumn columnSetupBy;
		private DataColumn columnDatesetup;
		private DataColumn columnReceivedStatus;
		private DataColumn columnCatalogStatus;
		private DataColumn columnCopies;
		private DataColumn columnPublishedDate;
		private DataColumn columnPublishedYear;
		private DataColumn columnVol;
		private DataColumn columnNo;
		private DataColumn columnEdition;
		private DataColumn columnCost;
		private DataColumn columnTotalCost;
		private DataColumn columnISBN;
		private DataColumn columnACCNO;
		private DataColumn columnGRNumber;
		private DataColumn columnAvailability;
		private DataColumn columnAccYear;
		private DataColumn columnParallelTitle;
		private DataColumn columnEditors;
		private DataColumn columnMeetings;
		private DataColumn columnPubPlace;
		private DataColumn columnClassNo;
		private DataColumn columnLanguage;
		private DataColumn columnBinding;
		private DataColumn columnPages;
		private DataColumn columnSpineLabel;
		private DataColumn columnPubType;
		private DataColumn columnMedium;
		private DataColumn columnAbstract;
		private DataColumn columnShelfRef;
		private DataColumn columnKeywords;
		private DataColumn columnSubject;
		private DataColumn columnLibraryBranch;
		private DataColumn columnimageurl;
		private DataColumn columnNavigatelink;
		private DataColumn columnCatLogNo;
		private DataColumn columnObject;
		public event wsheet.BookDetailsRowChangeEventHandler BookDetailsRowChanging
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.BookDetailsRowChanging = (wsheet.BookDetailsRowChangeEventHandler)Delegate.Combine(this.BookDetailsRowChanging, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.BookDetailsRowChanging = (wsheet.BookDetailsRowChangeEventHandler)Delegate.Remove(this.BookDetailsRowChanging, value);
			}
		}
		public event wsheet.BookDetailsRowChangeEventHandler BookDetailsRowChanged
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.BookDetailsRowChanged = (wsheet.BookDetailsRowChangeEventHandler)Delegate.Combine(this.BookDetailsRowChanged, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.BookDetailsRowChanged = (wsheet.BookDetailsRowChangeEventHandler)Delegate.Remove(this.BookDetailsRowChanged, value);
			}
		}
		public event wsheet.BookDetailsRowChangeEventHandler BookDetailsRowDeleting
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.BookDetailsRowDeleting = (wsheet.BookDetailsRowChangeEventHandler)Delegate.Combine(this.BookDetailsRowDeleting, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.BookDetailsRowDeleting = (wsheet.BookDetailsRowChangeEventHandler)Delegate.Remove(this.BookDetailsRowDeleting, value);
			}
		}
		public event wsheet.BookDetailsRowChangeEventHandler BookDetailsRowDeleted
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.BookDetailsRowDeleted = (wsheet.BookDetailsRowChangeEventHandler)Delegate.Combine(this.BookDetailsRowDeleted, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.BookDetailsRowDeleted = (wsheet.BookDetailsRowChangeEventHandler)Delegate.Remove(this.BookDetailsRowDeleted, value);
			}
		}
		[DebuggerNonUserCode]
		public DataColumn SrnColumn
		{
			get
			{
				return this.columnSrn;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn OrderNoColumn
		{
			get
			{
				return this.columnOrderNo;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn TitleColumn
		{
			get
			{
				return this.columnTitle;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn AuthorColumn
		{
			get
			{
				return this.columnAuthor;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn PublisherColumn
		{
			get
			{
				return this.columnPublisher;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn BookTypeColumn
		{
			get
			{
				return this.columnBookType;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn DealerColumn
		{
			get
			{
				return this.columnDealer;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn AquisitionTypeColumn
		{
			get
			{
				return this.columnAquisitionType;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn ReceivedGroupColumn
		{
			get
			{
				return this.columnReceivedGroup;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn SetupByColumn
		{
			get
			{
				return this.columnSetupBy;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn DatesetupColumn
		{
			get
			{
				return this.columnDatesetup;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn ReceivedStatusColumn
		{
			get
			{
				return this.columnReceivedStatus;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn CatalogStatusColumn
		{
			get
			{
				return this.columnCatalogStatus;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn CopiesColumn
		{
			get
			{
				return this.columnCopies;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn PublishedDateColumn
		{
			get
			{
				return this.columnPublishedDate;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn PublishedYearColumn
		{
			get
			{
				return this.columnPublishedYear;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn VolColumn
		{
			get
			{
				return this.columnVol;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn NoColumn
		{
			get
			{
				return this.columnNo;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn EditionColumn
		{
			get
			{
				return this.columnEdition;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn CostColumn
		{
			get
			{
				return this.columnCost;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn TotalCostColumn
		{
			get
			{
				return this.columnTotalCost;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn ISBNColumn
		{
			get
			{
				return this.columnISBN;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn ACCNOColumn
		{
			get
			{
				return this.columnACCNO;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn GRNumberColumn
		{
			get
			{
				return this.columnGRNumber;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn AvailabilityColumn
		{
			get
			{
				return this.columnAvailability;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn AccYearColumn
		{
			get
			{
				return this.columnAccYear;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn ParallelTitleColumn
		{
			get
			{
				return this.columnParallelTitle;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn EditorsColumn
		{
			get
			{
				return this.columnEditors;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn MeetingsColumn
		{
			get
			{
				return this.columnMeetings;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn PubPlaceColumn
		{
			get
			{
				return this.columnPubPlace;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn ClassNoColumn
		{
			get
			{
				return this.columnClassNo;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn LanguageColumn
		{
			get
			{
				return this.columnLanguage;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn BindingColumn
		{
			get
			{
				return this.columnBinding;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn PagesColumn
		{
			get
			{
				return this.columnPages;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn SpineLabelColumn
		{
			get
			{
				return this.columnSpineLabel;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn PubTypeColumn
		{
			get
			{
				return this.columnPubType;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn MediumColumn
		{
			get
			{
				return this.columnMedium;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn AbstractColumn
		{
			get
			{
				return this.columnAbstract;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn ShelfRefColumn
		{
			get
			{
				return this.columnShelfRef;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn KeywordsColumn
		{
			get
			{
				return this.columnKeywords;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn SubjectColumn
		{
			get
			{
				return this.columnSubject;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn LibraryBranchColumn
		{
			get
			{
				return this.columnLibraryBranch;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn imageurlColumn
		{
			get
			{
				return this.columnimageurl;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn NavigatelinkColumn
		{
			get
			{
				return this.columnNavigatelink;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn CatLogNoColumn
		{
			get
			{
				return this.columnCatLogNo;
			}
		}
		[DebuggerNonUserCode]
		public DataColumn ObjectColumn
		{
			get
			{
				return this.columnObject;
			}
		}
		[Browsable(false), DebuggerNonUserCode]
		public int Count
		{
			get
			{
				return base.Rows.Count;
			}
		}
		[DebuggerNonUserCode]
		public wsheet.BookDetailsRow this[int index]
		{
			get
			{
				return (wsheet.BookDetailsRow)base.Rows[index];
			}
		}
		[DebuggerNonUserCode]
		public BookDetailsDataTable()
		{
			base.TableName = "BookDetails";
			this.BeginInit();
			this.InitClass();
			this.EndInit();
		}
		[DebuggerNonUserCode]
		internal BookDetailsDataTable(DataTable table)
		{
			base.TableName = table.TableName;
			if (table.CaseSensitive != table.DataSet.CaseSensitive)
			{
				base.CaseSensitive = table.CaseSensitive;
			}
			if (table.Locale.ToString() != table.DataSet.Locale.ToString())
			{
				base.Locale = table.Locale;
			}
			if (table.Namespace != table.DataSet.Namespace)
			{
				base.Namespace = table.Namespace;
			}
			base.Prefix = table.Prefix;
			base.MinimumCapacity = table.MinimumCapacity;
		}
		[DebuggerNonUserCode]
		protected BookDetailsDataTable(SerializationInfo info, StreamingContext context) : base(info, context)
		{
			this.InitVars();
		}
		[DebuggerNonUserCode]
		public void AddBookDetailsRow(wsheet.BookDetailsRow row)
		{
			base.Rows.Add(row);
		}
		[DebuggerNonUserCode]
		public wsheet.BookDetailsRow AddBookDetailsRow(string OrderNo, string Title, string Author, string Publisher, string BookType, string Dealer, string AquisitionType, string ReceivedGroup, string SetupBy, DateTime Datesetup, int ReceivedStatus, int CatalogStatus, int Copies, string PublishedDate, string PublishedYear, int Vol, int No, string Edition, decimal Cost, decimal TotalCost, string ISBN, string ACCNO, string GRNumber, int Availability, string AccYear, string ParallelTitle, string Editors, string Meetings, string PubPlace, string ClassNo, string Language, string Binding, string Pages, string SpineLabel, string PubType, string Medium, string Abstract, string ShelfRef, string Keywords, string Subject, string LibraryBranch, string imageurl, string Navigatelink, string CatLogNo, string Object)
		{
			wsheet.BookDetailsRow bookDetailsRow = (wsheet.BookDetailsRow)base.NewRow();
			object[] itemArray = new object[]
			{
				null,
				OrderNo,
				Title,
				Author,
				Publisher,
				BookType,
				Dealer,
				AquisitionType,
				ReceivedGroup,
				SetupBy,
				Datesetup,
				ReceivedStatus,
				CatalogStatus,
				Copies,
				PublishedDate,
				PublishedYear,
				Vol,
				No,
				Edition,
				Cost,
				TotalCost,
				ISBN,
				ACCNO,
				GRNumber,
				Availability,
				AccYear,
				ParallelTitle,
				Editors,
				Meetings,
				PubPlace,
				ClassNo,
				Language,
				Binding,
				Pages,
				SpineLabel,
				PubType,
				Medium,
				Abstract,
				ShelfRef,
				Keywords,
				Subject,
				LibraryBranch,
				imageurl,
				Navigatelink,
				CatLogNo,
				Object
			};
			bookDetailsRow.ItemArray = itemArray;
			base.Rows.Add(bookDetailsRow);
			return bookDetailsRow;
		}
		[DebuggerNonUserCode]
		public wsheet.BookDetailsRow FindByACCNO(string ACCNO)
		{
			return (wsheet.BookDetailsRow)base.Rows.Find(new object[]
			{
				ACCNO
			});
		}
		[DebuggerNonUserCode]
		public override DataTable Clone()
		{
			wsheet.BookDetailsDataTable bookDetailsDataTable = (wsheet.BookDetailsDataTable)base.Clone();
			bookDetailsDataTable.InitVars();
			return bookDetailsDataTable;
		}
		[DebuggerNonUserCode]
		protected override DataTable CreateInstance()
		{
			return new wsheet.BookDetailsDataTable();
		}
		[DebuggerNonUserCode]
		internal void InitVars()
		{
			this.columnSrn = base.Columns["Srn"];
			this.columnOrderNo = base.Columns["OrderNo"];
			this.columnTitle = base.Columns["Title"];
			this.columnAuthor = base.Columns["Author"];
			this.columnPublisher = base.Columns["Publisher"];
			this.columnBookType = base.Columns["BookType"];
			this.columnDealer = base.Columns["Dealer"];
			this.columnAquisitionType = base.Columns["AquisitionType"];
			this.columnReceivedGroup = base.Columns["ReceivedGroup"];
			this.columnSetupBy = base.Columns["SetupBy"];
			this.columnDatesetup = base.Columns["Datesetup"];
			this.columnReceivedStatus = base.Columns["ReceivedStatus"];
			this.columnCatalogStatus = base.Columns["CatalogStatus"];
			this.columnCopies = base.Columns["Copies"];
			this.columnPublishedDate = base.Columns["PublishedDate"];
			this.columnPublishedYear = base.Columns["PublishedYear"];
			this.columnVol = base.Columns["Vol"];
			this.columnNo = base.Columns["No"];
			this.columnEdition = base.Columns["Edition"];
			this.columnCost = base.Columns["Cost"];
			this.columnTotalCost = base.Columns["TotalCost"];
			this.columnISBN = base.Columns["ISBN"];
			this.columnACCNO = base.Columns["ACCNO"];
			this.columnGRNumber = base.Columns["GRNumber"];
			this.columnAvailability = base.Columns["Availability"];
			this.columnAccYear = base.Columns["AccYear"];
			this.columnParallelTitle = base.Columns["ParallelTitle"];
			this.columnEditors = base.Columns["Editors"];
			this.columnMeetings = base.Columns["Meetings"];
			this.columnPubPlace = base.Columns["PubPlace"];
			this.columnClassNo = base.Columns["ClassNo"];
			this.columnLanguage = base.Columns["Language"];
			this.columnBinding = base.Columns["Binding"];
			this.columnPages = base.Columns["Pages"];
			this.columnSpineLabel = base.Columns["SpineLabel"];
			this.columnPubType = base.Columns["PubType"];
			this.columnMedium = base.Columns["Medium"];
			this.columnAbstract = base.Columns["Abstract"];
			this.columnShelfRef = base.Columns["ShelfRef"];
			this.columnKeywords = base.Columns["Keywords"];
			this.columnSubject = base.Columns["Subject"];
			this.columnLibraryBranch = base.Columns["LibraryBranch"];
			this.columnimageurl = base.Columns["imageurl"];
			this.columnNavigatelink = base.Columns["Navigatelink"];
			this.columnCatLogNo = base.Columns["CatLogNo"];
			this.columnObject = base.Columns["Object"];
		}
		[DebuggerNonUserCode]
		private void InitClass()
		{
			this.columnSrn = new DataColumn("Srn", typeof(decimal), null, MappingType.Element);
			base.Columns.Add(this.columnSrn);
			this.columnOrderNo = new DataColumn("OrderNo", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnOrderNo);
			this.columnTitle = new DataColumn("Title", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnTitle);
			this.columnAuthor = new DataColumn("Author", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnAuthor);
			this.columnPublisher = new DataColumn("Publisher", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnPublisher);
			this.columnBookType = new DataColumn("BookType", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnBookType);
			this.columnDealer = new DataColumn("Dealer", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnDealer);
			this.columnAquisitionType = new DataColumn("AquisitionType", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnAquisitionType);
			this.columnReceivedGroup = new DataColumn("ReceivedGroup", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnReceivedGroup);
			this.columnSetupBy = new DataColumn("SetupBy", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnSetupBy);
			this.columnDatesetup = new DataColumn("Datesetup", typeof(DateTime), null, MappingType.Element);
			base.Columns.Add(this.columnDatesetup);
			this.columnReceivedStatus = new DataColumn("ReceivedStatus", typeof(int), null, MappingType.Element);
			base.Columns.Add(this.columnReceivedStatus);
			this.columnCatalogStatus = new DataColumn("CatalogStatus", typeof(int), null, MappingType.Element);
			base.Columns.Add(this.columnCatalogStatus);
			this.columnCopies = new DataColumn("Copies", typeof(int), null, MappingType.Element);
			base.Columns.Add(this.columnCopies);
			this.columnPublishedDate = new DataColumn("PublishedDate", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnPublishedDate);
			this.columnPublishedYear = new DataColumn("PublishedYear", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnPublishedYear);
			this.columnVol = new DataColumn("Vol", typeof(int), null, MappingType.Element);
			base.Columns.Add(this.columnVol);
			this.columnNo = new DataColumn("No", typeof(int), null, MappingType.Element);
			base.Columns.Add(this.columnNo);
			this.columnEdition = new DataColumn("Edition", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnEdition);
			this.columnCost = new DataColumn("Cost", typeof(decimal), null, MappingType.Element);
			base.Columns.Add(this.columnCost);
			this.columnTotalCost = new DataColumn("TotalCost", typeof(decimal), null, MappingType.Element);
			base.Columns.Add(this.columnTotalCost);
			this.columnISBN = new DataColumn("ISBN", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnISBN);
			this.columnACCNO = new DataColumn("ACCNO", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnACCNO);
			this.columnGRNumber = new DataColumn("GRNumber", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnGRNumber);
			this.columnAvailability = new DataColumn("Availability", typeof(int), null, MappingType.Element);
			base.Columns.Add(this.columnAvailability);
			this.columnAccYear = new DataColumn("AccYear", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnAccYear);
			this.columnParallelTitle = new DataColumn("ParallelTitle", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnParallelTitle);
			this.columnEditors = new DataColumn("Editors", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnEditors);
			this.columnMeetings = new DataColumn("Meetings", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnMeetings);
			this.columnPubPlace = new DataColumn("PubPlace", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnPubPlace);
			this.columnClassNo = new DataColumn("ClassNo", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnClassNo);
			this.columnLanguage = new DataColumn("Language", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnLanguage);
			this.columnBinding = new DataColumn("Binding", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnBinding);
			this.columnPages = new DataColumn("Pages", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnPages);
			this.columnSpineLabel = new DataColumn("SpineLabel", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnSpineLabel);
			this.columnPubType = new DataColumn("PubType", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnPubType);
			this.columnMedium = new DataColumn("Medium", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnMedium);
			this.columnAbstract = new DataColumn("Abstract", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnAbstract);
			this.columnShelfRef = new DataColumn("ShelfRef", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnShelfRef);
			this.columnKeywords = new DataColumn("Keywords", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnKeywords);
			this.columnSubject = new DataColumn("Subject", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnSubject);
			this.columnLibraryBranch = new DataColumn("LibraryBranch", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnLibraryBranch);
			this.columnimageurl = new DataColumn("imageurl", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnimageurl);
			this.columnNavigatelink = new DataColumn("Navigatelink", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnNavigatelink);
			this.columnCatLogNo = new DataColumn("CatLogNo", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnCatLogNo);
			this.columnObject = new DataColumn("Object", typeof(string), null, MappingType.Element);
			base.Columns.Add(this.columnObject);
			base.Constraints.Add(new UniqueConstraint("Constraint1", new DataColumn[]
			{
				this.columnACCNO
			}, true));
			this.columnSrn.AutoIncrement = true;
			this.columnSrn.AutoIncrementSeed = -1L;
			this.columnSrn.AutoIncrementStep = -1L;
			this.columnSrn.AllowDBNull = false;
			this.columnSrn.ReadOnly = true;
			this.columnOrderNo.AllowDBNull = false;
			this.columnOrderNo.MaxLength = 50;
			this.columnTitle.MaxLength = 250;
			this.columnAuthor.MaxLength = 250;
			this.columnPublisher.MaxLength = 250;
			this.columnBookType.MaxLength = 50;
			this.columnDealer.MaxLength = 250;
			this.columnAquisitionType.MaxLength = 50;
			this.columnReceivedGroup.MaxLength = 100;
			this.columnSetupBy.MaxLength = 50;
			this.columnReceivedStatus.AllowDBNull = false;
			this.columnCatalogStatus.AllowDBNull = false;
			this.columnPublishedDate.MaxLength = 50;
			this.columnPublishedYear.MaxLength = 50;
			this.columnEdition.MaxLength = 50;
			this.columnISBN.MaxLength = 50;
			this.columnACCNO.AllowDBNull = false;
			this.columnACCNO.Unique = true;
			this.columnACCNO.MaxLength = 50;
			this.columnGRNumber.MaxLength = 50;
			this.columnAccYear.MaxLength = 50;
			this.columnParallelTitle.MaxLength = 250;
			this.columnEditors.MaxLength = 250;
			this.columnMeetings.MaxLength = 100;
			this.columnPubPlace.MaxLength = 100;
			this.columnClassNo.MaxLength = 100;
			this.columnLanguage.MaxLength = 50;
			this.columnBinding.MaxLength = 50;
			this.columnPages.MaxLength = 50;
			this.columnSpineLabel.MaxLength = 50;
			this.columnPubType.MaxLength = 50;
			this.columnMedium.MaxLength = 50;
			this.columnAbstract.MaxLength = 250;
			this.columnShelfRef.MaxLength = 250;
			this.columnKeywords.MaxLength = 100;
			this.columnSubject.MaxLength = 250;
			this.columnLibraryBranch.MaxLength = 50;
			this.columnimageurl.MaxLength = 100;
			this.columnNavigatelink.MaxLength = 100;
			this.columnCatLogNo.MaxLength = 50;
			this.columnObject.MaxLength = 50;
		}
		[DebuggerNonUserCode]
		public wsheet.BookDetailsRow NewBookDetailsRow()
		{
			return (wsheet.BookDetailsRow)base.NewRow();
		}
		[DebuggerNonUserCode]
		protected override DataRow NewRowFromBuilder(DataRowBuilder builder)
		{
			return new wsheet.BookDetailsRow(builder);
		}
		[DebuggerNonUserCode]
		protected override Type GetRowType()
		{
			return typeof(wsheet.BookDetailsRow);
		}
		[DebuggerNonUserCode]
		protected override void OnRowChanged(DataRowChangeEventArgs e)
		{
			base.OnRowChanged(e);
			if (this.BookDetailsRowChanged != null)
			{
				this.BookDetailsRowChanged(this, new wsheet.BookDetailsRowChangeEvent((wsheet.BookDetailsRow)e.Row, e.Action));
			}
		}
		[DebuggerNonUserCode]
		protected override void OnRowChanging(DataRowChangeEventArgs e)
		{
			base.OnRowChanging(e);
			if (this.BookDetailsRowChanging != null)
			{
				this.BookDetailsRowChanging(this, new wsheet.BookDetailsRowChangeEvent((wsheet.BookDetailsRow)e.Row, e.Action));
			}
		}
		[DebuggerNonUserCode]
		protected override void OnRowDeleted(DataRowChangeEventArgs e)
		{
			base.OnRowDeleted(e);
			if (this.BookDetailsRowDeleted != null)
			{
				this.BookDetailsRowDeleted(this, new wsheet.BookDetailsRowChangeEvent((wsheet.BookDetailsRow)e.Row, e.Action));
			}
		}
		[DebuggerNonUserCode]
		protected override void OnRowDeleting(DataRowChangeEventArgs e)
		{
			base.OnRowDeleting(e);
			if (this.BookDetailsRowDeleting != null)
			{
				this.BookDetailsRowDeleting(this, new wsheet.BookDetailsRowChangeEvent((wsheet.BookDetailsRow)e.Row, e.Action));
			}
		}
		[DebuggerNonUserCode]
		public void RemoveBookDetailsRow(wsheet.BookDetailsRow row)
		{
			base.Rows.Remove(row);
		}
		[DebuggerNonUserCode]
		public static XmlSchemaComplexType GetTypedTableSchema(XmlSchemaSet xs)
		{
			XmlSchemaComplexType xmlSchemaComplexType = new XmlSchemaComplexType();
			XmlSchemaSequence xmlSchemaSequence = new XmlSchemaSequence();
			wsheet wsheet = new wsheet();
			XmlSchemaAny xmlSchemaAny = new XmlSchemaAny();
			xmlSchemaAny.Namespace = "http://www.w3.org/2001/XMLSchema";
			xmlSchemaAny.MinOccurs = 0m;
			xmlSchemaAny.MaxOccurs = 79228162514264337593543950335m;
			xmlSchemaAny.ProcessContents = XmlSchemaContentProcessing.Lax;
			xmlSchemaSequence.Items.Add(xmlSchemaAny);
			XmlSchemaAny xmlSchemaAny2 = new XmlSchemaAny();
			xmlSchemaAny2.Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1";
			xmlSchemaAny2.MinOccurs = 1m;
			xmlSchemaAny2.ProcessContents = XmlSchemaContentProcessing.Lax;
			xmlSchemaSequence.Items.Add(xmlSchemaAny2);
			XmlSchemaAttribute xmlSchemaAttribute = new XmlSchemaAttribute();
			xmlSchemaAttribute.Name = "namespace";
			xmlSchemaAttribute.FixedValue = wsheet.Namespace;
			xmlSchemaComplexType.Attributes.Add(xmlSchemaAttribute);
			XmlSchemaAttribute xmlSchemaAttribute2 = new XmlSchemaAttribute();
			xmlSchemaAttribute2.Name = "tableTypeName";
			xmlSchemaAttribute2.FixedValue = "BookDetailsDataTable";
			xmlSchemaComplexType.Attributes.Add(xmlSchemaAttribute2);
			xmlSchemaComplexType.Particle = xmlSchemaSequence;
			XmlSchema schemaSerializable = wsheet.GetSchemaSerializable();
			if (xs.Contains(schemaSerializable.TargetNamespace))
			{
				MemoryStream memoryStream = new MemoryStream();
				MemoryStream memoryStream2 = new MemoryStream();
				try
				{
					schemaSerializable.Write(memoryStream);
					IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
					while (enumerator.MoveNext())
					{
						XmlSchema xmlSchema = (XmlSchema)enumerator.Current;
						memoryStream2.SetLength(0L);
						xmlSchema.Write(memoryStream2);
						if (memoryStream.Length == memoryStream2.Length)
						{
							memoryStream.Position = 0L;
							memoryStream2.Position = 0L;
							while (memoryStream.Position != memoryStream.Length && memoryStream.ReadByte() == memoryStream2.ReadByte())
							{
							}
							if (memoryStream.Position == memoryStream.Length)
							{
								return xmlSchemaComplexType;
							}
						}
					}
				}
				finally
				{
					if (memoryStream != null)
					{
						memoryStream.Close();
					}
					if (memoryStream2 != null)
					{
						memoryStream2.Close();
					}
				}
			}
			xs.Add(schemaSerializable);
			return xmlSchemaComplexType;
		}
	}
	[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0")]
	public class BookDetailsRow : DataRow
	{
		private wsheet.BookDetailsDataTable tableBookDetails;
		[DebuggerNonUserCode]
		public decimal Srn
		{
			get
			{
				return (decimal)base[this.tableBookDetails.SrnColumn];
			}
			set
			{
				base[this.tableBookDetails.SrnColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string OrderNo
		{
			get
			{
				return (string)base[this.tableBookDetails.OrderNoColumn];
			}
			set
			{
				base[this.tableBookDetails.OrderNoColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Title
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.TitleColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Title' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.TitleColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Author
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.AuthorColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Author' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.AuthorColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Publisher
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.PublisherColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Publisher' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.PublisherColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string BookType
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.BookTypeColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'BookType' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.BookTypeColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Dealer
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.DealerColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Dealer' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.DealerColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string AquisitionType
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.AquisitionTypeColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'AquisitionType' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.AquisitionTypeColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string ReceivedGroup
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.ReceivedGroupColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'ReceivedGroup' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.ReceivedGroupColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string SetupBy
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.SetupByColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'SetupBy' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.SetupByColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public DateTime Datesetup
		{
			get
			{
				DateTime result;
				try
				{
					result = (DateTime)base[this.tableBookDetails.DatesetupColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Datesetup' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.DatesetupColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public int ReceivedStatus
		{
			get
			{
				return (int)base[this.tableBookDetails.ReceivedStatusColumn];
			}
			set
			{
				base[this.tableBookDetails.ReceivedStatusColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public int CatalogStatus
		{
			get
			{
				return (int)base[this.tableBookDetails.CatalogStatusColumn];
			}
			set
			{
				base[this.tableBookDetails.CatalogStatusColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public int Copies
		{
			get
			{
				int result;
				try
				{
					result = (int)base[this.tableBookDetails.CopiesColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Copies' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.CopiesColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string PublishedDate
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.PublishedDateColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'PublishedDate' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.PublishedDateColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string PublishedYear
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.PublishedYearColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'PublishedYear' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.PublishedYearColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public int Vol
		{
			get
			{
				int result;
				try
				{
					result = (int)base[this.tableBookDetails.VolColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Vol' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.VolColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public int No
		{
			get
			{
				int result;
				try
				{
					result = (int)base[this.tableBookDetails.NoColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'No' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.NoColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Edition
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.EditionColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Edition' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.EditionColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public decimal Cost
		{
			get
			{
				decimal result;
				try
				{
					result = (decimal)base[this.tableBookDetails.CostColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Cost' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.CostColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public decimal TotalCost
		{
			get
			{
				decimal result;
				try
				{
					result = (decimal)base[this.tableBookDetails.TotalCostColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'TotalCost' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.TotalCostColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string ISBN
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.ISBNColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'ISBN' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.ISBNColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string ACCNO
		{
			get
			{
				return (string)base[this.tableBookDetails.ACCNOColumn];
			}
			set
			{
				base[this.tableBookDetails.ACCNOColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string GRNumber
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.GRNumberColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'GRNumber' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.GRNumberColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public int Availability
		{
			get
			{
				int result;
				try
				{
					result = (int)base[this.tableBookDetails.AvailabilityColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Availability' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.AvailabilityColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string AccYear
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.AccYearColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'AccYear' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.AccYearColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string ParallelTitle
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.ParallelTitleColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'ParallelTitle' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.ParallelTitleColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Editors
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.EditorsColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Editors' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.EditorsColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Meetings
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.MeetingsColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Meetings' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.MeetingsColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string PubPlace
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.PubPlaceColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'PubPlace' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.PubPlaceColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string ClassNo
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.ClassNoColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'ClassNo' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.ClassNoColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Language
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.LanguageColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Language' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.LanguageColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Binding
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.BindingColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Binding' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.BindingColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Pages
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.PagesColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Pages' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.PagesColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string SpineLabel
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.SpineLabelColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'SpineLabel' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.SpineLabelColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string PubType
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.PubTypeColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'PubType' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.PubTypeColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Medium
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.MediumColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Medium' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.MediumColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Abstract
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.AbstractColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Abstract' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.AbstractColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string ShelfRef
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.ShelfRefColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'ShelfRef' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.ShelfRefColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Keywords
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.KeywordsColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Keywords' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.KeywordsColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Subject
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.SubjectColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Subject' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.SubjectColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string LibraryBranch
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.LibraryBranchColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'LibraryBranch' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.LibraryBranchColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string imageurl
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.imageurlColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'imageurl' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.imageurlColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Navigatelink
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.NavigatelinkColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Navigatelink' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.NavigatelinkColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string CatLogNo
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.CatLogNoColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'CatLogNo' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.CatLogNoColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		public string Object
		{
			get
			{
				string result;
				try
				{
					result = (string)base[this.tableBookDetails.ObjectColumn];
				}
				catch (InvalidCastException innerException)
				{
					throw new StrongTypingException("The value for column 'Object' in table 'BookDetails' is DBNull.", innerException);
				}
				return result;
			}
			set
			{
				base[this.tableBookDetails.ObjectColumn] = value;
			}
		}
		[DebuggerNonUserCode]
		internal BookDetailsRow(DataRowBuilder rb) : base(rb)
		{
			this.tableBookDetails = (wsheet.BookDetailsDataTable)base.Table;
		}
		[DebuggerNonUserCode]
		public bool IsTitleNull()
		{
			return base.IsNull(this.tableBookDetails.TitleColumn);
		}
		[DebuggerNonUserCode]
		public void SetTitleNull()
		{
			base[this.tableBookDetails.TitleColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsAuthorNull()
		{
			return base.IsNull(this.tableBookDetails.AuthorColumn);
		}
		[DebuggerNonUserCode]
		public void SetAuthorNull()
		{
			base[this.tableBookDetails.AuthorColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsPublisherNull()
		{
			return base.IsNull(this.tableBookDetails.PublisherColumn);
		}
		[DebuggerNonUserCode]
		public void SetPublisherNull()
		{
			base[this.tableBookDetails.PublisherColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsBookTypeNull()
		{
			return base.IsNull(this.tableBookDetails.BookTypeColumn);
		}
		[DebuggerNonUserCode]
		public void SetBookTypeNull()
		{
			base[this.tableBookDetails.BookTypeColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsDealerNull()
		{
			return base.IsNull(this.tableBookDetails.DealerColumn);
		}
		[DebuggerNonUserCode]
		public void SetDealerNull()
		{
			base[this.tableBookDetails.DealerColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsAquisitionTypeNull()
		{
			return base.IsNull(this.tableBookDetails.AquisitionTypeColumn);
		}
		[DebuggerNonUserCode]
		public void SetAquisitionTypeNull()
		{
			base[this.tableBookDetails.AquisitionTypeColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsReceivedGroupNull()
		{
			return base.IsNull(this.tableBookDetails.ReceivedGroupColumn);
		}
		[DebuggerNonUserCode]
		public void SetReceivedGroupNull()
		{
			base[this.tableBookDetails.ReceivedGroupColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsSetupByNull()
		{
			return base.IsNull(this.tableBookDetails.SetupByColumn);
		}
		[DebuggerNonUserCode]
		public void SetSetupByNull()
		{
			base[this.tableBookDetails.SetupByColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsDatesetupNull()
		{
			return base.IsNull(this.tableBookDetails.DatesetupColumn);
		}
		[DebuggerNonUserCode]
		public void SetDatesetupNull()
		{
			base[this.tableBookDetails.DatesetupColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsCopiesNull()
		{
			return base.IsNull(this.tableBookDetails.CopiesColumn);
		}
		[DebuggerNonUserCode]
		public void SetCopiesNull()
		{
			base[this.tableBookDetails.CopiesColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsPublishedDateNull()
		{
			return base.IsNull(this.tableBookDetails.PublishedDateColumn);
		}
		[DebuggerNonUserCode]
		public void SetPublishedDateNull()
		{
			base[this.tableBookDetails.PublishedDateColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsPublishedYearNull()
		{
			return base.IsNull(this.tableBookDetails.PublishedYearColumn);
		}
		[DebuggerNonUserCode]
		public void SetPublishedYearNull()
		{
			base[this.tableBookDetails.PublishedYearColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsVolNull()
		{
			return base.IsNull(this.tableBookDetails.VolColumn);
		}
		[DebuggerNonUserCode]
		public void SetVolNull()
		{
			base[this.tableBookDetails.VolColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsNoNull()
		{
			return base.IsNull(this.tableBookDetails.NoColumn);
		}
		[DebuggerNonUserCode]
		public void SetNoNull()
		{
			base[this.tableBookDetails.NoColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsEditionNull()
		{
			return base.IsNull(this.tableBookDetails.EditionColumn);
		}
		[DebuggerNonUserCode]
		public void SetEditionNull()
		{
			base[this.tableBookDetails.EditionColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsCostNull()
		{
			return base.IsNull(this.tableBookDetails.CostColumn);
		}
		[DebuggerNonUserCode]
		public void SetCostNull()
		{
			base[this.tableBookDetails.CostColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsTotalCostNull()
		{
			return base.IsNull(this.tableBookDetails.TotalCostColumn);
		}
		[DebuggerNonUserCode]
		public void SetTotalCostNull()
		{
			base[this.tableBookDetails.TotalCostColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsISBNNull()
		{
			return base.IsNull(this.tableBookDetails.ISBNColumn);
		}
		[DebuggerNonUserCode]
		public void SetISBNNull()
		{
			base[this.tableBookDetails.ISBNColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsGRNumberNull()
		{
			return base.IsNull(this.tableBookDetails.GRNumberColumn);
		}
		[DebuggerNonUserCode]
		public void SetGRNumberNull()
		{
			base[this.tableBookDetails.GRNumberColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsAvailabilityNull()
		{
			return base.IsNull(this.tableBookDetails.AvailabilityColumn);
		}
		[DebuggerNonUserCode]
		public void SetAvailabilityNull()
		{
			base[this.tableBookDetails.AvailabilityColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsAccYearNull()
		{
			return base.IsNull(this.tableBookDetails.AccYearColumn);
		}
		[DebuggerNonUserCode]
		public void SetAccYearNull()
		{
			base[this.tableBookDetails.AccYearColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsParallelTitleNull()
		{
			return base.IsNull(this.tableBookDetails.ParallelTitleColumn);
		}
		[DebuggerNonUserCode]
		public void SetParallelTitleNull()
		{
			base[this.tableBookDetails.ParallelTitleColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsEditorsNull()
		{
			return base.IsNull(this.tableBookDetails.EditorsColumn);
		}
		[DebuggerNonUserCode]
		public void SetEditorsNull()
		{
			base[this.tableBookDetails.EditorsColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsMeetingsNull()
		{
			return base.IsNull(this.tableBookDetails.MeetingsColumn);
		}
		[DebuggerNonUserCode]
		public void SetMeetingsNull()
		{
			base[this.tableBookDetails.MeetingsColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsPubPlaceNull()
		{
			return base.IsNull(this.tableBookDetails.PubPlaceColumn);
		}
		[DebuggerNonUserCode]
		public void SetPubPlaceNull()
		{
			base[this.tableBookDetails.PubPlaceColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsClassNoNull()
		{
			return base.IsNull(this.tableBookDetails.ClassNoColumn);
		}
		[DebuggerNonUserCode]
		public void SetClassNoNull()
		{
			base[this.tableBookDetails.ClassNoColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsLanguageNull()
		{
			return base.IsNull(this.tableBookDetails.LanguageColumn);
		}
		[DebuggerNonUserCode]
		public void SetLanguageNull()
		{
			base[this.tableBookDetails.LanguageColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsBindingNull()
		{
			return base.IsNull(this.tableBookDetails.BindingColumn);
		}
		[DebuggerNonUserCode]
		public void SetBindingNull()
		{
			base[this.tableBookDetails.BindingColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsPagesNull()
		{
			return base.IsNull(this.tableBookDetails.PagesColumn);
		}
		[DebuggerNonUserCode]
		public void SetPagesNull()
		{
			base[this.tableBookDetails.PagesColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsSpineLabelNull()
		{
			return base.IsNull(this.tableBookDetails.SpineLabelColumn);
		}
		[DebuggerNonUserCode]
		public void SetSpineLabelNull()
		{
			base[this.tableBookDetails.SpineLabelColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsPubTypeNull()
		{
			return base.IsNull(this.tableBookDetails.PubTypeColumn);
		}
		[DebuggerNonUserCode]
		public void SetPubTypeNull()
		{
			base[this.tableBookDetails.PubTypeColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsMediumNull()
		{
			return base.IsNull(this.tableBookDetails.MediumColumn);
		}
		[DebuggerNonUserCode]
		public void SetMediumNull()
		{
			base[this.tableBookDetails.MediumColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsAbstractNull()
		{
			return base.IsNull(this.tableBookDetails.AbstractColumn);
		}
		[DebuggerNonUserCode]
		public void SetAbstractNull()
		{
			base[this.tableBookDetails.AbstractColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsShelfRefNull()
		{
			return base.IsNull(this.tableBookDetails.ShelfRefColumn);
		}
		[DebuggerNonUserCode]
		public void SetShelfRefNull()
		{
			base[this.tableBookDetails.ShelfRefColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsKeywordsNull()
		{
			return base.IsNull(this.tableBookDetails.KeywordsColumn);
		}
		[DebuggerNonUserCode]
		public void SetKeywordsNull()
		{
			base[this.tableBookDetails.KeywordsColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsSubjectNull()
		{
			return base.IsNull(this.tableBookDetails.SubjectColumn);
		}
		[DebuggerNonUserCode]
		public void SetSubjectNull()
		{
			base[this.tableBookDetails.SubjectColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsLibraryBranchNull()
		{
			return base.IsNull(this.tableBookDetails.LibraryBranchColumn);
		}
		[DebuggerNonUserCode]
		public void SetLibraryBranchNull()
		{
			base[this.tableBookDetails.LibraryBranchColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsimageurlNull()
		{
			return base.IsNull(this.tableBookDetails.imageurlColumn);
		}
		[DebuggerNonUserCode]
		public void SetimageurlNull()
		{
			base[this.tableBookDetails.imageurlColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsNavigatelinkNull()
		{
			return base.IsNull(this.tableBookDetails.NavigatelinkColumn);
		}
		[DebuggerNonUserCode]
		public void SetNavigatelinkNull()
		{
			base[this.tableBookDetails.NavigatelinkColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsCatLogNoNull()
		{
			return base.IsNull(this.tableBookDetails.CatLogNoColumn);
		}
		[DebuggerNonUserCode]
		public void SetCatLogNoNull()
		{
			base[this.tableBookDetails.CatLogNoColumn] = Convert.DBNull;
		}
		[DebuggerNonUserCode]
		public bool IsObjectNull()
		{
			return base.IsNull(this.tableBookDetails.ObjectColumn);
		}
		[DebuggerNonUserCode]
		public void SetObjectNull()
		{
			base[this.tableBookDetails.ObjectColumn] = Convert.DBNull;
		}
	}
	[GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0")]
	public class BookDetailsRowChangeEvent : EventArgs
	{
		private wsheet.BookDetailsRow eventRow;
		private DataRowAction eventAction;
		[DebuggerNonUserCode]
		public wsheet.BookDetailsRow Row
		{
			get
			{
				return this.eventRow;
			}
		}
		[DebuggerNonUserCode]
		public DataRowAction Action
		{
			get
			{
				return this.eventAction;
			}
		}
		[DebuggerNonUserCode]
		public BookDetailsRowChangeEvent(wsheet.BookDetailsRow row, DataRowAction action)
		{
			this.eventRow = row;
			this.eventAction = action;
		}
	}
	private wsheet.BookDetailsDataTable tableBookDetails;
	private SchemaSerializationMode _schemaSerializationMode = SchemaSerializationMode.IncludeSchema;
	[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Content), DebuggerNonUserCode]
	public wsheet.BookDetailsDataTable BookDetails
	{
		get
		{
			return this.tableBookDetails;
		}
	}
	[Browsable(true), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible), DebuggerNonUserCode]
	public override SchemaSerializationMode SchemaSerializationMode
	{
		get
		{
			return this._schemaSerializationMode;
		}
		set
		{
			this._schemaSerializationMode = value;
		}
	}
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden), DebuggerNonUserCode]
	public new DataTableCollection Tables
	{
		get
		{
			return base.Tables;
		}
	}
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden), DebuggerNonUserCode]
	public new DataRelationCollection Relations
	{
		get
		{
			return base.Relations;
		}
	}
	[DebuggerNonUserCode]
	public wsheet()
	{
		base.BeginInit();
		this.InitClass();
		CollectionChangeEventHandler value = new CollectionChangeEventHandler(this.SchemaChanged);
		base.Tables.CollectionChanged += value;
		base.Relations.CollectionChanged += value;
		base.EndInit();
	}
	[DebuggerNonUserCode]
	protected wsheet(SerializationInfo info, StreamingContext context) : base(info, context, false)
	{
		if (base.IsBinarySerialized(info, context))
		{
			this.InitVars(false);
			CollectionChangeEventHandler value = new CollectionChangeEventHandler(this.SchemaChanged);
			this.Tables.CollectionChanged += value;
			this.Relations.CollectionChanged += value;
			return;
		}
		string s = (string)info.GetValue("XmlSchema", typeof(string));
		if (base.DetermineSchemaSerializationMode(info, context) == SchemaSerializationMode.IncludeSchema)
		{
			DataSet dataSet = new DataSet();
			dataSet.ReadXmlSchema(new XmlTextReader(new StringReader(s)));
			if (dataSet.Tables["BookDetails"] != null)
			{
				base.Tables.Add(new wsheet.BookDetailsDataTable(dataSet.Tables["BookDetails"]));
			}
			base.DataSetName = dataSet.DataSetName;
			base.Prefix = dataSet.Prefix;
			base.Namespace = dataSet.Namespace;
			base.Locale = dataSet.Locale;
			base.CaseSensitive = dataSet.CaseSensitive;
			base.EnforceConstraints = dataSet.EnforceConstraints;
			base.Merge(dataSet, false, MissingSchemaAction.Add);
			this.InitVars();
		}
		else
		{
			base.ReadXmlSchema(new XmlTextReader(new StringReader(s)));
		}
		base.GetSerializationData(info, context);
		CollectionChangeEventHandler value2 = new CollectionChangeEventHandler(this.SchemaChanged);
		base.Tables.CollectionChanged += value2;
		this.Relations.CollectionChanged += value2;
	}
	[DebuggerNonUserCode]
	protected override void InitializeDerivedDataSet()
	{
		base.BeginInit();
		this.InitClass();
		base.EndInit();
	}
	[DebuggerNonUserCode]
	public override DataSet Clone()
	{
		wsheet wsheet = (wsheet)base.Clone();
		wsheet.InitVars();
		wsheet.SchemaSerializationMode = this.SchemaSerializationMode;
		return wsheet;
	}
	[DebuggerNonUserCode]
	protected override bool ShouldSerializeTables()
	{
		return false;
	}
	[DebuggerNonUserCode]
	protected override bool ShouldSerializeRelations()
	{
		return false;
	}
	[DebuggerNonUserCode]
	protected override void ReadXmlSerializable(XmlReader reader)
	{
		if (base.DetermineSchemaSerializationMode(reader) == SchemaSerializationMode.IncludeSchema)
		{
			this.Reset();
			DataSet dataSet = new DataSet();
			dataSet.ReadXml(reader);
			if (dataSet.Tables["BookDetails"] != null)
			{
				base.Tables.Add(new wsheet.BookDetailsDataTable(dataSet.Tables["BookDetails"]));
			}
			base.DataSetName = dataSet.DataSetName;
			base.Prefix = dataSet.Prefix;
			base.Namespace = dataSet.Namespace;
			base.Locale = dataSet.Locale;
			base.CaseSensitive = dataSet.CaseSensitive;
			base.EnforceConstraints = dataSet.EnforceConstraints;
			base.Merge(dataSet, false, MissingSchemaAction.Add);
			this.InitVars();
			return;
		}
		base.ReadXml(reader);
		this.InitVars();
	}
	[DebuggerNonUserCode]
	protected override XmlSchema GetSchemaSerializable()
	{
		MemoryStream memoryStream = new MemoryStream();
		base.WriteXmlSchema(new XmlTextWriter(memoryStream, null));
		memoryStream.Position = 0L;
		return XmlSchema.Read(new XmlTextReader(memoryStream), null);
	}
	[DebuggerNonUserCode]
	internal void InitVars()
	{
		this.InitVars(true);
	}
	[DebuggerNonUserCode]
	internal void InitVars(bool initTable)
	{
		this.tableBookDetails = (wsheet.BookDetailsDataTable)base.Tables["BookDetails"];
		if (initTable && this.tableBookDetails != null)
		{
			this.tableBookDetails.InitVars();
		}
	}
	[DebuggerNonUserCode]
	private void InitClass()
	{
		base.DataSetName = "wsheet";
		base.Prefix = "";
		base.Namespace = "http://tempuri.org/wsheet.xsd";
		base.EnforceConstraints = true;
		this.SchemaSerializationMode = SchemaSerializationMode.IncludeSchema;
		this.tableBookDetails = new wsheet.BookDetailsDataTable();
		base.Tables.Add(this.tableBookDetails);
	}
	[DebuggerNonUserCode]
	private bool ShouldSerializeBookDetails()
	{
		return false;
	}
	[DebuggerNonUserCode]
	private void SchemaChanged(object sender, CollectionChangeEventArgs e)
	{
		if (e.Action == CollectionChangeAction.Remove)
		{
			this.InitVars();
		}
	}
	[DebuggerNonUserCode]
	public static XmlSchemaComplexType GetTypedDataSetSchema(XmlSchemaSet xs)
	{
		wsheet wsheet = new wsheet();
		XmlSchemaComplexType xmlSchemaComplexType = new XmlSchemaComplexType();
		XmlSchemaSequence xmlSchemaSequence = new XmlSchemaSequence();
		XmlSchemaAny xmlSchemaAny = new XmlSchemaAny();
		xmlSchemaAny.Namespace = wsheet.Namespace;
		xmlSchemaSequence.Items.Add(xmlSchemaAny);
		xmlSchemaComplexType.Particle = xmlSchemaSequence;
		XmlSchema schemaSerializable = wsheet.GetSchemaSerializable();
		if (xs.Contains(schemaSerializable.TargetNamespace))
		{
			MemoryStream memoryStream = new MemoryStream();
			MemoryStream memoryStream2 = new MemoryStream();
			try
			{
				schemaSerializable.Write(memoryStream);
				IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
				while (enumerator.MoveNext())
				{
					XmlSchema xmlSchema = (XmlSchema)enumerator.Current;
					memoryStream2.SetLength(0L);
					xmlSchema.Write(memoryStream2);
					if (memoryStream.Length == memoryStream2.Length)
					{
						memoryStream.Position = 0L;
						memoryStream2.Position = 0L;
						while (memoryStream.Position != memoryStream.Length && memoryStream.ReadByte() == memoryStream2.ReadByte())
						{
						}
						if (memoryStream.Position == memoryStream.Length)
						{
							return xmlSchemaComplexType;
						}
					}
				}
			}
			finally
			{
				if (memoryStream != null)
				{
					memoryStream.Close();
				}
				if (memoryStream2 != null)
				{
					memoryStream2.Close();
				}
			}
		}
		xs.Add(schemaSerializable);
		return xmlSchemaComplexType;
	}
}
