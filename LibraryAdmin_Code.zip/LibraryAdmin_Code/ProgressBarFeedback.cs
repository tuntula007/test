using System;
using System.IO;
using System.Net;
using System.Text;
public class ProgressBarFeedback
{
	public string Getfeedback(string IP, string Ftype, string msg)
	{
		string text = string.Empty;
		try
		{
			string requestUriString = string.Concat(new string[]
			{
				"http://",
				IP.Trim(),
				"/hh.htm?pin=",
				Ftype,
				"&msg=",
				msg
			});
			HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(requestUriString);
			httpWebRequest.Timeout = 10000;
			httpWebRequest.Method = "POST";
			httpWebRequest.ContentType = "application/x-www-form-urlencode";
			ASCIIEncoding aSCIIEncoding = new ASCIIEncoding();
			string s = "NIL";
			byte[] bytes = aSCIIEncoding.GetBytes(s);
			httpWebRequest.ContentLength = (long)bytes.Length;
			Stream requestStream = httpWebRequest.GetRequestStream();
			requestStream.Write(bytes, 0, bytes.Length);
			requestStream.Close();
			HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
			Stream responseStream = httpWebResponse.GetResponseStream();
			StreamReader streamReader = new StreamReader(responseStream);
			char[] array = new char[1024];
			int i = streamReader.Read(array, 0, 1024);
			text = new string(array, 0, i);
			while (i > 0)
			{
				text = new string(array, 0, i);
				Console.WriteLine(text);
				i = streamReader.Read(array, 0, 1024);
			}
			streamReader.Close();
			responseStream.Close();
			httpWebResponse.Close();
		}
		catch (Exception ex)
		{
			Console.WriteLine(ex.Message);
		}
		return text;
	}
}
