using System;
public class Numeric
{
	public bool IsNumeric(string p)
	{
		bool result = false;
		string[] array = p.Trim().Split(new char[]
		{
			' ',
			':',
			';',
			'-',
			'.',
			'#',
			'@',
			'~',
			'_',
			'+',
			'%',
			'"',
			'>',
			'!',
			'<',
			'*',
			'^',
			'?',
			',',
			'|',
			'(',
			')'
		});
		string text = "";
		string[] array2 = array;
		for (int i = 0; i < array2.Length; i++)
		{
			string text2 = array2[i];
			string text3 = text2;
			for (int j = 0; j < text3.Length; j++)
			{
				char c = text3[j];
				if (c <= '9' && c >= '0')
				{
					text += c.ToString();
				}
			}
			if (!(text.Trim() == text2))
			{
				break;
			}
			text = "";
			result = true;
		}
		return result;
	}
}
