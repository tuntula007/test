using System;
using System.Collections;
namespace Cyberspace.Emailpackage
{
	public class CMail
	{
		private string m_DisplayName;
		private ArrayList m_ToEmail = new ArrayList();
		private ArrayList m_FromEmail = new ArrayList();
		private ArrayList m_ReplyTo = new ArrayList();
		private ArrayList m_CCEmail = new ArrayList();
		private ArrayList m_BCCEmail = new ArrayList();
		private string m_Subject;
		private string m_Body;
		private string m_ComposedDate;
		private string m_SourceApplication;
		private string m_AttachedFile;
		public string DisplayName
		{
			get
			{
				return this.m_DisplayName;
			}
			set
			{
				this.m_DisplayName = value;
			}
		}
		public ArrayList ToEmail
		{
			get
			{
				return this.m_ToEmail;
			}
			set
			{
				this.m_ToEmail = value;
			}
		}
		public ArrayList FromEmail
		{
			get
			{
				return this.m_FromEmail;
			}
			set
			{
				this.m_FromEmail = value;
			}
		}
		public ArrayList ReplyTo
		{
			get
			{
				return this.m_ReplyTo;
			}
			set
			{
				this.m_ReplyTo = value;
			}
		}
		public ArrayList CCEmail
		{
			get
			{
				return this.m_CCEmail;
			}
			set
			{
				this.m_CCEmail = value;
			}
		}
		public ArrayList BCCEmail
		{
			get
			{
				return this.m_BCCEmail;
			}
			set
			{
				this.m_BCCEmail = value;
			}
		}
		public string Subject
		{
			get
			{
				return this.m_Subject;
			}
			set
			{
				this.m_Subject = value;
			}
		}
		public string Body
		{
			get
			{
				return this.m_Body;
			}
			set
			{
				this.m_Body = value;
			}
		}
		public string ComposedDate
		{
			get
			{
				return this.m_ComposedDate;
			}
			set
			{
				this.m_ComposedDate = value;
			}
		}
		public string SourceApplication
		{
			get
			{
				return this.m_SourceApplication;
			}
			set
			{
				this.m_SourceApplication = value;
			}
		}
		public string AttachedFile
		{
			get
			{
				return this.m_AttachedFile;
			}
			set
			{
				this.m_AttachedFile = value;
			}
		}
	}
}
