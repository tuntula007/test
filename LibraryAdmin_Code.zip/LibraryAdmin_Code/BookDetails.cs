using System;
public class BookDetails
{
	private decimal _Srn;
	private string _OrderNo;
	private string _Title;
	private string _Author;
	private string _Publisher;
	private string _BookType;
	private string _Dealer;
	private string _AquisitionType;
	private string _ReceivedGroup;
	private string _SetupBy;
	private string _Datesetup;
	private int _ReceivedStatus;
	private int _CatalogStatus;
	private int _Copies;
	private string _PublishedDate;
	private string _PublishedYear;
	private int _Vol;
	private int _No;
	private string _Edition;
	private decimal _Cost;
	private decimal _TotalCost;
	private string _ISBN;
	private string _ACCNO;
	private string _GRNumber;
	private int _Availability;
	private string _AccYear;
	private string _ParallelTitle;
	private string _Editors;
	private string _Meetings;
	private string _PubPlace;
	private string _ClassNo;
	private string _Language;
	private string _Binding;
	private string _Pages;
	private string _SpineLabel;
	private string _PubType;
	private string _Medium;
	private string _Abstract;
	private string _ShelfRef;
	private string _Keywords;
	private string _Subject;
	private string _LibraryBranch;
	private string _imageurl;
	private string _Navigatelink;
	private string _CatLogNo;
	private string _Object;
	public decimal Srn
	{
		get
		{
			return this._Srn;
		}
		set
		{
			this._Srn = value;
		}
	}
	public string OrderNo
	{
		get
		{
			return this._OrderNo;
		}
		set
		{
			this._OrderNo = value;
		}
	}
	public string Title
	{
		get
		{
			return this._Title;
		}
		set
		{
			this._Title = value;
		}
	}
	public string Author
	{
		get
		{
			return this._Author;
		}
		set
		{
			this._Author = value;
		}
	}
	public string Publisher
	{
		get
		{
			return this._Publisher;
		}
		set
		{
			this._Publisher = value;
		}
	}
	public string BookType
	{
		get
		{
			return this._BookType;
		}
		set
		{
			this._BookType = value;
		}
	}
	public string Dealer
	{
		get
		{
			return this._Dealer;
		}
		set
		{
			this._Dealer = value;
		}
	}
	public string AquisitionType
	{
		get
		{
			return this._AquisitionType;
		}
		set
		{
			this._AquisitionType = value;
		}
	}
	public string ReceivedGroup
	{
		get
		{
			return this._ReceivedGroup;
		}
		set
		{
			this._ReceivedGroup = value;
		}
	}
	public string SetupBy
	{
		get
		{
			return this._SetupBy;
		}
		set
		{
			this._SetupBy = value;
		}
	}
	public string Datesetup
	{
		get
		{
			return this._Datesetup;
		}
		set
		{
			this._Datesetup = value;
		}
	}
	public int ReceivedStatus
	{
		get
		{
			return this._ReceivedStatus;
		}
		set
		{
			this._ReceivedStatus = value;
		}
	}
	public int CatalogStatus
	{
		get
		{
			return this._CatalogStatus;
		}
		set
		{
			this._CatalogStatus = value;
		}
	}
	public int Copies
	{
		get
		{
			return this._Copies;
		}
		set
		{
			this._Copies = value;
		}
	}
	public string PublishedDate
	{
		get
		{
			return this._PublishedDate;
		}
		set
		{
			this._PublishedDate = value;
		}
	}
	public string PublishedYear
	{
		get
		{
			return this._PublishedYear;
		}
		set
		{
			this._PublishedYear = value;
		}
	}
	public int Vol
	{
		get
		{
			return this._Vol;
		}
		set
		{
			this._Vol = value;
		}
	}
	public int No
	{
		get
		{
			return this._No;
		}
		set
		{
			this._No = value;
		}
	}
	public string Edition
	{
		get
		{
			return this._Edition;
		}
		set
		{
			this._Edition = value;
		}
	}
	public decimal Cost
	{
		get
		{
			return this._Cost;
		}
		set
		{
			this._Cost = value;
		}
	}
	public decimal TotalCost
	{
		get
		{
			return this._TotalCost;
		}
		set
		{
			this._TotalCost = value;
		}
	}
	public string ISBN
	{
		get
		{
			return this._ISBN;
		}
		set
		{
			this._ISBN = value;
		}
	}
	public string ACCNO
	{
		get
		{
			return this._ACCNO;
		}
		set
		{
			this._ACCNO = value;
		}
	}
	public string GRNumber
	{
		get
		{
			return this._GRNumber;
		}
		set
		{
			this._GRNumber = value;
		}
	}
	public int Availability
	{
		get
		{
			return this._Availability;
		}
		set
		{
			this._Availability = value;
		}
	}
	public string AccYear
	{
		get
		{
			return this._AccYear;
		}
		set
		{
			this._AccYear = value;
		}
	}
	public string ParallelTitle
	{
		get
		{
			return this._ParallelTitle;
		}
		set
		{
			this._ParallelTitle = value;
		}
	}
	public string Editors
	{
		get
		{
			return this._Editors;
		}
		set
		{
			this._Editors = value;
		}
	}
	public string Meetings
	{
		get
		{
			return this._Meetings;
		}
		set
		{
			this._Meetings = value;
		}
	}
	public string PubPlace
	{
		get
		{
			return this._PubPlace;
		}
		set
		{
			this._PubPlace = value;
		}
	}
	public string ClassNo
	{
		get
		{
			return this._ClassNo;
		}
		set
		{
			this._ClassNo = value;
		}
	}
	public string Language
	{
		get
		{
			return this._Language;
		}
		set
		{
			this._Language = value;
		}
	}
	public string Binding
	{
		get
		{
			return this._Binding;
		}
		set
		{
			this._Binding = value;
		}
	}
	public string Pages
	{
		get
		{
			return this._Pages;
		}
		set
		{
			this._Pages = value;
		}
	}
	public string SpineLabel
	{
		get
		{
			return this._SpineLabel;
		}
		set
		{
			this._SpineLabel = value;
		}
	}
	public string PubType
	{
		get
		{
			return this._PubType;
		}
		set
		{
			this._PubType = value;
		}
	}
	public string Medium
	{
		get
		{
			return this._Medium;
		}
		set
		{
			this._Medium = value;
		}
	}
	public string Abstract
	{
		get
		{
			return this._Abstract;
		}
		set
		{
			this._Abstract = value;
		}
	}
	public string ShelfRef
	{
		get
		{
			return this._ShelfRef;
		}
		set
		{
			this._ShelfRef = value;
		}
	}
	public string Keywords
	{
		get
		{
			return this._Keywords;
		}
		set
		{
			this._Keywords = value;
		}
	}
	public string Subject
	{
		get
		{
			return this._Subject;
		}
		set
		{
			this._Subject = value;
		}
	}
	public string LibraryBranch
	{
		get
		{
			return this._LibraryBranch;
		}
		set
		{
			this._LibraryBranch = value;
		}
	}
	public string imageurl
	{
		get
		{
			return this._imageurl;
		}
		set
		{
			this._imageurl = value;
		}
	}
	public string Navigatelink
	{
		get
		{
			return this._Navigatelink;
		}
		set
		{
			this._Navigatelink = value;
		}
	}
	public string CatLogNo
	{
		get
		{
			return this._CatLogNo;
		}
		set
		{
			this._CatLogNo = value;
		}
	}
	public string Object
	{
		get
		{
			return this._Object;
		}
		set
		{
			this._Object = value;
		}
	}
	public BookDetails()
	{
	}
	public BookDetails(decimal Srn, string OrderNo, string Title, string Author, string Publisher, string BookType, string Dealer, string AquisitionType, string ReceivedGroup, string SetupBy, string Datesetup, int ReceivedStatus, int CatalogStatus, int Copies, string PublishedDate, string PublishedYear, int Vol, int No, string Edition, decimal Cost, decimal TotalCost, string ISBN, string ACCNO, string GRNumber, int Availability, string AccYear, string ParallelTitle, string Editors, string Meetings, string PubPlace, string ClassNo, string Language, string Binding, string Pages, string SpineLabel, string PubType, string Medium, string Abstract, string ShelfRef, string Keywords, string Subject, string LibraryBranch, string imageurl, string Navigatelink, string CatLogNo, string Object)
	{
		this._Srn = Srn;
		this._OrderNo = OrderNo;
		this._Title = Title;
		this._Author = Author;
		this._Publisher = Publisher;
		this._BookType = BookType;
		this._Dealer = Dealer;
		this._AquisitionType = AquisitionType;
		this._ReceivedGroup = ReceivedGroup;
		this._SetupBy = SetupBy;
		this._Datesetup = Datesetup;
		this._ReceivedStatus = ReceivedStatus;
		this._CatalogStatus = CatalogStatus;
		this._Copies = Copies;
		this._PublishedDate = PublishedDate;
		this._PublishedYear = PublishedYear;
		this._Vol = Vol;
		this._No = No;
		this._Edition = Edition;
		this._Cost = Cost;
		this._TotalCost = TotalCost;
		this._ISBN = ISBN;
		this._ACCNO = ACCNO;
		this._GRNumber = GRNumber;
		this._Availability = Availability;
		this._AccYear = AccYear;
		this._ParallelTitle = ParallelTitle;
		this._Editors = Editors;
		this._Meetings = Meetings;
		this._PubPlace = PubPlace;
		this._ClassNo = ClassNo;
		this._Language = Language;
		this._Binding = Binding;
		this._Pages = Pages;
		this._SpineLabel = SpineLabel;
		this._PubType = PubType;
		this._Medium = Medium;
		this._Abstract = Abstract;
		this._ShelfRef = ShelfRef;
		this._Keywords = Keywords;
		this._Subject = Subject;
		this._LibraryBranch = LibraryBranch;
		this._imageurl = imageurl;
		this._Navigatelink = Navigatelink;
		this._CatLogNo = CatLogNo;
		this._Object = Object;
	}
}
