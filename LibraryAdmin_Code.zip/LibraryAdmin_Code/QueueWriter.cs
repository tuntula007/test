using Cyberspace.Emailpackage;
using Cyberspace.ServiceBrocker;
using System;
using System.Configuration;
using System.Messaging;
public class QueueWriter
{
	private string CrudQueryPath = "";
	private string EmailPath = "";
	private string AuditLogPath = "";
	private string RawDataPath = "";
	private string msg = "";
	private string SchLevelPromotions = "";
	public QueueWriter()
	{
		this.CrudQueryPath = ".\\Private$\\" + ConfigurationManager.AppSettings["Crudqueries"];
		this.EmailPath = ".\\Private$\\" + ConfigurationManager.AppSettings["Outgoingmails"];
		this.AuditLogPath = ".\\Private$\\" + ConfigurationManager.AppSettings["Auditlog"];
		this.RawDataPath = ".\\Private$\\" + ConfigurationManager.AppSettings["RawdataUploader"];
		this.SchLevelPromotions = ".\\Private$\\" + ConfigurationManager.AppSettings["SchLevelPromotion"];
	}
	public string SendToCrud(string sourceClass, string methodName, string actionType, string actionBody)
	{
		string result;
		try
		{
			if (this.PostRequest(new CSingleAttribute
			{
				SourceApplication = "Eduportal",
				SourceClass = sourceClass,
				MethodName = methodName,
				ActionType = actionType,
				ActionBody = actionBody,
				DateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff")
			}))
			{
				result = "true";
			}
			else
			{
				result = "false";
			}
		}
		catch (Exception ex)
		{
			result = ex.Message;
		}
		return result;
	}
	public string SendToCrud(CSingleAttribute cs)
	{
		string result;
		try
		{
			cs.DateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
			if (this.PostRequest(cs))
			{
				result = "true";
			}
			else
			{
				result = "false";
			}
		}
		catch (Exception ex)
		{
			result = ex.Message;
		}
		return result;
	}
	public bool SendToEmail(CMail cm)
	{
		bool result = false;
		try
		{
			DefaultPropertiesToSend defaultPropertiesToSend = new DefaultPropertiesToSend();
			defaultPropertiesToSend.AttachSenderId = true;
			defaultPropertiesToSend.Recoverable = true;
			MessageQueue messageQueue;
			if (!MessageQueue.Exists(this.EmailPath))
			{
				messageQueue = MessageQueue.Create(this.EmailPath);
				messageQueue.SetPermissions("Everyone", MessageQueueAccessRights.FullControl);
			}
			else
			{
				messageQueue = new MessageQueue(this.EmailPath);
				messageQueue.Formatter = new XmlMessageFormatter(new Type[]
				{
					typeof(CMail)
				});
				messageQueue.DefaultPropertiesToSend = defaultPropertiesToSend;
			}
			messageQueue.DefaultPropertiesToSend.Recoverable = true;
			messageQueue.DefaultPropertiesToSend.AttachSenderId = true;
			messageQueue.DefaultPropertiesToSend.Label = cm.Subject.Substring(0, 10) + " .... " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
			messageQueue.Send(cm);
			messageQueue.Dispose();
			messageQueue.Close();
			result = true;
		}
		catch (Exception ex)
		{
			this.msg = ex.Message + "||" + ex.StackTrace;
			this.LogError(this.msg, "Edu Portal", "Send To Email");
			result = false;
		}
		return result;
	}
	private void LogError(string strMsg, string SourceApp, string SourceMethod)
	{
		CPermit cPermit = new CPermit();
		cPermit.Direction = strMsg;
		cPermit.SourceApplication = SourceApp;
		cPermit.MethodName = SourceMethod;
		cPermit.MsgType = "ERROR";
	}
	public bool SendToAuditLog(CWritetoqueue cp)
	{
		bool result = false;
		try
		{
			DefaultPropertiesToSend defaultPropertiesToSend = new DefaultPropertiesToSend();
			defaultPropertiesToSend.AttachSenderId = true;
			defaultPropertiesToSend.Recoverable = true;
			MessageQueue messageQueue;
			if (!MessageQueue.Exists(this.AuditLogPath))
			{
				messageQueue = MessageQueue.Create(this.AuditLogPath);
				messageQueue.SetPermissions("Everyone", MessageQueueAccessRights.FullControl);
			}
			else
			{
				messageQueue = new MessageQueue(this.AuditLogPath);
				messageQueue.Formatter = new XmlMessageFormatter(new Type[]
				{
					typeof(CWritetoqueue)
				});
				messageQueue.DefaultPropertiesToSend = defaultPropertiesToSend;
			}
			messageQueue.DefaultPropertiesToSend.Recoverable = true;
			messageQueue.DefaultPropertiesToSend.AttachSenderId = true;
			messageQueue.DefaultPropertiesToSend.Label = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
			messageQueue.Send(cp);
			messageQueue.Dispose();
			messageQueue.Close();
			result = true;
		}
		catch (Exception ex)
		{
			string arg_CB_0 = ex.Message;
			result = false;
		}
		return result;
	}
	public bool SendToRawData()
	{
		return false;
	}
	private bool PostRequest(CSingleAttribute sa)
	{
		bool result = false;
		try
		{
			MessageQueue messageQueue = new MessageQueue(this.CrudQueryPath);
			messageQueue.Send(sa);
			messageQueue.Dispose();
			result = true;
		}
		catch (Exception ex)
		{
			throw ex;
		}
		return result;
	}
	public bool SendToLevelPromo(string ActiveSession)
	{
		bool result = false;
		try
		{
			DefaultPropertiesToSend defaultPropertiesToSend = new DefaultPropertiesToSend();
			defaultPropertiesToSend.AttachSenderId = true;
			defaultPropertiesToSend.Recoverable = true;
			MessageQueue messageQueue;
			if (!MessageQueue.Exists(this.SchLevelPromotions))
			{
				messageQueue = MessageQueue.Create(this.SchLevelPromotions);
				messageQueue.SetPermissions("Everyone", MessageQueueAccessRights.FullControl);
			}
			else
			{
				messageQueue = new MessageQueue(this.SchLevelPromotions);
				messageQueue.Formatter = new XmlMessageFormatter(new Type[]
				{
					typeof(string)
				});
				messageQueue.DefaultPropertiesToSend = defaultPropertiesToSend;
			}
			messageQueue.DefaultPropertiesToSend.Recoverable = true;
			messageQueue.DefaultPropertiesToSend.AttachSenderId = true;
			messageQueue.DefaultPropertiesToSend.Label = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
			messageQueue.Send(ActiveSession);
			messageQueue.Dispose();
			messageQueue.Close();
			result = true;
		}
		catch (Exception ex)
		{
			string arg_CB_0 = ex.Message;
			result = false;
		}
		return result;
	}
}
