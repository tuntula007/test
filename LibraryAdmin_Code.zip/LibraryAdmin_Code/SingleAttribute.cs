using Cyberspace.ServiceBrocker;
using System;
using System.Configuration;
using System.Messaging;
public class SingleAttribute
{
	private string SingleAttributePath;
	public SingleAttribute()
	{
		this.SingleAttributePath = ".\\Private$\\" + ConfigurationManager.AppSettings["SingleAttribute"];
	}
	public string ToDataBase(string sourceClass, string methodName, string actionType, string actionBody)
	{
		string result;
		try
		{
			if (this.PostRequest(new CSingleAttribute
			{
				SourceApplication = "Eduportal",
				SourceClass = sourceClass,
				MethodName = methodName,
				ActionType = actionType,
				ActionBody = actionBody,
				DateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff")
			}))
			{
				result = "true";
			}
			else
			{
				result = "false";
			}
		}
		catch (Exception ex)
		{
			result = ex.Message;
		}
		return result;
	}
	private bool PostRequest(CSingleAttribute sa)
	{
		bool result = false;
		try
		{
			MessageQueue messageQueue = new MessageQueue(this.SingleAttributePath);
			messageQueue.Send(sa);
			messageQueue.Dispose();
			result = true;
		}
		catch (Exception ex)
		{
			throw ex;
		}
		return result;
	}
}
